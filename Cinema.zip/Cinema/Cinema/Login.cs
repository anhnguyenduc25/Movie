﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class Login : Form
    {
        string user;
        public Login()
        {
            InitializeComponent();
        }
        DataTable LoginAdmin()
        {
            string userName = textBoxUser.Text;
            string passWord = textBoxPass.Text;
            DataTable data = new DataTable();
            string query = "select count(*) from ACCOUNT where USER_ACCOUNT = '" + userName + "' and PASSWORD_ACCOUNT = '" + passWord + "' and STATUS_ACCOUNT = '" + 1 + "' ";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable LoginUser()
        {
            string userName = textBoxUser.Text;
            string passWord = textBoxPass.Text;
            DataTable data = new DataTable();
            string query = "select count(*) from ACCOUNT where USER_ACCOUNT = '" + userName + "' and PASSWORD_ACCOUNT = '" + passWord + "' and STATUS_ACCOUNT = '" + 0 + "' ";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if(textBoxPass.UseSystemPasswordChar == true)
            {
                textBoxPass.UseSystemPasswordChar = false;
            }
            else if (textBoxPass.UseSystemPasswordChar == false)
            {
                textBoxPass.UseSystemPasswordChar = true;
            }
        }

        private void textBoxUser_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void buttonSignUp_Click(object sender, EventArgs e)
        {
            SignUp signup = new SignUp();
            this.Hide();
            signup.ShowDialog();
            this.Close();
        }
        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (LoginAdmin().Rows[0][0].ToString() == "1")
            {
                user = textBoxUser.Text;
                Admin a = new Admin(user);
                this.Hide();
                a.ShowDialog();
                this.Close();
            }
            else if (LoginUser().Rows[0][0].ToString() == "1")
            {
                user = textBoxUser.Text;
                Home home = new Home(user);
                this.Hide();
                home.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu !");
            }
            if (string.IsNullOrEmpty(textBoxUser.Text))
            {
                textBoxUser.Focus();
                errorProvider1.SetError(textBoxUser, "Vui lòng nhập tài khoản !");
            }
            else if (!string.IsNullOrEmpty(textBoxUser.Text))
            {
                errorProvider1.SetError(textBoxUser, null);
            }
            if (string.IsNullOrEmpty(textBoxPass.Text))
            {
                textBoxPass.Focus();
                errorProvider2.SetError(textBoxPass, "Vui lòng nhập mật khẩu !");
            }
            else if (!string.IsNullOrEmpty(textBoxPass.Text))
            {
                errorProvider2.SetError(textBoxPass, null);
            }
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void textBoxUser_Validating(object sender, CancelEventArgs e)
        {
            
        }

        private void textBoxPass_Validating(object sender, CancelEventArgs e)
        {
            
        }

        private void textBoxPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
