﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cinema
{
    class ConnectionString
    {
        public static string connectionString = @"Data Source=DESKTOP-QBLRO6P\SQLEXPRESS;Initial Catalog=BANVEXEMPHIM;Integrated Security=True";
    }
}
