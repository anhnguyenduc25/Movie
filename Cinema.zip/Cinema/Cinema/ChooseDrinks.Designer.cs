﻿
namespace Cinema
{
    partial class ChooseDrinks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChooseDrinks));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelName1 = new System.Windows.Forms.Label();
            this.labelName2 = new System.Windows.Forms.Label();
            this.labelName3 = new System.Windows.Forms.Label();
            this.labelName4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelSoLuong1 = new System.Windows.Forms.Label();
            this.labelSoLuong2 = new System.Windows.Forms.Label();
            this.labelSoLuong3 = new System.Windows.Forms.Label();
            this.labelSoLuong4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBoxTiepTuc = new System.Windows.Forms.PictureBox();
            this.labelGiaTong = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBoxGiam4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxTang4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxGiam3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxTang3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxGiam2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxTang2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxGiam1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxTang1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelGia1 = new System.Windows.Forms.Label();
            this.labelGia2 = new System.Windows.Forms.Label();
            this.labelGia3 = new System.Windows.Forms.Label();
            this.labelGia4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTiepTuc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGiam4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTang4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGiam3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTang3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGiam2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTang2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGiam1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTang1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(122, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Combo - Bắp nước";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DeepPink;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(475, 49);
            this.panel1.TabIndex = 2;
            // 
            // labelName1
            // 
            this.labelName1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName1.Location = new System.Drawing.Point(143, 60);
            this.labelName1.Name = "labelName1";
            this.labelName1.Size = new System.Drawing.Size(320, 25);
            this.labelName1.TabIndex = 6;
            this.labelName1.Text = "HAPPY TIGER CUP 2022 - 249.000đ";
            // 
            // labelName2
            // 
            this.labelName2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName2.Location = new System.Drawing.Point(143, 214);
            this.labelName2.Name = "labelName2";
            this.labelName2.Size = new System.Drawing.Size(320, 25);
            this.labelName2.TabIndex = 7;
            this.labelName2.Text = "CGV SNACK COMBO - 113.000đ";
            // 
            // labelName3
            // 
            this.labelName3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName3.Location = new System.Drawing.Point(143, 368);
            this.labelName3.Name = "labelName3";
            this.labelName3.Size = new System.Drawing.Size(320, 25);
            this.labelName3.TabIndex = 8;
            this.labelName3.Text = "CGV COMBO - 102.000đ";
            // 
            // labelName4
            // 
            this.labelName4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName4.Location = new System.Drawing.Point(143, 522);
            this.labelName4.Name = "labelName4";
            this.labelName4.Size = new System.Drawing.Size(320, 25);
            this.labelName4.TabIndex = 9;
            this.labelName4.Text = "MY SNACK COMBO - 93.000đ";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(143, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(320, 123);
            this.label6.TabIndex = 10;
            this.label6.Text = "1 ly Dần Vui Vẻ (kèm nước) + 1 bắp ngọt lớn\r\n* Miễn phí đổi vị bắp Phô mai, Caram" +
    "el *\r\n** Nhận trong ngày xem phim **";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(143, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(320, 123);
            this.label7.TabIndex = 11;
            this.label7.Text = "1 Bắp Lớn + 2 Nước Siêu Lớn + 1 Snack\r\nNhận trong ngày xem phim\r\n* Miễn phí đổi v" +
    "ị bắp Caramel *\r\n** Đổi vị Phô Mai phụ thu thêm tiền **";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(143, 393);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(320, 123);
            this.label8.TabIndex = 12;
            this.label8.Text = "1 Bắp Lớn + 2 Nước Siêu Lớn\r\nNhận trong ngày xem phim\r\n* Miễn phí đổi vị bắp Cara" +
    "mel *\r\n** Đổi vị Phô Mai phụ thu thêm tiền **";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(143, 547);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(320, 123);
            this.label9.TabIndex = 13;
            this.label9.Text = "1 Bắp Lớn + 1 Nước Siêu Lớn + 1 Snack\r\nNhận trong ngày xem phim\r\n* Miễn phí đổi v" +
    "ị bắp Caramel *\r\n** Đổi vị Phô Mai phụ thu thêm tiền **";
            // 
            // labelSoLuong1
            // 
            this.labelSoLuong1.AutoSize = true;
            this.labelSoLuong1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoLuong1.Location = new System.Drawing.Point(181, 169);
            this.labelSoLuong1.Name = "labelSoLuong1";
            this.labelSoLuong1.Size = new System.Drawing.Size(24, 26);
            this.labelSoLuong1.TabIndex = 14;
            this.labelSoLuong1.Text = "0";
            this.labelSoLuong1.Click += new System.EventHandler(this.labelSoLuong1_Click);
            // 
            // labelSoLuong2
            // 
            this.labelSoLuong2.AutoSize = true;
            this.labelSoLuong2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoLuong2.Location = new System.Drawing.Point(181, 323);
            this.labelSoLuong2.Name = "labelSoLuong2";
            this.labelSoLuong2.Size = new System.Drawing.Size(24, 26);
            this.labelSoLuong2.TabIndex = 17;
            this.labelSoLuong2.Text = "0";
            // 
            // labelSoLuong3
            // 
            this.labelSoLuong3.AutoSize = true;
            this.labelSoLuong3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoLuong3.Location = new System.Drawing.Point(181, 477);
            this.labelSoLuong3.Name = "labelSoLuong3";
            this.labelSoLuong3.Size = new System.Drawing.Size(24, 26);
            this.labelSoLuong3.TabIndex = 20;
            this.labelSoLuong3.Text = "0";
            // 
            // labelSoLuong4
            // 
            this.labelSoLuong4.AutoSize = true;
            this.labelSoLuong4.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoLuong4.Location = new System.Drawing.Point(181, 631);
            this.labelSoLuong4.Name = "labelSoLuong4";
            this.labelSoLuong4.Size = new System.Drawing.Size(24, 26);
            this.labelSoLuong4.TabIndex = 23;
            this.labelSoLuong4.Text = "0";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.pictureBoxTiepTuc);
            this.panel2.Controls.Add(this.labelGiaTong);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Location = new System.Drawing.Point(0, 676);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(475, 109);
            this.panel2.TabIndex = 26;
            // 
            // pictureBoxTiepTuc
            // 
            this.pictureBoxTiepTuc.BackgroundImage = global::Cinema.Properties.Resources.buttonTiepTuc;
            this.pictureBoxTiepTuc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxTiepTuc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxTiepTuc.Location = new System.Drawing.Point(18, 36);
            this.pictureBoxTiepTuc.Name = "pictureBoxTiepTuc";
            this.pictureBoxTiepTuc.Size = new System.Drawing.Size(438, 65);
            this.pictureBoxTiepTuc.TabIndex = 25;
            this.pictureBoxTiepTuc.TabStop = false;
            this.pictureBoxTiepTuc.Click += new System.EventHandler(this.pictureBoxTiepTuc_Click);
            // 
            // labelGiaTong
            // 
            this.labelGiaTong.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGiaTong.ForeColor = System.Drawing.Color.Black;
            this.labelGiaTong.Location = new System.Drawing.Point(257, 3);
            this.labelGiaTong.Name = "labelGiaTong";
            this.labelGiaTong.Size = new System.Drawing.Size(206, 30);
            this.labelGiaTong.TabIndex = 8;
            this.labelGiaTong.Text = "0đ";
            this.labelGiaTong.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(12, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 19);
            this.label10.TabIndex = 7;
            this.label10.Text = "Tổng cộng";
            // 
            // pictureBoxGiam4
            // 
            this.pictureBoxGiam4.BackgroundImage = global::Cinema.Properties.Resources.buttonGiam;
            this.pictureBoxGiam4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxGiam4.Location = new System.Drawing.Point(148, 629);
            this.pictureBoxGiam4.Name = "pictureBoxGiam4";
            this.pictureBoxGiam4.Size = new System.Drawing.Size(28, 28);
            this.pictureBoxGiam4.TabIndex = 25;
            this.pictureBoxGiam4.TabStop = false;
            this.pictureBoxGiam4.Click += new System.EventHandler(this.pictureBoxGiam4_Click);
            // 
            // pictureBoxTang4
            // 
            this.pictureBoxTang4.BackgroundImage = global::Cinema.Properties.Resources.buttonTang;
            this.pictureBoxTang4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxTang4.Location = new System.Drawing.Point(211, 629);
            this.pictureBoxTang4.Name = "pictureBoxTang4";
            this.pictureBoxTang4.Size = new System.Drawing.Size(28, 28);
            this.pictureBoxTang4.TabIndex = 24;
            this.pictureBoxTang4.TabStop = false;
            this.pictureBoxTang4.Click += new System.EventHandler(this.pictureBoxTang4_Click);
            // 
            // pictureBoxGiam3
            // 
            this.pictureBoxGiam3.BackgroundImage = global::Cinema.Properties.Resources.buttonGiam;
            this.pictureBoxGiam3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxGiam3.Location = new System.Drawing.Point(148, 475);
            this.pictureBoxGiam3.Name = "pictureBoxGiam3";
            this.pictureBoxGiam3.Size = new System.Drawing.Size(28, 28);
            this.pictureBoxGiam3.TabIndex = 22;
            this.pictureBoxGiam3.TabStop = false;
            this.pictureBoxGiam3.Click += new System.EventHandler(this.pictureBoxGiam3_Click);
            // 
            // pictureBoxTang3
            // 
            this.pictureBoxTang3.BackgroundImage = global::Cinema.Properties.Resources.buttonTang;
            this.pictureBoxTang3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxTang3.Location = new System.Drawing.Point(211, 475);
            this.pictureBoxTang3.Name = "pictureBoxTang3";
            this.pictureBoxTang3.Size = new System.Drawing.Size(28, 28);
            this.pictureBoxTang3.TabIndex = 21;
            this.pictureBoxTang3.TabStop = false;
            this.pictureBoxTang3.Click += new System.EventHandler(this.pictureBoxTang3_Click);
            // 
            // pictureBoxGiam2
            // 
            this.pictureBoxGiam2.BackgroundImage = global::Cinema.Properties.Resources.buttonGiam;
            this.pictureBoxGiam2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxGiam2.Location = new System.Drawing.Point(148, 321);
            this.pictureBoxGiam2.Name = "pictureBoxGiam2";
            this.pictureBoxGiam2.Size = new System.Drawing.Size(28, 28);
            this.pictureBoxGiam2.TabIndex = 19;
            this.pictureBoxGiam2.TabStop = false;
            this.pictureBoxGiam2.Click += new System.EventHandler(this.pictureBoxGiam2_Click);
            // 
            // pictureBoxTang2
            // 
            this.pictureBoxTang2.BackgroundImage = global::Cinema.Properties.Resources.buttonTang;
            this.pictureBoxTang2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxTang2.Location = new System.Drawing.Point(211, 321);
            this.pictureBoxTang2.Name = "pictureBoxTang2";
            this.pictureBoxTang2.Size = new System.Drawing.Size(28, 28);
            this.pictureBoxTang2.TabIndex = 18;
            this.pictureBoxTang2.TabStop = false;
            this.pictureBoxTang2.Click += new System.EventHandler(this.pictureBoxTang2_Click);
            // 
            // pictureBoxGiam1
            // 
            this.pictureBoxGiam1.BackgroundImage = global::Cinema.Properties.Resources.buttonGiam;
            this.pictureBoxGiam1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxGiam1.Location = new System.Drawing.Point(148, 167);
            this.pictureBoxGiam1.Name = "pictureBoxGiam1";
            this.pictureBoxGiam1.Size = new System.Drawing.Size(28, 28);
            this.pictureBoxGiam1.TabIndex = 16;
            this.pictureBoxGiam1.TabStop = false;
            this.pictureBoxGiam1.Click += new System.EventHandler(this.pictureBoxGiam1_Click);
            // 
            // pictureBoxTang1
            // 
            this.pictureBoxTang1.BackgroundImage = global::Cinema.Properties.Resources.buttonTang;
            this.pictureBoxTang1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxTang1.Location = new System.Drawing.Point(211, 167);
            this.pictureBoxTang1.Name = "pictureBoxTang1";
            this.pictureBoxTang1.Size = new System.Drawing.Size(28, 28);
            this.pictureBoxTang1.TabIndex = 15;
            this.pictureBoxTang1.TabStop = false;
            this.pictureBoxTang1.Click += new System.EventHandler(this.pictureBoxTang1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::Cinema.Properties.Resources.nuoc4;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox4.Location = new System.Drawing.Point(9, 522);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(127, 148);
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::Cinema.Properties.Resources.nuoc3;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox3.Location = new System.Drawing.Point(9, 368);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(127, 148);
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::Cinema.Properties.Resources.nuoc2;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Location = new System.Drawing.Point(9, 214);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(127, 148);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Cinema.Properties.Resources.nuoc1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(9, 60);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(127, 148);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelGia1
            // 
            this.labelGia1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGia1.ForeColor = System.Drawing.Color.Black;
            this.labelGia1.Location = new System.Drawing.Point(277, 167);
            this.labelGia1.Name = "labelGia1";
            this.labelGia1.Size = new System.Drawing.Size(179, 30);
            this.labelGia1.TabIndex = 27;
            this.labelGia1.Text = "0đ";
            this.labelGia1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.labelGia1.Click += new System.EventHandler(this.labelGia1_Click);
            // 
            // labelGia2
            // 
            this.labelGia2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGia2.ForeColor = System.Drawing.Color.Black;
            this.labelGia2.Location = new System.Drawing.Point(277, 321);
            this.labelGia2.Name = "labelGia2";
            this.labelGia2.Size = new System.Drawing.Size(179, 30);
            this.labelGia2.TabIndex = 28;
            this.labelGia2.Text = "0đ";
            this.labelGia2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.labelGia2.Click += new System.EventHandler(this.labelGia2_Click);
            // 
            // labelGia3
            // 
            this.labelGia3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGia3.ForeColor = System.Drawing.Color.Black;
            this.labelGia3.Location = new System.Drawing.Point(277, 475);
            this.labelGia3.Name = "labelGia3";
            this.labelGia3.Size = new System.Drawing.Size(179, 30);
            this.labelGia3.TabIndex = 29;
            this.labelGia3.Text = "0đ";
            this.labelGia3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelGia4
            // 
            this.labelGia4.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGia4.ForeColor = System.Drawing.Color.Black;
            this.labelGia4.Location = new System.Drawing.Point(277, 629);
            this.labelGia4.Name = "labelGia4";
            this.labelGia4.Size = new System.Drawing.Size(179, 30);
            this.labelGia4.TabIndex = 30;
            this.labelGia4.Text = "0đ";
            this.labelGia4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(381, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 31;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ChooseDrinks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(475, 785);
            this.Controls.Add(this.labelGia4);
            this.Controls.Add(this.labelGia3);
            this.Controls.Add(this.labelGia2);
            this.Controls.Add(this.labelGia1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBoxGiam4);
            this.Controls.Add(this.pictureBoxTang4);
            this.Controls.Add(this.labelSoLuong4);
            this.Controls.Add(this.pictureBoxGiam3);
            this.Controls.Add(this.pictureBoxTang3);
            this.Controls.Add(this.labelSoLuong3);
            this.Controls.Add(this.pictureBoxGiam2);
            this.Controls.Add(this.pictureBoxTang2);
            this.Controls.Add(this.labelSoLuong2);
            this.Controls.Add(this.pictureBoxGiam1);
            this.Controls.Add(this.pictureBoxTang1);
            this.Controls.Add(this.labelSoLuong1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labelName4);
            this.Controls.Add(this.labelName3);
            this.Controls.Add(this.labelName2);
            this.Controls.Add(this.labelName1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ChooseDrinks";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chọn đồ uống";
            this.Load += new System.EventHandler(this.ChooseDrinks_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTiepTuc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGiam4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTang4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGiam3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTang3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGiam2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTang2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGiam1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTang1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label labelName1;
        private System.Windows.Forms.Label labelName2;
        private System.Windows.Forms.Label labelName3;
        private System.Windows.Forms.Label labelName4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelSoLuong1;
        private System.Windows.Forms.PictureBox pictureBoxTang1;
        private System.Windows.Forms.PictureBox pictureBoxGiam1;
        private System.Windows.Forms.PictureBox pictureBoxGiam2;
        private System.Windows.Forms.PictureBox pictureBoxTang2;
        private System.Windows.Forms.Label labelSoLuong2;
        private System.Windows.Forms.PictureBox pictureBoxGiam3;
        private System.Windows.Forms.PictureBox pictureBoxTang3;
        private System.Windows.Forms.Label labelSoLuong3;
        private System.Windows.Forms.PictureBox pictureBoxGiam4;
        private System.Windows.Forms.PictureBox pictureBoxTang4;
        private System.Windows.Forms.Label labelSoLuong4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBoxTiepTuc;
        private System.Windows.Forms.Label labelGiaTong;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelGia1;
        private System.Windows.Forms.Label labelGia2;
        private System.Windows.Forms.Label labelGia3;
        private System.Windows.Forms.Label labelGia4;
        private System.Windows.Forms.Button button1;
    }
}