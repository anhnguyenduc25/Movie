﻿
namespace Cinema
{
    partial class BuyTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BuyTicket));
            this.buttonBuyTicket = new System.Windows.Forms.Button();
            this.buttonNews = new System.Windows.Forms.Button();
            this.buttonEvaluate = new System.Windows.Forms.Button();
            this.buttonCalendar = new System.Windows.Forms.Button();
            this.buttonInformation = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.buttonNgay1 = new System.Windows.Forms.Button();
            this.buttonNgay2 = new System.Windows.Forms.Button();
            this.buttonNgay3 = new System.Windows.Forms.Button();
            this.buttonNgay4 = new System.Windows.Forms.Button();
            this.buttonNgay5 = new System.Windows.Forms.Button();
            this.buttonNgay6 = new System.Windows.Forms.Button();
            this.buttonNgay7 = new System.Windows.Forms.Button();
            this.buttoncgv = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.buttonTime1 = new System.Windows.Forms.Button();
            this.buttonTime2 = new System.Windows.Forms.Button();
            this.buttonTime3 = new System.Windows.Forms.Button();
            this.buttonTime4 = new System.Windows.Forms.Button();
            this.buttonTime5 = new System.Windows.Forms.Button();
            this.buttonTime6 = new System.Windows.Forms.Button();
            this.buttonTime7 = new System.Windows.Forms.Button();
            this.buttonTime8 = new System.Windows.Forms.Button();
            this.buttonTime9 = new System.Windows.Forms.Button();
            this.buttonTime10 = new System.Windows.Forms.Button();
            this.buttonTime11 = new System.Windows.Forms.Button();
            this.buttonTime12 = new System.Windows.Forms.Button();
            this.buttonTime13 = new System.Windows.Forms.Button();
            this.buttonTime14 = new System.Windows.Forms.Button();
            this.buttonTime15 = new System.Windows.Forms.Button();
            this.buttonTime16 = new System.Windows.Forms.Button();
            this.buttonTime17 = new System.Windows.Forms.Button();
            this.buttonTime18 = new System.Windows.Forms.Button();
            this.buttonTime19 = new System.Windows.Forms.Button();
            this.buttonTime20 = new System.Windows.Forms.Button();
            this.buttonTime21 = new System.Windows.Forms.Button();
            this.buttonTime22 = new System.Windows.Forms.Button();
            this.buttonTime23 = new System.Windows.Forms.Button();
            this.buttonTime24 = new System.Windows.Forms.Button();
            this.buttonTime25 = new System.Windows.Forms.Button();
            this.buttonTime26 = new System.Windows.Forms.Button();
            this.buttonTime27 = new System.Windows.Forms.Button();
            this.buttonTime28 = new System.Windows.Forms.Button();
            this.buttonTime29 = new System.Windows.Forms.Button();
            this.buttonTime30 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBoxcgv2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxcgv1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxcgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxcgv1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBuyTicket
            // 
            this.buttonBuyTicket.BackColor = System.Drawing.Color.Salmon;
            this.buttonBuyTicket.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonBuyTicket.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonBuyTicket.Enabled = false;
            this.buttonBuyTicket.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonBuyTicket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBuyTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBuyTicket.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonBuyTicket.Location = new System.Drawing.Point(344, 2);
            this.buttonBuyTicket.Name = "buttonBuyTicket";
            this.buttonBuyTicket.Size = new System.Drawing.Size(169, 33);
            this.buttonBuyTicket.TabIndex = 93;
            this.buttonBuyTicket.Text = "Mua vé";
            this.buttonBuyTicket.UseVisualStyleBackColor = false;
            this.buttonBuyTicket.Click += new System.EventHandler(this.button8_Click);
            // 
            // buttonNews
            // 
            this.buttonNews.BackColor = System.Drawing.Color.White;
            this.buttonNews.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNews.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNews.Enabled = false;
            this.buttonNews.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNews.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNews.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonNews.Location = new System.Drawing.Point(515, 2);
            this.buttonNews.Name = "buttonNews";
            this.buttonNews.Size = new System.Drawing.Size(169, 33);
            this.buttonNews.TabIndex = 92;
            this.buttonNews.Text = "Tin tức";
            this.buttonNews.UseVisualStyleBackColor = false;
            this.buttonNews.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonEvaluate
            // 
            this.buttonEvaluate.BackColor = System.Drawing.Color.White;
            this.buttonEvaluate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonEvaluate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonEvaluate.Enabled = false;
            this.buttonEvaluate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonEvaluate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEvaluate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEvaluate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonEvaluate.Location = new System.Drawing.Point(686, 2);
            this.buttonEvaluate.Name = "buttonEvaluate";
            this.buttonEvaluate.Size = new System.Drawing.Size(169, 33);
            this.buttonEvaluate.TabIndex = 91;
            this.buttonEvaluate.Text = "Đánh giá";
            this.buttonEvaluate.UseVisualStyleBackColor = false;
            this.buttonEvaluate.Click += new System.EventHandler(this.button6_Click);
            // 
            // buttonCalendar
            // 
            this.buttonCalendar.BackColor = System.Drawing.Color.White;
            this.buttonCalendar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonCalendar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCalendar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonCalendar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCalendar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalendar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonCalendar.Location = new System.Drawing.Point(173, 2);
            this.buttonCalendar.Name = "buttonCalendar";
            this.buttonCalendar.Size = new System.Drawing.Size(169, 33);
            this.buttonCalendar.TabIndex = 90;
            this.buttonCalendar.Text = "Lịch chiếu";
            this.buttonCalendar.UseVisualStyleBackColor = false;
            this.buttonCalendar.Click += new System.EventHandler(this.button5_Click);
            // 
            // buttonInformation
            // 
            this.buttonInformation.BackColor = System.Drawing.Color.White;
            this.buttonInformation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonInformation.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonInformation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonInformation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonInformation.Location = new System.Drawing.Point(2, 2);
            this.buttonInformation.Name = "buttonInformation";
            this.buttonInformation.Size = new System.Drawing.Size(169, 33);
            this.buttonInformation.TabIndex = 89;
            this.buttonInformation.Text = "Thông tin phim";
            this.buttonInformation.UseVisualStyleBackColor = false;
            this.buttonInformation.Click += new System.EventHandler(this.button4_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.Location = new System.Drawing.Point(182, 5);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(504, 32);
            this.comboBox1.Sorted = true;
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(19, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(159, 29);
            this.label14.TabIndex = 159;
            this.label14.Text = "Chọn địa điểm:";
            // 
            // buttonNgay1
            // 
            this.buttonNgay1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.buttonNgay1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNgay1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNgay1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNgay1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNgay1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNgay1.ForeColor = System.Drawing.Color.Black;
            this.buttonNgay1.Location = new System.Drawing.Point(14, 40);
            this.buttonNgay1.Name = "buttonNgay1";
            this.buttonNgay1.Size = new System.Drawing.Size(169, 56);
            this.buttonNgay1.TabIndex = 160;
            this.buttonNgay1.UseVisualStyleBackColor = false;
            this.buttonNgay1.Click += new System.EventHandler(this.button10_Click);
            // 
            // buttonNgay2
            // 
            this.buttonNgay2.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonNgay2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNgay2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNgay2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNgay2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNgay2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNgay2.ForeColor = System.Drawing.Color.DimGray;
            this.buttonNgay2.Location = new System.Drawing.Point(181, 40);
            this.buttonNgay2.Name = "buttonNgay2";
            this.buttonNgay2.Size = new System.Drawing.Size(169, 56);
            this.buttonNgay2.TabIndex = 161;
            this.buttonNgay2.UseVisualStyleBackColor = false;
            this.buttonNgay2.Click += new System.EventHandler(this.button9_Click);
            // 
            // buttonNgay3
            // 
            this.buttonNgay3.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonNgay3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNgay3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNgay3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNgay3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNgay3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNgay3.ForeColor = System.Drawing.Color.DimGray;
            this.buttonNgay3.Location = new System.Drawing.Point(349, 40);
            this.buttonNgay3.Name = "buttonNgay3";
            this.buttonNgay3.Size = new System.Drawing.Size(169, 56);
            this.buttonNgay3.TabIndex = 162;
            this.buttonNgay3.UseVisualStyleBackColor = false;
            this.buttonNgay3.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonNgay4
            // 
            this.buttonNgay4.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonNgay4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNgay4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNgay4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNgay4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNgay4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNgay4.ForeColor = System.Drawing.Color.DimGray;
            this.buttonNgay4.Location = new System.Drawing.Point(517, 40);
            this.buttonNgay4.Name = "buttonNgay4";
            this.buttonNgay4.Size = new System.Drawing.Size(169, 56);
            this.buttonNgay4.TabIndex = 163;
            this.buttonNgay4.UseVisualStyleBackColor = false;
            this.buttonNgay4.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonNgay5
            // 
            this.buttonNgay5.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonNgay5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNgay5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNgay5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNgay5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNgay5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNgay5.ForeColor = System.Drawing.Color.DimGray;
            this.buttonNgay5.Location = new System.Drawing.Point(685, 40);
            this.buttonNgay5.Name = "buttonNgay5";
            this.buttonNgay5.Size = new System.Drawing.Size(169, 56);
            this.buttonNgay5.TabIndex = 164;
            this.buttonNgay5.UseVisualStyleBackColor = false;
            this.buttonNgay5.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonNgay6
            // 
            this.buttonNgay6.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonNgay6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNgay6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNgay6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNgay6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNgay6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNgay6.ForeColor = System.Drawing.Color.DimGray;
            this.buttonNgay6.Location = new System.Drawing.Point(853, 40);
            this.buttonNgay6.Name = "buttonNgay6";
            this.buttonNgay6.Size = new System.Drawing.Size(169, 56);
            this.buttonNgay6.TabIndex = 165;
            this.buttonNgay6.UseVisualStyleBackColor = false;
            this.buttonNgay6.Click += new System.EventHandler(this.button11_Click);
            // 
            // buttonNgay7
            // 
            this.buttonNgay7.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonNgay7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNgay7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNgay7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNgay7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNgay7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNgay7.ForeColor = System.Drawing.Color.DimGray;
            this.buttonNgay7.Location = new System.Drawing.Point(1021, 40);
            this.buttonNgay7.Name = "buttonNgay7";
            this.buttonNgay7.Size = new System.Drawing.Size(169, 56);
            this.buttonNgay7.TabIndex = 166;
            this.buttonNgay7.UseVisualStyleBackColor = false;
            this.buttonNgay7.Click += new System.EventHandler(this.button12_Click);
            // 
            // buttoncgv
            // 
            this.buttoncgv.BackColor = System.Drawing.Color.Gainsboro;
            this.buttoncgv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttoncgv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttoncgv.Enabled = false;
            this.buttoncgv.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttoncgv.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttoncgv.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttoncgv.ForeColor = System.Drawing.Color.Black;
            this.buttoncgv.Location = new System.Drawing.Point(14, 111);
            this.buttoncgv.Name = "buttoncgv";
            this.buttoncgv.Size = new System.Drawing.Size(504, 62);
            this.buttoncgv.TabIndex = 167;
            this.buttoncgv.Text = "CGV Cinemas";
            this.buttoncgv.UseVisualStyleBackColor = false;
            this.buttoncgv.Visible = false;
            this.buttoncgv.Click += new System.EventHandler(this.buttoncgv_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(14, 179);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(504, 35);
            this.button1.TabIndex = 169;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(14, 220);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(504, 35);
            this.button2.TabIndex = 170;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(14, 261);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(504, 35);
            this.button3.TabIndex = 171;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(14, 302);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(504, 35);
            this.button4.TabIndex = 172;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(14, 343);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(504, 35);
            this.button5.TabIndex = 173;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // buttonTime1
            // 
            this.buttonTime1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime1.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime1.Location = new System.Drawing.Point(547, 118);
            this.buttonTime1.Name = "buttonTime1";
            this.buttonTime1.Size = new System.Drawing.Size(102, 45);
            this.buttonTime1.TabIndex = 175;
            this.buttonTime1.UseVisualStyleBackColor = false;
            this.buttonTime1.Visible = false;
            this.buttonTime1.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // buttonTime2
            // 
            this.buttonTime2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime2.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime2.Location = new System.Drawing.Point(655, 118);
            this.buttonTime2.Name = "buttonTime2";
            this.buttonTime2.Size = new System.Drawing.Size(102, 45);
            this.buttonTime2.TabIndex = 176;
            this.buttonTime2.UseVisualStyleBackColor = false;
            this.buttonTime2.Visible = false;
            this.buttonTime2.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // buttonTime3
            // 
            this.buttonTime3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime3.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime3.Location = new System.Drawing.Point(763, 118);
            this.buttonTime3.Name = "buttonTime3";
            this.buttonTime3.Size = new System.Drawing.Size(102, 45);
            this.buttonTime3.TabIndex = 177;
            this.buttonTime3.UseVisualStyleBackColor = false;
            this.buttonTime3.Visible = false;
            this.buttonTime3.Click += new System.EventHandler(this.button11_Click_1);
            // 
            // buttonTime4
            // 
            this.buttonTime4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime4.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime4.Location = new System.Drawing.Point(871, 118);
            this.buttonTime4.Name = "buttonTime4";
            this.buttonTime4.Size = new System.Drawing.Size(102, 45);
            this.buttonTime4.TabIndex = 178;
            this.buttonTime4.UseVisualStyleBackColor = false;
            this.buttonTime4.Visible = false;
            this.buttonTime4.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // buttonTime5
            // 
            this.buttonTime5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime5.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime5.Location = new System.Drawing.Point(979, 118);
            this.buttonTime5.Name = "buttonTime5";
            this.buttonTime5.Size = new System.Drawing.Size(102, 45);
            this.buttonTime5.TabIndex = 179;
            this.buttonTime5.UseVisualStyleBackColor = false;
            this.buttonTime5.Visible = false;
            this.buttonTime5.Click += new System.EventHandler(this.button13_Click);
            // 
            // buttonTime6
            // 
            this.buttonTime6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime6.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime6.Location = new System.Drawing.Point(1087, 118);
            this.buttonTime6.Name = "buttonTime6";
            this.buttonTime6.Size = new System.Drawing.Size(102, 45);
            this.buttonTime6.TabIndex = 180;
            this.buttonTime6.UseVisualStyleBackColor = false;
            this.buttonTime6.Visible = false;
            this.buttonTime6.Click += new System.EventHandler(this.button14_Click);
            // 
            // buttonTime7
            // 
            this.buttonTime7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime7.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime7.Location = new System.Drawing.Point(547, 169);
            this.buttonTime7.Name = "buttonTime7";
            this.buttonTime7.Size = new System.Drawing.Size(102, 45);
            this.buttonTime7.TabIndex = 181;
            this.buttonTime7.UseVisualStyleBackColor = false;
            this.buttonTime7.Visible = false;
            this.buttonTime7.Click += new System.EventHandler(this.button20_Click);
            // 
            // buttonTime8
            // 
            this.buttonTime8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime8.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime8.Location = new System.Drawing.Point(655, 169);
            this.buttonTime8.Name = "buttonTime8";
            this.buttonTime8.Size = new System.Drawing.Size(102, 45);
            this.buttonTime8.TabIndex = 182;
            this.buttonTime8.UseVisualStyleBackColor = false;
            this.buttonTime8.Visible = false;
            this.buttonTime8.Click += new System.EventHandler(this.button19_Click);
            // 
            // buttonTime9
            // 
            this.buttonTime9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime9.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime9.Location = new System.Drawing.Point(763, 169);
            this.buttonTime9.Name = "buttonTime9";
            this.buttonTime9.Size = new System.Drawing.Size(102, 45);
            this.buttonTime9.TabIndex = 183;
            this.buttonTime9.UseVisualStyleBackColor = false;
            this.buttonTime9.Visible = false;
            this.buttonTime9.Click += new System.EventHandler(this.button18_Click);
            // 
            // buttonTime10
            // 
            this.buttonTime10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime10.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime10.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime10.Location = new System.Drawing.Point(871, 169);
            this.buttonTime10.Name = "buttonTime10";
            this.buttonTime10.Size = new System.Drawing.Size(102, 45);
            this.buttonTime10.TabIndex = 184;
            this.buttonTime10.UseVisualStyleBackColor = false;
            this.buttonTime10.Visible = false;
            this.buttonTime10.Click += new System.EventHandler(this.button17_Click);
            // 
            // buttonTime11
            // 
            this.buttonTime11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime11.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime11.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime11.Location = new System.Drawing.Point(979, 169);
            this.buttonTime11.Name = "buttonTime11";
            this.buttonTime11.Size = new System.Drawing.Size(102, 45);
            this.buttonTime11.TabIndex = 185;
            this.buttonTime11.UseVisualStyleBackColor = false;
            this.buttonTime11.Visible = false;
            this.buttonTime11.Click += new System.EventHandler(this.button16_Click);
            // 
            // buttonTime12
            // 
            this.buttonTime12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime12.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime12.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime12.Location = new System.Drawing.Point(1087, 169);
            this.buttonTime12.Name = "buttonTime12";
            this.buttonTime12.Size = new System.Drawing.Size(102, 45);
            this.buttonTime12.TabIndex = 186;
            this.buttonTime12.UseVisualStyleBackColor = false;
            this.buttonTime12.Visible = false;
            this.buttonTime12.Click += new System.EventHandler(this.button15_Click);
            // 
            // buttonTime13
            // 
            this.buttonTime13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime13.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime13.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime13.Location = new System.Drawing.Point(547, 221);
            this.buttonTime13.Name = "buttonTime13";
            this.buttonTime13.Size = new System.Drawing.Size(102, 45);
            this.buttonTime13.TabIndex = 187;
            this.buttonTime13.UseVisualStyleBackColor = false;
            this.buttonTime13.Visible = false;
            this.buttonTime13.Click += new System.EventHandler(this.button26_Click);
            // 
            // buttonTime14
            // 
            this.buttonTime14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime14.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime14.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime14.Location = new System.Drawing.Point(655, 221);
            this.buttonTime14.Name = "buttonTime14";
            this.buttonTime14.Size = new System.Drawing.Size(102, 45);
            this.buttonTime14.TabIndex = 188;
            this.buttonTime14.UseVisualStyleBackColor = false;
            this.buttonTime14.Visible = false;
            this.buttonTime14.Click += new System.EventHandler(this.button25_Click);
            // 
            // buttonTime15
            // 
            this.buttonTime15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime15.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime15.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime15.Location = new System.Drawing.Point(763, 221);
            this.buttonTime15.Name = "buttonTime15";
            this.buttonTime15.Size = new System.Drawing.Size(102, 45);
            this.buttonTime15.TabIndex = 189;
            this.buttonTime15.UseVisualStyleBackColor = false;
            this.buttonTime15.Visible = false;
            this.buttonTime15.Click += new System.EventHandler(this.button24_Click);
            // 
            // buttonTime16
            // 
            this.buttonTime16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime16.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime16.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime16.Location = new System.Drawing.Point(871, 221);
            this.buttonTime16.Name = "buttonTime16";
            this.buttonTime16.Size = new System.Drawing.Size(102, 45);
            this.buttonTime16.TabIndex = 190;
            this.buttonTime16.UseVisualStyleBackColor = false;
            this.buttonTime16.Visible = false;
            this.buttonTime16.Click += new System.EventHandler(this.button23_Click);
            // 
            // buttonTime17
            // 
            this.buttonTime17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime17.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime17.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime17.Location = new System.Drawing.Point(979, 221);
            this.buttonTime17.Name = "buttonTime17";
            this.buttonTime17.Size = new System.Drawing.Size(102, 45);
            this.buttonTime17.TabIndex = 191;
            this.buttonTime17.UseVisualStyleBackColor = false;
            this.buttonTime17.Visible = false;
            this.buttonTime17.Click += new System.EventHandler(this.button22_Click);
            // 
            // buttonTime18
            // 
            this.buttonTime18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime18.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime18.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime18.Location = new System.Drawing.Point(1087, 221);
            this.buttonTime18.Name = "buttonTime18";
            this.buttonTime18.Size = new System.Drawing.Size(102, 45);
            this.buttonTime18.TabIndex = 192;
            this.buttonTime18.UseVisualStyleBackColor = false;
            this.buttonTime18.Visible = false;
            this.buttonTime18.Click += new System.EventHandler(this.button21_Click);
            // 
            // buttonTime19
            // 
            this.buttonTime19.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime19.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime19.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime19.Location = new System.Drawing.Point(547, 272);
            this.buttonTime19.Name = "buttonTime19";
            this.buttonTime19.Size = new System.Drawing.Size(102, 45);
            this.buttonTime19.TabIndex = 193;
            this.buttonTime19.UseVisualStyleBackColor = false;
            this.buttonTime19.Visible = false;
            this.buttonTime19.Click += new System.EventHandler(this.button32_Click);
            // 
            // buttonTime20
            // 
            this.buttonTime20.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime20.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime20.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime20.Location = new System.Drawing.Point(655, 272);
            this.buttonTime20.Name = "buttonTime20";
            this.buttonTime20.Size = new System.Drawing.Size(102, 45);
            this.buttonTime20.TabIndex = 194;
            this.buttonTime20.UseVisualStyleBackColor = false;
            this.buttonTime20.Visible = false;
            this.buttonTime20.Click += new System.EventHandler(this.button31_Click);
            // 
            // buttonTime21
            // 
            this.buttonTime21.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime21.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime21.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime21.Location = new System.Drawing.Point(763, 272);
            this.buttonTime21.Name = "buttonTime21";
            this.buttonTime21.Size = new System.Drawing.Size(102, 45);
            this.buttonTime21.TabIndex = 195;
            this.buttonTime21.UseVisualStyleBackColor = false;
            this.buttonTime21.Visible = false;
            this.buttonTime21.Click += new System.EventHandler(this.button30_Click);
            // 
            // buttonTime22
            // 
            this.buttonTime22.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime22.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime22.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime22.Location = new System.Drawing.Point(871, 272);
            this.buttonTime22.Name = "buttonTime22";
            this.buttonTime22.Size = new System.Drawing.Size(102, 45);
            this.buttonTime22.TabIndex = 196;
            this.buttonTime22.UseVisualStyleBackColor = false;
            this.buttonTime22.Visible = false;
            this.buttonTime22.Click += new System.EventHandler(this.button29_Click);
            // 
            // buttonTime23
            // 
            this.buttonTime23.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime23.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime23.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime23.Location = new System.Drawing.Point(979, 272);
            this.buttonTime23.Name = "buttonTime23";
            this.buttonTime23.Size = new System.Drawing.Size(102, 45);
            this.buttonTime23.TabIndex = 197;
            this.buttonTime23.UseVisualStyleBackColor = false;
            this.buttonTime23.Visible = false;
            this.buttonTime23.Click += new System.EventHandler(this.button28_Click);
            // 
            // buttonTime24
            // 
            this.buttonTime24.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime24.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime24.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime24.Location = new System.Drawing.Point(1087, 272);
            this.buttonTime24.Name = "buttonTime24";
            this.buttonTime24.Size = new System.Drawing.Size(102, 45);
            this.buttonTime24.TabIndex = 198;
            this.buttonTime24.UseVisualStyleBackColor = false;
            this.buttonTime24.Visible = false;
            this.buttonTime24.Click += new System.EventHandler(this.button27_Click);
            // 
            // buttonTime25
            // 
            this.buttonTime25.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime25.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime25.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime25.Location = new System.Drawing.Point(547, 323);
            this.buttonTime25.Name = "buttonTime25";
            this.buttonTime25.Size = new System.Drawing.Size(102, 45);
            this.buttonTime25.TabIndex = 199;
            this.buttonTime25.UseVisualStyleBackColor = false;
            this.buttonTime25.Visible = false;
            this.buttonTime25.Click += new System.EventHandler(this.button38_Click);
            // 
            // buttonTime26
            // 
            this.buttonTime26.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime26.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime26.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime26.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime26.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime26.Location = new System.Drawing.Point(655, 323);
            this.buttonTime26.Name = "buttonTime26";
            this.buttonTime26.Size = new System.Drawing.Size(102, 45);
            this.buttonTime26.TabIndex = 200;
            this.buttonTime26.UseVisualStyleBackColor = false;
            this.buttonTime26.Visible = false;
            this.buttonTime26.Click += new System.EventHandler(this.button37_Click);
            // 
            // buttonTime27
            // 
            this.buttonTime27.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime27.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime27.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime27.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime27.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime27.Location = new System.Drawing.Point(763, 323);
            this.buttonTime27.Name = "buttonTime27";
            this.buttonTime27.Size = new System.Drawing.Size(102, 45);
            this.buttonTime27.TabIndex = 201;
            this.buttonTime27.UseVisualStyleBackColor = false;
            this.buttonTime27.Visible = false;
            this.buttonTime27.Click += new System.EventHandler(this.button36_Click);
            // 
            // buttonTime28
            // 
            this.buttonTime28.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime28.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime28.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime28.Location = new System.Drawing.Point(871, 323);
            this.buttonTime28.Name = "buttonTime28";
            this.buttonTime28.Size = new System.Drawing.Size(102, 45);
            this.buttonTime28.TabIndex = 202;
            this.buttonTime28.UseVisualStyleBackColor = false;
            this.buttonTime28.Visible = false;
            this.buttonTime28.Click += new System.EventHandler(this.button35_Click);
            // 
            // buttonTime29
            // 
            this.buttonTime29.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime29.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime29.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime29.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime29.Location = new System.Drawing.Point(979, 323);
            this.buttonTime29.Name = "buttonTime29";
            this.buttonTime29.Size = new System.Drawing.Size(102, 45);
            this.buttonTime29.TabIndex = 203;
            this.buttonTime29.UseVisualStyleBackColor = false;
            this.buttonTime29.Visible = false;
            this.buttonTime29.Click += new System.EventHandler(this.button34_Click);
            // 
            // buttonTime30
            // 
            this.buttonTime30.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonTime30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTime30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTime30.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonTime30.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTime30.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTime30.ForeColor = System.Drawing.Color.DimGray;
            this.buttonTime30.Location = new System.Drawing.Point(1087, 323);
            this.buttonTime30.Name = "buttonTime30";
            this.buttonTime30.Size = new System.Drawing.Size(102, 45);
            this.buttonTime30.TabIndex = 204;
            this.buttonTime30.UseVisualStyleBackColor = false;
            this.buttonTime30.Visible = false;
            this.buttonTime30.Click += new System.EventHandler(this.button33_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.buttonTime30);
            this.panel1.Controls.Add(this.buttonTime29);
            this.panel1.Controls.Add(this.buttonTime28);
            this.panel1.Controls.Add(this.buttonTime27);
            this.panel1.Controls.Add(this.buttonTime26);
            this.panel1.Controls.Add(this.buttonTime25);
            this.panel1.Controls.Add(this.buttonTime24);
            this.panel1.Controls.Add(this.buttonTime23);
            this.panel1.Controls.Add(this.buttonTime22);
            this.panel1.Controls.Add(this.buttonTime21);
            this.panel1.Controls.Add(this.buttonTime20);
            this.panel1.Controls.Add(this.buttonTime19);
            this.panel1.Controls.Add(this.buttonTime18);
            this.panel1.Controls.Add(this.buttonTime17);
            this.panel1.Controls.Add(this.buttonTime16);
            this.panel1.Controls.Add(this.buttonTime15);
            this.panel1.Controls.Add(this.buttonTime14);
            this.panel1.Controls.Add(this.buttonTime13);
            this.panel1.Controls.Add(this.buttonTime12);
            this.panel1.Controls.Add(this.buttonTime11);
            this.panel1.Controls.Add(this.buttonTime10);
            this.panel1.Controls.Add(this.buttonTime9);
            this.panel1.Controls.Add(this.buttonTime8);
            this.panel1.Controls.Add(this.buttonTime7);
            this.panel1.Controls.Add(this.buttonTime6);
            this.panel1.Controls.Add(this.buttonTime5);
            this.panel1.Controls.Add(this.buttonTime4);
            this.panel1.Controls.Add(this.buttonTime3);
            this.panel1.Controls.Add(this.buttonTime2);
            this.panel1.Controls.Add(this.buttonTime1);
            this.panel1.Controls.Add(this.pictureBoxcgv2);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.pictureBoxcgv1);
            this.panel1.Controls.Add(this.buttoncgv);
            this.panel1.Controls.Add(this.buttonNgay7);
            this.panel1.Controls.Add(this.buttonNgay6);
            this.panel1.Controls.Add(this.buttonNgay5);
            this.panel1.Controls.Add(this.buttonNgay4);
            this.panel1.Controls.Add(this.buttonNgay3);
            this.panel1.Controls.Add(this.buttonNgay2);
            this.panel1.Controls.Add(this.buttonNgay1);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Location = new System.Drawing.Point(2, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1229, 392);
            this.panel1.TabIndex = 88;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBoxcgv2
            // 
            this.pictureBoxcgv2.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBoxcgv2.BackgroundImage = global::Cinema.Properties.Resources.chevron1;
            this.pictureBoxcgv2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxcgv2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxcgv2.Location = new System.Drawing.Point(475, 128);
            this.pictureBoxcgv2.Name = "pictureBoxcgv2";
            this.pictureBoxcgv2.Size = new System.Drawing.Size(31, 29);
            this.pictureBoxcgv2.TabIndex = 174;
            this.pictureBoxcgv2.TabStop = false;
            this.pictureBoxcgv2.Visible = false;
            this.pictureBoxcgv2.Click += new System.EventHandler(this.pictureBoxcgv2_Click);
            // 
            // pictureBoxcgv1
            // 
            this.pictureBoxcgv1.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBoxcgv1.BackgroundImage = global::Cinema.Properties.Resources.cgvlogo1;
            this.pictureBoxcgv1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxcgv1.Location = new System.Drawing.Point(40, 118);
            this.pictureBoxcgv1.Name = "pictureBoxcgv1";
            this.pictureBoxcgv1.Size = new System.Drawing.Size(120, 50);
            this.pictureBoxcgv1.TabIndex = 168;
            this.pictureBoxcgv1.TabStop = false;
            this.pictureBoxcgv1.Visible = false;
            // 
            // BuyTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1233, 431);
            this.Controls.Add(this.buttonBuyTicket);
            this.Controls.Add(this.buttonNews);
            this.Controls.Add(this.buttonEvaluate);
            this.Controls.Add(this.buttonCalendar);
            this.Controls.Add(this.buttonInformation);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "BuyTicket";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chọn rạp phim và khung giờ";
            this.Load += new System.EventHandler(this.BuyTicket_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxcgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxcgv1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonBuyTicket;
        private System.Windows.Forms.Button buttonNews;
        private System.Windows.Forms.Button buttonEvaluate;
        private System.Windows.Forms.Button buttonCalendar;
        private System.Windows.Forms.Button buttonInformation;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button buttonNgay1;
        private System.Windows.Forms.Button buttonNgay2;
        private System.Windows.Forms.Button buttonNgay3;
        private System.Windows.Forms.Button buttonNgay4;
        private System.Windows.Forms.Button buttonNgay5;
        private System.Windows.Forms.Button buttonNgay6;
        private System.Windows.Forms.Button buttonNgay7;
        private System.Windows.Forms.Button buttoncgv;
        private System.Windows.Forms.PictureBox pictureBoxcgv1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pictureBoxcgv2;
        private System.Windows.Forms.Button buttonTime1;
        private System.Windows.Forms.Button buttonTime2;
        private System.Windows.Forms.Button buttonTime3;
        private System.Windows.Forms.Button buttonTime4;
        private System.Windows.Forms.Button buttonTime5;
        private System.Windows.Forms.Button buttonTime6;
        private System.Windows.Forms.Button buttonTime7;
        private System.Windows.Forms.Button buttonTime8;
        private System.Windows.Forms.Button buttonTime9;
        private System.Windows.Forms.Button buttonTime10;
        private System.Windows.Forms.Button buttonTime11;
        private System.Windows.Forms.Button buttonTime12;
        private System.Windows.Forms.Button buttonTime13;
        private System.Windows.Forms.Button buttonTime14;
        private System.Windows.Forms.Button buttonTime15;
        private System.Windows.Forms.Button buttonTime16;
        private System.Windows.Forms.Button buttonTime17;
        private System.Windows.Forms.Button buttonTime18;
        private System.Windows.Forms.Button buttonTime19;
        private System.Windows.Forms.Button buttonTime20;
        private System.Windows.Forms.Button buttonTime21;
        private System.Windows.Forms.Button buttonTime22;
        private System.Windows.Forms.Button buttonTime23;
        private System.Windows.Forms.Button buttonTime24;
        private System.Windows.Forms.Button buttonTime25;
        private System.Windows.Forms.Button buttonTime26;
        private System.Windows.Forms.Button buttonTime27;
        private System.Windows.Forms.Button buttonTime28;
        private System.Windows.Forms.Button buttonTime29;
        private System.Windows.Forms.Button buttonTime30;
        private System.Windows.Forms.Panel panel1;
    }
}