﻿
namespace Cinema
{
    partial class Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Information));
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelAge = new System.Windows.Forms.Label();
            this.labelTime = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labelStudio = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelProducer = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelDirector = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelActor = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonBuyTicket2 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBoxPhim = new System.Windows.Forms.PictureBox();
            this.labelContent = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.buttonInformation = new System.Windows.Forms.Button();
            this.buttonCalendar = new System.Windows.Forms.Button();
            this.buttonEvaluate = new System.Windows.Forms.Button();
            this.buttonNews = new System.Windows.Forms.Button();
            this.buttonBuyTicket = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhim)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.labelAge);
            this.panel1.Controls.Add(this.labelTime);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.labelDate);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.labelStudio);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.labelProducer);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.labelDirector);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.labelActor);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.buttonBuyTicket2);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.pictureBoxPhim);
            this.panel1.Controls.Add(this.labelContent);
            this.panel1.Controls.Add(this.labelName);
            this.panel1.Location = new System.Drawing.Point(2, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1229, 392);
            this.panel1.TabIndex = 82;
            // 
            // labelAge
            // 
            this.labelAge.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAge.ForeColor = System.Drawing.Color.White;
            this.labelAge.Location = new System.Drawing.Point(627, 351);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(136, 29);
            this.labelAge.TabIndex = 162;
            this.labelAge.Click += new System.EventHandler(this.labelAge_Click);
            // 
            // labelTime
            // 
            this.labelTime.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.ForeColor = System.Drawing.Color.White;
            this.labelTime.Location = new System.Drawing.Point(427, 351);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(136, 29);
            this.labelTime.TabIndex = 160;
            this.labelTime.Click += new System.EventHandler(this.labelTime_Click);
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(627, 322);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(151, 29);
            this.label16.TabIndex = 161;
            this.label16.Text = "🙎‍ Giới hạn tuổi";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(427, 322);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 29);
            this.label2.TabIndex = 159;
            this.label2.Text = "⏰ Thời lượng";
            // 
            // labelDate
            // 
            this.labelDate.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDate.ForeColor = System.Drawing.Color.White;
            this.labelDate.Location = new System.Drawing.Point(226, 351);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(136, 29);
            this.labelDate.TabIndex = 158;
            this.labelDate.Click += new System.EventHandler(this.labelDate_Click);
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(226, 322);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(136, 29);
            this.label13.TabIndex = 157;
            this.label13.Text = "📅 Khởi chiếu";
            // 
            // labelStudio
            // 
            this.labelStudio.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStudio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelStudio.Location = new System.Drawing.Point(823, 290);
            this.labelStudio.Name = "labelStudio";
            this.labelStudio.Size = new System.Drawing.Size(381, 28);
            this.labelStudio.TabIndex = 156;
            this.labelStudio.Click += new System.EventHandler(this.labelStudio_Click);
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(823, 262);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(381, 28);
            this.label12.TabIndex = 155;
            this.label12.Text = "Vũ trụ điện ảnh";
            // 
            // labelProducer
            // 
            this.labelProducer.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProducer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelProducer.Location = new System.Drawing.Point(823, 234);
            this.labelProducer.Name = "labelProducer";
            this.labelProducer.Size = new System.Drawing.Size(381, 28);
            this.labelProducer.TabIndex = 154;
            this.labelProducer.Click += new System.EventHandler(this.labelProducer_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(823, 206);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(381, 28);
            this.label10.TabIndex = 153;
            this.label10.Text = "Nhà sản xuất";
            // 
            // labelDirector
            // 
            this.labelDirector.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDirector.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelDirector.Location = new System.Drawing.Point(823, 178);
            this.labelDirector.Name = "labelDirector";
            this.labelDirector.Size = new System.Drawing.Size(381, 28);
            this.labelDirector.TabIndex = 152;
            this.labelDirector.Click += new System.EventHandler(this.labelDirector_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(823, 150);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(381, 28);
            this.label8.TabIndex = 151;
            this.label8.Text = "Đạo diễn";
            // 
            // labelActor
            // 
            this.labelActor.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelActor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelActor.Location = new System.Drawing.Point(823, 77);
            this.labelActor.Name = "labelActor";
            this.labelActor.Size = new System.Drawing.Size(381, 73);
            this.labelActor.TabIndex = 150;
            this.labelActor.Click += new System.EventHandler(this.labelActor_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(823, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(381, 28);
            this.label5.TabIndex = 83;
            this.label5.Text = "Diễn viên";
            // 
            // buttonBuyTicket2
            // 
            this.buttonBuyTicket2.BackColor = System.Drawing.Color.Transparent;
            this.buttonBuyTicket2.BackgroundImage = global::Cinema.Properties.Resources.buyticket1;
            this.buttonBuyTicket2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonBuyTicket2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonBuyTicket2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonBuyTicket2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBuyTicket2.ForeColor = System.Drawing.Color.White;
            this.buttonBuyTicket2.Location = new System.Drawing.Point(404, 45);
            this.buttonBuyTicket2.Name = "buttonBuyTicket2";
            this.buttonBuyTicket2.Size = new System.Drawing.Size(77, 32);
            this.buttonBuyTicket2.TabIndex = 149;
            this.buttonBuyTicket2.UseVisualStyleBackColor = false;
            this.buttonBuyTicket2.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = global::Cinema.Properties.Resources.evaluate1;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(307, 45);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 32);
            this.button2.TabIndex = 148;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::Cinema.Properties.Resources.like1;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(230, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 32);
            this.button1.TabIndex = 147;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // pictureBoxPhim
            // 
            this.pictureBoxPhim.BackColor = System.Drawing.Color.White;
            this.pictureBoxPhim.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxPhim.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxPhim.Location = new System.Drawing.Point(10, 12);
            this.pictureBoxPhim.Name = "pictureBoxPhim";
            this.pictureBoxPhim.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxPhim.TabIndex = 73;
            this.pictureBoxPhim.TabStop = false;
            this.pictureBoxPhim.Click += new System.EventHandler(this.pictureBoxPhim_Click);
            // 
            // labelContent
            // 
            this.labelContent.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelContent.ForeColor = System.Drawing.Color.White;
            this.labelContent.Location = new System.Drawing.Point(226, 97);
            this.labelContent.Name = "labelContent";
            this.labelContent.Size = new System.Drawing.Size(591, 215);
            this.labelContent.TabIndex = 81;
            this.labelContent.Click += new System.EventHandler(this.labelContent_Click);
            // 
            // labelName
            // 
            this.labelName.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.White;
            this.labelName.Location = new System.Drawing.Point(224, 12);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(994, 30);
            this.labelName.TabIndex = 78;
            this.labelName.Click += new System.EventHandler(this.labelName_Click);
            // 
            // buttonInformation
            // 
            this.buttonInformation.BackColor = System.Drawing.Color.Salmon;
            this.buttonInformation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonInformation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonInformation.Enabled = false;
            this.buttonInformation.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonInformation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonInformation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonInformation.Location = new System.Drawing.Point(2, 2);
            this.buttonInformation.Name = "buttonInformation";
            this.buttonInformation.Size = new System.Drawing.Size(169, 33);
            this.buttonInformation.TabIndex = 83;
            this.buttonInformation.Text = "Thông tin phim";
            this.buttonInformation.UseVisualStyleBackColor = false;
            this.buttonInformation.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonCalendar
            // 
            this.buttonCalendar.BackColor = System.Drawing.Color.White;
            this.buttonCalendar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonCalendar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCalendar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonCalendar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCalendar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalendar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonCalendar.Location = new System.Drawing.Point(173, 2);
            this.buttonCalendar.Name = "buttonCalendar";
            this.buttonCalendar.Size = new System.Drawing.Size(169, 33);
            this.buttonCalendar.TabIndex = 84;
            this.buttonCalendar.Text = "Lịch chiếu";
            this.buttonCalendar.UseVisualStyleBackColor = false;
            this.buttonCalendar.Click += new System.EventHandler(this.button5_Click);
            // 
            // buttonEvaluate
            // 
            this.buttonEvaluate.BackColor = System.Drawing.Color.White;
            this.buttonEvaluate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonEvaluate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonEvaluate.Enabled = false;
            this.buttonEvaluate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonEvaluate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEvaluate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEvaluate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonEvaluate.Location = new System.Drawing.Point(686, 2);
            this.buttonEvaluate.Name = "buttonEvaluate";
            this.buttonEvaluate.Size = new System.Drawing.Size(169, 33);
            this.buttonEvaluate.TabIndex = 85;
            this.buttonEvaluate.Text = "Đánh giá";
            this.buttonEvaluate.UseVisualStyleBackColor = false;
            this.buttonEvaluate.Click += new System.EventHandler(this.button6_Click);
            // 
            // buttonNews
            // 
            this.buttonNews.BackColor = System.Drawing.Color.White;
            this.buttonNews.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonNews.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNews.Enabled = false;
            this.buttonNews.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonNews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNews.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNews.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonNews.Location = new System.Drawing.Point(515, 2);
            this.buttonNews.Name = "buttonNews";
            this.buttonNews.Size = new System.Drawing.Size(169, 33);
            this.buttonNews.TabIndex = 86;
            this.buttonNews.Text = "Tin tức";
            this.buttonNews.UseVisualStyleBackColor = false;
            this.buttonNews.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonBuyTicket
            // 
            this.buttonBuyTicket.BackColor = System.Drawing.Color.White;
            this.buttonBuyTicket.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonBuyTicket.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonBuyTicket.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonBuyTicket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBuyTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBuyTicket.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonBuyTicket.Location = new System.Drawing.Point(344, 2);
            this.buttonBuyTicket.Name = "buttonBuyTicket";
            this.buttonBuyTicket.Size = new System.Drawing.Size(169, 33);
            this.buttonBuyTicket.TabIndex = 87;
            this.buttonBuyTicket.Text = "Mua vé";
            this.buttonBuyTicket.UseVisualStyleBackColor = false;
            this.buttonBuyTicket.Click += new System.EventHandler(this.button8_Click);
            // 
            // Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1233, 431);
            this.Controls.Add(this.buttonBuyTicket);
            this.Controls.Add(this.buttonNews);
            this.Controls.Add(this.buttonEvaluate);
            this.Controls.Add(this.buttonCalendar);
            this.Controls.Add(this.buttonInformation);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Information";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông tin phim";
            this.Load += new System.EventHandler(this.Information_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhim)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labelStudio;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelProducer;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelDirector;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelActor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonBuyTicket2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBoxPhim;
        private System.Windows.Forms.Label labelContent;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Button buttonInformation;
        private System.Windows.Forms.Button buttonCalendar;
        private System.Windows.Forms.Button buttonEvaluate;
        private System.Windows.Forms.Button buttonNews;
        private System.Windows.Forms.Button buttonBuyTicket;
    }
}