﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class Admin : Form
    {
        public Admin(string user)
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            dataGridViewAccount.DataSource = GetAccount().Tables[0];
            dataGridViewAccount.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewMovie.DataSource = GetMovie().Tables[0];
            dataGridViewMovie.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader;

            dataGridViewBill.DataSource = GetBill().Tables[0];
            dataGridViewBill.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dataGridViewAccount_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        DataSet GetAccount()
        {
            DataSet data = new DataSet();
            string query = "SELECT * FROM ACCOUNT";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataSet GetMovie()
        {
            DataSet data = new DataSet();
            string query = "SELECT ID_MOVIE, NAME_MOVIE, CATEGORY_MOVIE, ACTOR_MOVIE, DIRECTOR_MOVIE, PRODUCER_MOVIE, DATE_MOVIE, TIME_MOVIE, AGE_MOVIE FROM MOVIE";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataSet GetBill()
        {
            DataSet data = new DataSet();
            string query = "SELECT ID_BILL, TOTAL_PRICE, USER_ACCOUNT, NAME_PAYMENT_METHODS FROM BILL, ACCOUNT, PAYMENT_METHODS WHERE ACCOUNT.ID_ACCOUNT=BILL.ID_ACCOUNT AND BILL.ID_PAYMENT_METHODS=PAYMENT_METHODS.ID_PAYMENT_METHODS";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void buttonUpdateBill_Click(object sender, EventArgs e)
        {
            dataGridViewBill.DataSource = GetBill().Tables[0];
            dataGridViewBill.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void textBoxUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewAccount_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBoxUser.Text = dataGridViewAccount.CurrentRow.Cells[1].Value.ToString();
            textBoxPass.Text = dataGridViewAccount.CurrentRow.Cells[2].Value.ToString();
            comboBoxStatus.Text = dataGridViewAccount.CurrentRow.Cells[3].Value.ToString();
        }

        private void buttonAddAccount_Click(object sender, EventArgs e)
        {
            if(CheckAccount().Rows[0][0].ToString() == "1")
            {
                MessageBox.Show("Tài khoản đã tồn tại!");
            }
            else
            {
                AddAccount();
                MessageBox.Show("Thêm tài khoản thành công");
                dataGridViewAccount.DataSource = GetAccount().Tables[0];
                dataGridViewAccount.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
        }

        DataTable GetNumAccount()
        {
            DataTable data = new DataTable();
            string query = "SELECT COUNT (*) FROM ACCOUNT";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }
        DataTable CheckAccount()
        {
            DataTable data = new DataTable();
            string query = "SELECT COUNT (*) FROM ACCOUNT WHERE USER_ACCOUNT='"+textBoxUser.Text+"'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable AddAccount()
        {
            DataTable data = new DataTable();
            string query = "INSERT INTO ACCOUNT(ID_ACCOUNT, USER_ACCOUNT, PASSWORD_ACCOUNT, STATUS_ACCOUNT) VALUES ('"+(Int32.Parse(GetNumAccount().Rows[0][0].ToString())+1)+"','"+textBoxUser.Text+"','"+textBoxPass.Text+"','"+comboBoxStatus.Text+"')";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable UpdateAccount()
        {
            DataTable data = new DataTable();
            string query = "UPDATE ACCOUNT SET PASSWORD_ACCOUNT='" + textBoxPass.Text + "', STATUS_ACCOUNT='" + comboBoxStatus.Text + "' WHERE ID_ACCOUNT='" + GetIdAccount().Rows[0][0].ToString() + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetIdAccount()
        {
            DataTable data = new DataTable();
            string query = "SELECT ID_ACCOUNT FROM ACCOUNT WHERE USER_ACCOUNT='"+textBoxUser.Text+"'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void buttonUpdateAccount_Click(object sender, EventArgs e)
        {
            UpdateAccount();
            MessageBox.Show("Sửa tài khoản thành công");
            dataGridViewAccount.DataSource = GetAccount().Tables[0];
            dataGridViewAccount.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        DataTable DeleteAccount()
        {
            DataTable data = new DataTable();
            string query = "DELETE FROM ACCOUNT WHERE ID_ACCOUNT='"+GetIdAccount().Rows[0][0].ToString()+"'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void buttonDeleteAccount_Click(object sender, EventArgs e)
        {
            DeleteAccount();
            MessageBox.Show("Xóa tài khoản thành công");
            dataGridViewAccount.DataSource = GetAccount().Tables[0];
            dataGridViewAccount.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dataGridViewMovie_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBoxNameMovie.Text = dataGridViewMovie.CurrentRow.Cells[1].Value.ToString();
            textBoxProducer.Text = dataGridViewMovie.CurrentRow.Cells[5].Value.ToString();
            textBoxActor.Text = dataGridViewMovie.CurrentRow.Cells[3].Value.ToString();
            dateTimePickerDate.Text = dataGridViewMovie.CurrentRow.Cells[6].Value.ToString();
            textBoxCategory.Text = dataGridViewMovie.CurrentRow.Cells[2].Value.ToString();
            textBoxAge.Text = dataGridViewMovie.CurrentRow.Cells[8].Value.ToString();
            textBoxDirector.Text = dataGridViewMovie.CurrentRow.Cells[4].Value.ToString();
            textBoxTime.Text = dataGridViewMovie.CurrentRow.Cells[7].Value.ToString();
        }

        private void dataGridViewMovie_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello");
        }

        private void dataGridViewBill_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
