﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class Payment : Form
    {
        string discount1;
        string combo1;
        string user1;
        string showtime1;
        string dayOfWeek1;
        string cinemaPlace1;
        string name1;
        string giaVe1;
        string ghe1;
        string giaCombo1;
        string price1;
        public Payment(string combo, string user, string showtime, string dayOfWeek, string cinemaPlace, string name, string giaVe, string ghe, string giaCombo)
        {
            combo1 = combo;
            user1 = user;
            showtime1 = showtime;
            dayOfWeek1 = dayOfWeek;
            cinemaPlace1 = cinemaPlace;
            name1 = name;
            giaVe1 = giaVe;
            giaCombo1 = giaCombo;
            ghe1 = ghe;
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            double giaVe = double.Parse(labelGiaVe.Text.Replace("đ", ""));
            double giaCombo = double.Parse(labelGiaCombo.Text.Replace("đ", ""));
            double tongGia = giaVe + giaCombo;
            labelTongGia.Text = tongGia.ToString();
            if (textBoxMaGiamGia.Text.Length == 0)
            {
                labelTongGia.Text = tongGia.ToString();
            }
            if (textBoxMaGiamGia.Text == "cuoituangiamgia" || textBoxMaGiamGia.Text == "baconsoi")
            {
                tongGia = tongGia * 0.9;
                labelTongGia.Text = tongGia.ToString();
            }
            discount1 = textBoxMaGiamGia.Text;
        }

        private void buttonXacNhan_Click(object sender, EventArgs e)
        {
            
                price1 = labelTongGia.Text;
                SelectPayment sp = new SelectPayment(combo1, ghe1, discount1, user1, price1);
                this.Hide();
                sp.ShowDialog();
                this.Show();
            
        }

        private void labelTongGia_Click(object sender, EventArgs e)
        {
            
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            labelUser.Text = user1;
            labelDayOfWeek.Text = showtime1 + " - " + dayOfWeek1;
            labelPlace.Text = cinemaPlace1;
            labelName.Text = name1;
            labelGiaVe.Text = giaVe1;
            labelGiaCombo.Text = giaCombo1;
            labelGhe.Text = ghe1;
            double giaVe = double.Parse(labelGiaVe.Text.Replace("đ", ""));
            double giaCombo = double.Parse(labelGiaCombo.Text.Replace("đ", ""));
            double tongGia = giaVe + giaCombo;
            labelTongGia.Text = tongGia.ToString();
            if (textBoxMaGiamGia.Text.Length == 0)
            {
                labelTongGia.Text = tongGia.ToString();
            }
            if (textBoxMaGiamGia.Text == "cuoituangiamgia" || textBoxMaGiamGia.Text == "baconsoi")
            {
                tongGia = tongGia * 0.9;
                labelTongGia.Text = tongGia.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(ghe1 + "|" + combo1 + "|" + discount1);
        }
    }
}
