﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class ChooseSeat : Form
    {
        string Giave1;
        string ghe1;
        string user1;
        string dayOfWeek1;
        string cinemaPlace1;
        string pic1;
        string name1;
        string category1;
        string content1;
        string actor1;
        string director1;
        string producer1;
        string studio1;
        string date1;
        string time1;
        string age1;
        string showtime1;
        public ChooseSeat(string dayOfWeek, string cinemaPlace, string showtime, string user, string pic, string name, string category, string content, string actor, string director, string producer, string studio, string date, string time, string age)
        {
            user1 = user;
            dayOfWeek1 = dayOfWeek;
            cinemaPlace1 = cinemaPlace;
            pic1 = pic;
            name1 = name;
            category1 = category;
            content1 = content;
            actor1 = actor;
            director1 = director;
            producer1 = producer;
            studio1 = studio;
            date1 = date;
            time1 = time;
            age1 = age;
            showtime1 = showtime;
            InitializeComponent();
        }

        private void A1_Click(object sender, EventArgs e)
        {
            string s = A1.Text;
            if (A1.BackColor == Color.SlateBlue)
            {
                A1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString()+"đ";
            }
            else if (A1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s+", ", "");
                A1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString()+"đ";
            }
        }

        private void A2_Click(object sender, EventArgs e)
        {
            string s = A2.Text;
            if (A2.BackColor == Color.SlateBlue)
            {
                A2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A3_Click(object sender, EventArgs e)
        {
            string s = A3.Text;
            if (A3.BackColor == Color.SlateBlue)
            {
                A3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A4_Click(object sender, EventArgs e)
        {
            string s = A4.Text;
            if (A4.BackColor == Color.SlateBlue)
            {
                A4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A5_Click(object sender, EventArgs e)
        {
            string s = A5.Text;
            if (A5.BackColor == Color.SlateBlue)
            {
                A5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A6_Click(object sender, EventArgs e)
        {
            string s = A6.Text;
            if (A6.BackColor == Color.SlateBlue)
            {
                A6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A7_Click(object sender, EventArgs e)
        {
            string s = A7.Text;
            if (A7.BackColor == Color.SlateBlue)
            {
                A7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A8_Click(object sender, EventArgs e)
        {
            string s = A8.Text;
            if (A8.BackColor == Color.SlateBlue)
            {
                A8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A9_Click(object sender, EventArgs e)
        {
            string s = A9.Text;
            if (A9.BackColor == Color.SlateBlue)
            {
                A9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A10_Click(object sender, EventArgs e)
        {
            string s = A10.Text;
            if (A10.BackColor == Color.SlateBlue)
            {
                A10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A11_Click(object sender, EventArgs e)
        {
            string s = A11.Text;
            if (A11.BackColor == Color.SlateBlue)
            {
                A11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A12_Click(object sender, EventArgs e)
        {
            string s = A12.Text;
            if (A12.BackColor == Color.SlateBlue)
            {
                A12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A13_Click(object sender, EventArgs e)
        {
            string s = A13.Text;
            if (A13.BackColor == Color.SlateBlue)
            {
                A13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A14_Click(object sender, EventArgs e)
        {
            string s = A14.Text;
            if (A14.BackColor == Color.SlateBlue)
            {
                A14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A15_Click(object sender, EventArgs e)
        {
            string s = A15.Text;
            if (A15.BackColor == Color.SlateBlue)
            {
                A15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A16_Click(object sender, EventArgs e)
        {
            string s = A16.Text;
            if (A16.BackColor == Color.SlateBlue)
            {
                A16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A17_Click(object sender, EventArgs e)
        {
            string s = A17.Text;
            if (A17.BackColor == Color.SlateBlue)
            {
                A17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A18_Click(object sender, EventArgs e)
        {
            string s = A18.Text;
            if (A18.BackColor == Color.SlateBlue)
            {
                A18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A19_Click(object sender, EventArgs e)
        {
            string s = A19.Text;
            if (A19.BackColor == Color.SlateBlue)
            {
                A19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void A20_Click(object sender, EventArgs e)
        {
            string s = A20.Text;
            if (A20.BackColor == Color.SlateBlue)
            {
                A20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (A20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                A20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void ChooseSeat_Load(object sender, EventArgs e)
        {
            labelTime.Text = showtime1;
            labelName.Text = name1;
            
                int num = Int32.Parse(GetNumSeatBooked().Rows[0][0].ToString());
                for (int j = 0; j < num; j++)
                {
                    if (GetSeatBooked().Rows[j][0].ToString() == A1.Text)
                    {
                        A1.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A2.Text)
                    {
                        A2.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A3.Text)
                    {
                        A3.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A4.Text)
                    {
                        A4.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A5.Text)
                    {
                        A5.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A6.Text)
                    {
                        A6.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A7.Text)
                    {
                        A7.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A8.Text)
                    {
                        A8.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A9.Text)
                    {
                        A9.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A10.Text)
                    {
                        A10.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A11.Text)
                    {
                        A11.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A12.Text)
                    {
                        A12.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A13.Text)
                    {
                        A13.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A14.Text)
                    {
                        A14.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A15.Text)
                    {
                        A15.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A16.Text)
                    {
                        A16.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A17.Text)
                    {
                        A17.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A18.Text)
                    {
                        A18.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A19.Text)
                    {
                        A19.BackColor = Color.Black;
                    }
                    if (GetSeatBooked().Rows[j][0].ToString() == A20.Text)
                    {
                        A20.BackColor = Color.Black;
                    }
                }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ghe1 = labelSeat.Text;
            Giave1 = labelGiaGhe.Text;
            if (Int32.Parse(labelGiaGhe.Text.Replace("đ","")) == 0)
            {
                MessageBox.Show("Quý khách vui lòng chọn số ghế tối thiểu là 1.");
            }
            else
            {
                ChooseDrinks choosedrinks = new ChooseDrinks(user1, showtime1, dayOfWeek1, cinemaPlace1, name1, Giave1, ghe1);
                choosedrinks.ShowDialog();
                this.Show();
            }
        }

        private void labelMoney_Click(object sender, EventArgs e)
        {
            
        }

        private void B1_Click(object sender, EventArgs e)
        {
            string s = B1.Text;
            if (B1.BackColor == Color.SlateBlue)
            {
                B1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B2_Click(object sender, EventArgs e)
        {
            string s = B2.Text;
            if (B2.BackColor == Color.SlateBlue)
            {
                B2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B3_Click(object sender, EventArgs e)
        {
            string s = B3.Text;
            if (B3.BackColor == Color.SlateBlue)
            {
                B3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B4_Click(object sender, EventArgs e)
        {
            string s = B4.Text;
            if (B4.BackColor == Color.SlateBlue)
            {
                B4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B5_Click(object sender, EventArgs e)
        {
            string s = B5.Text;
            if (B5.BackColor == Color.SlateBlue)
            {
                B5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B6_Click(object sender, EventArgs e)
        {
            string s = B6.Text;
            if (B6.BackColor == Color.SlateBlue)
            {
                B6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B7_Click(object sender, EventArgs e)
        {
            string s = B7.Text;
            if (B7.BackColor == Color.SlateBlue)
            {
                B7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B8_Click(object sender, EventArgs e)
        {
            string s = B8.Text;
            if (B8.BackColor == Color.SlateBlue)
            {
                B8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B9_Click(object sender, EventArgs e)
        {
            string s = B9.Text;
            if (B9.BackColor == Color.SlateBlue)
            {
                B9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B10_Click(object sender, EventArgs e)
        {
            string s = B10.Text;
            if (B10.BackColor == Color.SlateBlue)
            {
                B10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B11_Click(object sender, EventArgs e)
        {
            string s = B11.Text;
            if (B11.BackColor == Color.SlateBlue)
            {
                B11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B12_Click(object sender, EventArgs e)
        {
            string s = B12.Text;
            if (B12.BackColor == Color.SlateBlue)
            {
                B12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B13_Click(object sender, EventArgs e)
        {
            string s = B13.Text;
            if (B13.BackColor == Color.SlateBlue)
            {
                B13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B14_Click(object sender, EventArgs e)
        {
            string s = B14.Text;
            if (B14.BackColor == Color.SlateBlue)
            {
                B14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B15_Click(object sender, EventArgs e)
        {
            string s = B15.Text;
            if (B15.BackColor == Color.SlateBlue)
            {
                B15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B16_Click(object sender, EventArgs e)
        {
            string s = B16.Text;
            if (B16.BackColor == Color.SlateBlue)
            {
                B16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B17_Click(object sender, EventArgs e)
        {
            string s = B17.Text;
            if (B17.BackColor == Color.SlateBlue)
            {
                B17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B18_Click(object sender, EventArgs e)
        {
            string s = B18.Text;
            if (B18.BackColor == Color.SlateBlue)
            {
                B18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B19_Click(object sender, EventArgs e)
        {
            string s = B19.Text;
            if (B19.BackColor == Color.SlateBlue)
            {
                B19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void B20_Click(object sender, EventArgs e)
        {
            string s = B20.Text;
            if (B20.BackColor == Color.SlateBlue)
            {
                B20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (B20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                B20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C1_Click(object sender, EventArgs e)
        {
            string s = C1.Text;
            if (C1.BackColor == Color.SlateBlue)
            {
                C1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C2_Click(object sender, EventArgs e)
        {
            string s = C2.Text;
            if (C2.BackColor == Color.SlateBlue)
            {
                C2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C3_Click(object sender, EventArgs e)
        {
            string s = C3.Text;
            if (C3.BackColor == Color.SlateBlue)
            {
                C3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C4_Click(object sender, EventArgs e)
        {
            string s = C4.Text;
            if (C4.BackColor == Color.SlateBlue)
            {
                C4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C5_Click(object sender, EventArgs e)
        {
            string s = C5.Text;
            if (C5.BackColor == Color.SlateBlue)
            {
                C5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C6_Click(object sender, EventArgs e)
        {
            string s = C6.Text;
            if (C6.BackColor == Color.SlateBlue)
            {
                C6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C7_Click(object sender, EventArgs e)
        {
            string s = C7.Text;
            if (C7.BackColor == Color.SlateBlue)
            {
                C7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C8_Click(object sender, EventArgs e)
        {
            string s = C8.Text;
            if (C8.BackColor == Color.SlateBlue)
            {
                C8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C9_Click(object sender, EventArgs e)
        {
            string s = C9.Text;
            if (C9.BackColor == Color.SlateBlue)
            {
                C9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C10_Click(object sender, EventArgs e)
        {
            string s = C10.Text;
            if (C10.BackColor == Color.SlateBlue)
            {
                C10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C11_Click(object sender, EventArgs e)
        {
            string s = C11.Text;
            if (C11.BackColor == Color.SlateBlue)
            {
                C11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C12_Click(object sender, EventArgs e)
        {
            string s = C12.Text;
            if (C12.BackColor == Color.SlateBlue)
            {
                C12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C13_Click(object sender, EventArgs e)
        {
            string s = C13.Text;
            if (C13.BackColor == Color.SlateBlue)
            {
                C13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C14_Click(object sender, EventArgs e)
        {
            string s = C14.Text;
            if (C14.BackColor == Color.SlateBlue)
            {
                C14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C15_Click(object sender, EventArgs e)
        {
            string s = C15.Text;
            if (C15.BackColor == Color.SlateBlue)
            {
                C15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C16_Click(object sender, EventArgs e)
        {
            string s = C16.Text;
            if (C16.BackColor == Color.SlateBlue)
            {
                C16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C17_Click(object sender, EventArgs e)
        {
            string s = C17.Text;
            if (C17.BackColor == Color.SlateBlue)
            {
                C17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C18_Click(object sender, EventArgs e)
        {
            string s = C18.Text;
            if (C18.BackColor == Color.SlateBlue)
            {
                C18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C19_Click(object sender, EventArgs e)
        {
            string s = C19.Text;
            if (C19.BackColor == Color.SlateBlue)
            {
                C19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void C20_Click(object sender, EventArgs e)
        {
            string s = C20.Text;
            if (C20.BackColor == Color.SlateBlue)
            {
                C20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (C20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                C20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D1_Click(object sender, EventArgs e)
        {
            string s = D1.Text;
            if (D1.BackColor == Color.SlateBlue)
            {
                D1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D2_Click(object sender, EventArgs e)
        {
            string s = D2.Text;
            if (D2.BackColor == Color.SlateBlue)
            {
                D2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D3_Click(object sender, EventArgs e)
        {
            string s = D3.Text;
            if (D3.BackColor == Color.SlateBlue)
            {
                D3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D4_Click(object sender, EventArgs e)
        {
            string s = D4.Text;
            if (D4.BackColor == Color.SlateBlue)
            {
                D4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D5_Click(object sender, EventArgs e)
        {
            string s = D5.Text;
            if (D5.BackColor == Color.SlateBlue)
            {
                D5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D6_Click(object sender, EventArgs e)
        {
            string s = D6.Text;
            if (D6.BackColor == Color.SlateBlue)
            {
                D6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D7_Click(object sender, EventArgs e)
        {
            string s = D7.Text;
            if (D7.BackColor == Color.SlateBlue)
            {
                D7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D8_Click(object sender, EventArgs e)
        {
            string s = D8.Text;
            if (D8.BackColor == Color.SlateBlue)
            {
                D8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D9_Click(object sender, EventArgs e)
        {
            string s = D9.Text;
            if (D9.BackColor == Color.SlateBlue)
            {
                D9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D10_Click(object sender, EventArgs e)
        {
            string s = D10.Text;
            if (D10.BackColor == Color.SlateBlue)
            {
                D10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D11_Click(object sender, EventArgs e)
        {
            string s = D11.Text;
            if (D11.BackColor == Color.SlateBlue)
            {
                D11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D12_Click(object sender, EventArgs e)
        {
            string s = D12.Text;
            if (D12.BackColor == Color.SlateBlue)
            {
                D12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D13_Click(object sender, EventArgs e)
        {
            string s = D13.Text;
            if (D13.BackColor == Color.SlateBlue)
            {
                D13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D14_Click(object sender, EventArgs e)
        {
            string s = D14.Text;
            if (D14.BackColor == Color.SlateBlue)
            {
                D14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D15_Click(object sender, EventArgs e)
        {
            string s = D15.Text;
            if (D15.BackColor == Color.SlateBlue)
            {
                D15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D16_Click(object sender, EventArgs e)
        {
            string s = D16.Text;
            if (D16.BackColor == Color.SlateBlue)
            {
                D16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D17_Click(object sender, EventArgs e)
        {
            string s = D17.Text;
            if (D17.BackColor == Color.SlateBlue)
            {
                D17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D18_Click(object sender, EventArgs e)
        {
            string s = D18.Text;
            if (D18.BackColor == Color.SlateBlue)
            {
                D18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D19_Click(object sender, EventArgs e)
        {
            string s = D19.Text;
            if (D19.BackColor == Color.SlateBlue)
            {
                D19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void D20_Click(object sender, EventArgs e)
        {
            string s = D20.Text;
            if (D20.BackColor == Color.SlateBlue)
            {
                D20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (D20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                D20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E1_Click(object sender, EventArgs e)
        {
            string s = E1.Text;
            if (E1.BackColor == Color.SlateBlue)
            {
                E1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E2_Click(object sender, EventArgs e)
        {
            string s = E2.Text;
            if (E2.BackColor == Color.SlateBlue)
            {
                E2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E3_Click(object sender, EventArgs e)
        {
            string s = E3.Text;
            if (E3.BackColor == Color.SlateBlue)
            {
                E3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E4_Click(object sender, EventArgs e)
        {
            string s = E4.Text;
            if (E4.BackColor == Color.SlateBlue)
            {
                E4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E5_Click(object sender, EventArgs e)
        {
            string s = E5.Text;
            if (E5.BackColor == Color.SlateBlue)
            {
                E5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E6_Click(object sender, EventArgs e)
        {
            string s = E6.Text;
            if (E6.BackColor == Color.SlateBlue)
            {
                E6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E7_Click(object sender, EventArgs e)
        {
            string s = E7.Text;
            if (E7.BackColor == Color.SlateBlue)
            {
                E7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E8_Click(object sender, EventArgs e)
        {
            string s = E8.Text;
            if (E8.BackColor == Color.SlateBlue)
            {
                E8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E9_Click(object sender, EventArgs e)
        {
            string s = E9.Text;
            if (E9.BackColor == Color.SlateBlue)
            {
                E9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E10_Click(object sender, EventArgs e)
        {
            string s = E10.Text;
            if (E10.BackColor == Color.SlateBlue)
            {
                E10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E11_Click(object sender, EventArgs e)
        {
            string s = E11.Text;
            if (E11.BackColor == Color.SlateBlue)
            {
                E11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E12_Click(object sender, EventArgs e)
        {
            string s = E12.Text;
            if (E12.BackColor == Color.SlateBlue)
            {
                E12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E13_Click(object sender, EventArgs e)
        {
            string s = E13.Text;
            if (E13.BackColor == Color.SlateBlue)
            {
                E13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E14_Click(object sender, EventArgs e)
        {
            string s = E14.Text;
            if (E14.BackColor == Color.SlateBlue)
            {
                E14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E15_Click(object sender, EventArgs e)
        {
            string s = E15.Text;
            if (E15.BackColor == Color.SlateBlue)
            {
                E15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E16_Click(object sender, EventArgs e)
        {
            string s = E16.Text;
            if (E16.BackColor == Color.SlateBlue)
            {
                E16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E17_Click(object sender, EventArgs e)
        {
            string s = E17.Text;
            if (E17.BackColor == Color.SlateBlue)
            {
                E17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E18_Click(object sender, EventArgs e)
        {
            string s = E18.Text;
            if (E18.BackColor == Color.SlateBlue)
            {
                E18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E19_Click(object sender, EventArgs e)
        {
            string s = E19.Text;
            if (E19.BackColor == Color.SlateBlue)
            {
                E19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void E20_Click(object sender, EventArgs e)
        {
            string s = E20.Text;
            if (E20.BackColor == Color.SlateBlue)
            {
                E20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (E20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                E20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F1_Click(object sender, EventArgs e)
        {
            string s = F1.Text;
            if (F1.BackColor == Color.SlateBlue)
            {
                F1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F2_Click(object sender, EventArgs e)
        {
            string s = F2.Text;
            if (F2.BackColor == Color.SlateBlue)
            {
                F2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F3_Click(object sender, EventArgs e)
        {
            string s = F3.Text;
            if (F3.BackColor == Color.SlateBlue)
            {
                F3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F4_Click(object sender, EventArgs e)
        {
            string s = F4.Text;
            if (F4.BackColor == Color.SlateBlue)
            {
                F4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F5_Click(object sender, EventArgs e)
        {
            string s = F5.Text;
            if (F5.BackColor == Color.SlateBlue)
            {
                F5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F6_Click(object sender, EventArgs e)
        {
            string s = F6.Text;
            if (F6.BackColor == Color.SlateBlue)
            {
                F6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F7_Click(object sender, EventArgs e)
        {
            string s = F7.Text;
            if (F7.BackColor == Color.SlateBlue)
            {
                F7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F8_Click(object sender, EventArgs e)
        {
            string s = F8.Text;
            if (F8.BackColor == Color.SlateBlue)
            {
                F8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F9_Click(object sender, EventArgs e)
        {
            string s = F9.Text;
            if (F9.BackColor == Color.SlateBlue)
            {
                F9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F10_Click(object sender, EventArgs e)
        {
            string s = F10.Text;
            if (F10.BackColor == Color.SlateBlue)
            {
                F10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F11_Click(object sender, EventArgs e)
        {
            string s = F11.Text;
            if (F11.BackColor == Color.SlateBlue)
            {
                F11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F12_Click(object sender, EventArgs e)
        {
            string s = F12.Text;
            if (F12.BackColor == Color.SlateBlue)
            {
                F12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F13_Click(object sender, EventArgs e)
        {
            string s = F13.Text;
            if (F13.BackColor == Color.SlateBlue)
            {
                F13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F14_Click(object sender, EventArgs e)
        {
            string s = F14.Text;
            if (F14.BackColor == Color.SlateBlue)
            {
                F14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F15_Click(object sender, EventArgs e)
        {
            string s = F15.Text;
            if (F15.BackColor == Color.SlateBlue)
            {
                F15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F16_Click(object sender, EventArgs e)
        {
            string s = F16.Text;
            if (F16.BackColor == Color.SlateBlue)
            {
                F16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F17_Click(object sender, EventArgs e)
        {
            string s = F17.Text;
            if (F17.BackColor == Color.SlateBlue)
            {
                F17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F18_Click(object sender, EventArgs e)
        {
            string s = F18.Text;
            if (F18.BackColor == Color.SlateBlue)
            {
                F18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F19_Click(object sender, EventArgs e)
        {
            string s = F19.Text;
            if (F19.BackColor == Color.SlateBlue)
            {
                F19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void F20_Click(object sender, EventArgs e)
        {
            string s = F20.Text;
            if (F20.BackColor == Color.SlateBlue)
            {
                F20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (F20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                F20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G1_Click(object sender, EventArgs e)
        {
            string s = G1.Text;
            if (G1.BackColor == Color.SlateBlue)
            {
                G1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G2_Click(object sender, EventArgs e)
        {
            string s = G2.Text;
            if (G2.BackColor == Color.SlateBlue)
            {
                G2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G3_Click(object sender, EventArgs e)
        {
            string s = G3.Text;
            if (G3.BackColor == Color.SlateBlue)
            {
                G3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G4_Click(object sender, EventArgs e)
        {
            string s = G4.Text;
            if (G4.BackColor == Color.SlateBlue)
            {
                G4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G5_Click(object sender, EventArgs e)
        {
            string s = G5.Text;
            if (G5.BackColor == Color.SlateBlue)
            {
                G5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G6_Click(object sender, EventArgs e)
        {
            string s = G6.Text;
            if (G6.BackColor == Color.SlateBlue)
            {
                G6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G7_Click(object sender, EventArgs e)
        {
            string s = G7.Text;
            if (G7.BackColor == Color.SlateBlue)
            {
                G7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G8_Click(object sender, EventArgs e)
        {
            string s = G8.Text;
            if (G8.BackColor == Color.SlateBlue)
            {
                G8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G9_Click(object sender, EventArgs e)
        {
            string s = G9.Text;
            if (G9.BackColor == Color.SlateBlue)
            {
                G9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G10_Click(object sender, EventArgs e)
        {
            string s = G10.Text;
            if (G10.BackColor == Color.SlateBlue)
            {
                G10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G11_Click(object sender, EventArgs e)
        {
            string s = G11.Text;
            if (G11.BackColor == Color.SlateBlue)
            {
                G11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G12_Click(object sender, EventArgs e)
        {
            string s = G12.Text;
            if (G12.BackColor == Color.SlateBlue)
            {
                G12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G13_Click(object sender, EventArgs e)
        {
            string s = G13.Text;
            if (G13.BackColor == Color.SlateBlue)
            {
                G13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G14_Click(object sender, EventArgs e)
        {
            string s = G14.Text;
            if (G14.BackColor == Color.SlateBlue)
            {
                G14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G15_Click(object sender, EventArgs e)
        {
            string s = G15.Text;
            if (G15.BackColor == Color.SlateBlue)
            {
                G15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G16_Click(object sender, EventArgs e)
        {
            string s = G16.Text;
            if (G16.BackColor == Color.SlateBlue)
            {
                G16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G17_Click(object sender, EventArgs e)
        {
            string s = G17.Text;
            if (G17.BackColor == Color.SlateBlue)
            {
                G17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G18_Click(object sender, EventArgs e)
        {
            string s = G18.Text;
            if (G18.BackColor == Color.SlateBlue)
            {
                G18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G19_Click(object sender, EventArgs e)
        {
            string s = G19.Text;
            if (G19.BackColor == Color.SlateBlue)
            {
                G19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void G20_Click(object sender, EventArgs e)
        {
            string s = G20.Text;
            if (G20.BackColor == Color.SlateBlue)
            {
                G20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (G20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                G20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H1_Click(object sender, EventArgs e)
        {
            string s = H1.Text;
            if (H1.BackColor == Color.SlateBlue)
            {
                H1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H2_Click(object sender, EventArgs e)
        {
            string s = H2.Text;
            if (H2.BackColor == Color.SlateBlue)
            {
                H2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H3_Click(object sender, EventArgs e)
        {
            string s = H3.Text;
            if (H3.BackColor == Color.SlateBlue)
            {
                H3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H4_Click(object sender, EventArgs e)
        {
            string s = H4.Text;
            if (H4.BackColor == Color.SlateBlue)
            {
                H4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H5_Click(object sender, EventArgs e)
        {
            string s = H5.Text;
            if (H5.BackColor == Color.SlateBlue)
            {
                H5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H6_Click(object sender, EventArgs e)
        {
            string s = H6.Text;
            if (H6.BackColor == Color.SlateBlue)
            {
                H6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H7_Click(object sender, EventArgs e)
        {
            string s = H7.Text;
            if (H7.BackColor == Color.SlateBlue)
            {
                H7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H8_Click(object sender, EventArgs e)
        {
            string s = H8.Text;
            if (H8.BackColor == Color.SlateBlue)
            {
                H8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H9_Click(object sender, EventArgs e)
        {
            string s = H9.Text;
            if (H9.BackColor == Color.SlateBlue)
            {
                H9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H10_Click(object sender, EventArgs e)
        {
            string s = H10.Text;
            if (H10.BackColor == Color.SlateBlue)
            {
                H10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H11_Click(object sender, EventArgs e)
        {
            string s = H11.Text;
            if (H11.BackColor == Color.SlateBlue)
            {
                H11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H12_Click(object sender, EventArgs e)
        {
            string s = H12.Text;
            if (H12.BackColor == Color.SlateBlue)
            {
                H12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H13_Click(object sender, EventArgs e)
        {
            string s = H13.Text;
            if (H13.BackColor == Color.SlateBlue)
            {
                H13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H14_Click(object sender, EventArgs e)
        {
            string s = H14.Text;
            if (H14.BackColor == Color.SlateBlue)
            {
                H14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H15_Click(object sender, EventArgs e)
        {
            string s = H15.Text;
            if (H15.BackColor == Color.SlateBlue)
            {
                H15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H16_Click(object sender, EventArgs e)
        {
            string s = H16.Text;
            if (H16.BackColor == Color.SlateBlue)
            {
                H16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H17_Click(object sender, EventArgs e)
        {
            string s = H17.Text;
            if (H17.BackColor == Color.SlateBlue)
            {
                H17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H18_Click(object sender, EventArgs e)
        {
            string s = H18.Text;
            if (H18.BackColor == Color.SlateBlue)
            {
                H18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H19_Click(object sender, EventArgs e)
        {
            string s = H19.Text;
            if (H19.BackColor == Color.SlateBlue)
            {
                H19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void H20_Click(object sender, EventArgs e)
        {
            string s = H20.Text;
            if (H20.BackColor == Color.SlateBlue)
            {
                H20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (H20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                H20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I1_Click(object sender, EventArgs e)
        {
            string s = I1.Text;
            if (I1.BackColor == Color.SlateBlue)
            {
                I1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I2_Click(object sender, EventArgs e)
        {
            string s = I2.Text;
            if (I2.BackColor == Color.SlateBlue)
            {
                I2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I3_Click(object sender, EventArgs e)
        {
            string s = I3.Text;
            if (I3.BackColor == Color.SlateBlue)
            {
                I3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I4_Click(object sender, EventArgs e)
        {
            string s = I4.Text;
            if (I4.BackColor == Color.SlateBlue)
            {
                I4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I5_Click(object sender, EventArgs e)
        {
            string s = I5.Text;
            if (I5.BackColor == Color.SlateBlue)
            {
                I5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I6_Click(object sender, EventArgs e)
        {
            string s = I6.Text;
            if (I6.BackColor == Color.SlateBlue)
            {
                I6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I7_Click(object sender, EventArgs e)
        {
            string s = I7.Text;
            if (I7.BackColor == Color.SlateBlue)
            {
                I7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I8_Click(object sender, EventArgs e)
        {
            string s = I8.Text;
            if (I8.BackColor == Color.SlateBlue)
            {
                I8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I9_Click(object sender, EventArgs e)
        {
            string s = I9.Text;
            if (I9.BackColor == Color.SlateBlue)
            {
                I9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I10_Click(object sender, EventArgs e)
        {
            string s = I10.Text;
            if (I10.BackColor == Color.SlateBlue)
            {
                I10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I11_Click(object sender, EventArgs e)
        {
            string s = I11.Text;
            if (I11.BackColor == Color.SlateBlue)
            {
                I11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I12_Click(object sender, EventArgs e)
        {
            string s = I12.Text;
            if (I12.BackColor == Color.SlateBlue)
            {
                I12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I13_Click(object sender, EventArgs e)
        {
            string s = I13.Text;
            if (I13.BackColor == Color.SlateBlue)
            {
                I13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I14_Click(object sender, EventArgs e)
        {
            string s = I14.Text;
            if (I14.BackColor == Color.SlateBlue)
            {
                I14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I15_Click(object sender, EventArgs e)
        {
            string s = I15.Text;
            if (I15.BackColor == Color.SlateBlue)
            {
                I15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I16_Click(object sender, EventArgs e)
        {
            string s = I16.Text;
            if (I16.BackColor == Color.SlateBlue)
            {
                I16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I17_Click(object sender, EventArgs e)
        {
            string s = I17.Text;
            if (I17.BackColor == Color.SlateBlue)
            {
                I17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I18_Click(object sender, EventArgs e)
        {
            string s = I18.Text;
            if (I18.BackColor == Color.SlateBlue)
            {
                I18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I19_Click(object sender, EventArgs e)
        {
            string s = I19.Text;
            if (I19.BackColor == Color.SlateBlue)
            {
                I19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void I20_Click(object sender, EventArgs e)
        {
            string s = I20.Text;
            if (I20.BackColor == Color.SlateBlue)
            {
                I20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (I20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                I20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J1_Click(object sender, EventArgs e)
        {
            string s = J1.Text;
            if (J1.BackColor == Color.SlateBlue)
            {
                J1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J2_Click(object sender, EventArgs e)
        {
            string s = J2.Text;
            if (J2.BackColor == Color.SlateBlue)
            {
                J2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J3_Click(object sender, EventArgs e)
        {
            string s = J3.Text;
            if (J3.BackColor == Color.SlateBlue)
            {
                J3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J4_Click(object sender, EventArgs e)
        {
            string s = J4.Text;
            if (J4.BackColor == Color.SlateBlue)
            {
                J4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J5_Click(object sender, EventArgs e)
        {
            string s = J5.Text;
            if (J5.BackColor == Color.SlateBlue)
            {
                J5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J6_Click(object sender, EventArgs e)
        {
            string s = J6.Text;
            if (J6.BackColor == Color.SlateBlue)
            {
                J6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J7_Click(object sender, EventArgs e)
        {
            string s = J7.Text;
            if (J7.BackColor == Color.SlateBlue)
            {
                J7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J8_Click(object sender, EventArgs e)
        {
            string s = J8.Text;
            if (J8.BackColor == Color.SlateBlue)
            {
                J8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J9_Click(object sender, EventArgs e)
        {
            string s = J9.Text;
            if (J9.BackColor == Color.SlateBlue)
            {
                J9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J10_Click(object sender, EventArgs e)
        {
            string s = J10.Text;
            if (J10.BackColor == Color.SlateBlue)
            {
                J10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J11_Click(object sender, EventArgs e)
        {
            string s = J11.Text;
            if (J11.BackColor == Color.SlateBlue)
            {
                J11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J12_Click(object sender, EventArgs e)
        {
            string s = J12.Text;
            if (J12.BackColor == Color.SlateBlue)
            {
                J12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J13_Click(object sender, EventArgs e)
        {
            string s = J13.Text;
            if (J13.BackColor == Color.SlateBlue)
            {
                J13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J14_Click(object sender, EventArgs e)
        {
            string s = J14.Text;
            if (J14.BackColor == Color.SlateBlue)
            {
                J14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J15_Click(object sender, EventArgs e)
        {
            string s = J15.Text;
            if (J15.BackColor == Color.SlateBlue)
            {
                J15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J16_Click(object sender, EventArgs e)
        {
            string s = J16.Text;
            if (J16.BackColor == Color.SlateBlue)
            {
                J16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J17_Click(object sender, EventArgs e)
        {
            string s = J17.Text;
            if (J17.BackColor == Color.SlateBlue)
            {
                J17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J18_Click(object sender, EventArgs e)
        {
            string s = J18.Text;
            if (J18.BackColor == Color.SlateBlue)
            {
                J18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J19_Click(object sender, EventArgs e)
        {
            string s = J19.Text;
            if (J19.BackColor == Color.SlateBlue)
            {
                J19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void J20_Click(object sender, EventArgs e)
        {
            string s = J20.Text;
            if (J20.BackColor == Color.SlateBlue)
            {
                J20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (J20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                J20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K1_Click(object sender, EventArgs e)
        {
            string s = K1.Text;
            if (K1.BackColor == Color.SlateBlue)
            {
                K1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K2_Click(object sender, EventArgs e)
        {
            string s = K2.Text;
            if (K2.BackColor == Color.SlateBlue)
            {
                K2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K3_Click(object sender, EventArgs e)
        {
            string s = K3.Text;
            if (K3.BackColor == Color.SlateBlue)
            {
                K3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K4_Click(object sender, EventArgs e)
        {
            string s = K4.Text;
            if (K4.BackColor == Color.SlateBlue)
            {
                K4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K5_Click(object sender, EventArgs e)
        {
            string s = K5.Text;
            if (K5.BackColor == Color.SlateBlue)
            {
                K5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K6_Click(object sender, EventArgs e)
        {
            string s = K6.Text;
            if (K6.BackColor == Color.SlateBlue)
            {
                K6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K7_Click(object sender, EventArgs e)
        {
            string s = K7.Text;
            if (K7.BackColor == Color.SlateBlue)
            {
                K7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K8_Click(object sender, EventArgs e)
        {
            string s = K8.Text;
            if (K8.BackColor == Color.SlateBlue)
            {
                K8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K9_Click(object sender, EventArgs e)
        {
            string s = K9.Text;
            if (K9.BackColor == Color.SlateBlue)
            {
                K9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K10_Click(object sender, EventArgs e)
        {
            string s = K10.Text;
            if (K10.BackColor == Color.SlateBlue)
            {
                K10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K11_Click(object sender, EventArgs e)
        {
            string s = K11.Text;
            if (K11.BackColor == Color.SlateBlue)
            {
                K11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K12_Click(object sender, EventArgs e)
        {
            string s = K12.Text;
            if (K12.BackColor == Color.SlateBlue)
            {
                K12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K13_Click(object sender, EventArgs e)
        {
            string s = K13.Text;
            if (K13.BackColor == Color.SlateBlue)
            {
                K13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K14_Click(object sender, EventArgs e)
        {
            string s = K14.Text;
            if (K14.BackColor == Color.SlateBlue)
            {
                K14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K15_Click(object sender, EventArgs e)
        {
            string s = K15.Text;
            if (K15.BackColor == Color.SlateBlue)
            {
                K15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K16_Click(object sender, EventArgs e)
        {
            string s = K16.Text;
            if (K16.BackColor == Color.SlateBlue)
            {
                K16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K17_Click(object sender, EventArgs e)
        {
            string s = K17.Text;
            if (K17.BackColor == Color.SlateBlue)
            {
                K17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K18_Click(object sender, EventArgs e)
        {
            string s = K18.Text;
            if (K18.BackColor == Color.SlateBlue)
            {
                K18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K19_Click(object sender, EventArgs e)
        {
            string s = K19.Text;
            if (K19.BackColor == Color.SlateBlue)
            {
                K19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void K20_Click(object sender, EventArgs e)
        {
            string s = K20.Text;
            if (K20.BackColor == Color.SlateBlue)
            {
                K20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (K20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                K20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L1_Click(object sender, EventArgs e)
        {
            string s = L1.Text;
            if (L1.BackColor == Color.SlateBlue)
            {
                L1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L2_Click(object sender, EventArgs e)
        {
            string s = L2.Text;
            if (L2.BackColor == Color.SlateBlue)
            {
                L2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L3_Click(object sender, EventArgs e)
        {
            string s = L3.Text;
            if (L3.BackColor == Color.SlateBlue)
            {
                L3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L4_Click(object sender, EventArgs e)
        {
            string s = L4.Text;
            if (L4.BackColor == Color.SlateBlue)
            {
                L4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L5_Click(object sender, EventArgs e)
        {
            string s = L5.Text;
            if (L5.BackColor == Color.SlateBlue)
            {
                L5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L6_Click(object sender, EventArgs e)
        {
            string s = L6.Text;
            if (L6.BackColor == Color.SlateBlue)
            {
                L6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L7_Click(object sender, EventArgs e)
        {
            string s = L7.Text;
            if (L7.BackColor == Color.SlateBlue)
            {
                L7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L8_Click(object sender, EventArgs e)
        {
            string s = L8.Text;
            if (L8.BackColor == Color.SlateBlue)
            {
                L8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L9_Click(object sender, EventArgs e)
        {
            string s = L9.Text;
            if (L9.BackColor == Color.SlateBlue)
            {
                L9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L10_Click(object sender, EventArgs e)
        {
            string s = L10.Text;
            if (L10.BackColor == Color.SlateBlue)
            {
                L10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L11_Click(object sender, EventArgs e)
        {
            string s = L11.Text;
            if (L11.BackColor == Color.SlateBlue)
            {
                L11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L12_Click(object sender, EventArgs e)
        {
            string s = L12.Text;
            if (L12.BackColor == Color.SlateBlue)
            {
                L12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L13_Click(object sender, EventArgs e)
        {
            string s = L13.Text;
            if (L13.BackColor == Color.SlateBlue)
            {
                L13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L14_Click(object sender, EventArgs e)
        {
            string s = L14.Text;
            if (L14.BackColor == Color.SlateBlue)
            {
                L14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L15_Click(object sender, EventArgs e)
        {
            string s = L15.Text;
            if (L15.BackColor == Color.SlateBlue)
            {
                L15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L16_Click(object sender, EventArgs e)
        {
            string s = L16.Text;
            if (L16.BackColor == Color.SlateBlue)
            {
                L16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L17_Click(object sender, EventArgs e)
        {
            string s = L17.Text;
            if (L17.BackColor == Color.SlateBlue)
            {
                L17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L18_Click(object sender, EventArgs e)
        {
            string s = L18.Text;
            if (L18.BackColor == Color.SlateBlue)
            {
                L18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L19_Click(object sender, EventArgs e)
        {
            string s = L19.Text;
            if (L19.BackColor == Color.SlateBlue)
            {
                L19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void L20_Click(object sender, EventArgs e)
        {
            string s = L20.Text;
            if (L20.BackColor == Color.SlateBlue)
            {
                L20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (L20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                L20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M1_Click(object sender, EventArgs e)
        {
            string s = M1.Text;
            if (M1.BackColor == Color.SlateBlue)
            {
                M1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M2_Click(object sender, EventArgs e)
        {
            string s = M2.Text;
            if (M2.BackColor == Color.SlateBlue)
            {
                M2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M3_Click(object sender, EventArgs e)
        {
            string s = M3.Text;
            if (M3.BackColor == Color.SlateBlue)
            {
                M3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M4_Click(object sender, EventArgs e)
        {
            string s = M4.Text;
            if (M4.BackColor == Color.SlateBlue)
            {
                M4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M5_Click(object sender, EventArgs e)
        {
            string s = M5.Text;
            if (M5.BackColor == Color.SlateBlue)
            {
                M5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M6_Click(object sender, EventArgs e)
        {
            string s = M6.Text;
            if (M6.BackColor == Color.SlateBlue)
            {
                M6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M7_Click(object sender, EventArgs e)
        {
            string s = M7.Text;
            if (M7.BackColor == Color.SlateBlue)
            {
                M7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M8_Click(object sender, EventArgs e)
        {
            string s = M8.Text;
            if (M8.BackColor == Color.SlateBlue)
            {
                M8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M9_Click(object sender, EventArgs e)
        {
            string s = M9.Text;
            if (M9.BackColor == Color.SlateBlue)
            {
                M9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M10_Click(object sender, EventArgs e)
        {
            string s = M10.Text;
            if (M10.BackColor == Color.SlateBlue)
            {
                M10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M11_Click(object sender, EventArgs e)
        {
            string s = M11.Text;
            if (M11.BackColor == Color.SlateBlue)
            {
                M11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M12_Click(object sender, EventArgs e)
        {
            string s = M12.Text;
            if (M12.BackColor == Color.SlateBlue)
            {
                M12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M13_Click(object sender, EventArgs e)
        {
            string s = M13.Text;
            if (M13.BackColor == Color.SlateBlue)
            {
                M13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M14_Click(object sender, EventArgs e)
        {
            string s = M14.Text;
            if (M14.BackColor == Color.SlateBlue)
            {
                M14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M15_Click(object sender, EventArgs e)
        {
            string s = M15.Text;
            if (M15.BackColor == Color.SlateBlue)
            {
                M15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M16_Click(object sender, EventArgs e)
        {
            string s = M16.Text;
            if (M16.BackColor == Color.SlateBlue)
            {
                M16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M17_Click(object sender, EventArgs e)
        {
            string s = M17.Text;
            if (M17.BackColor == Color.SlateBlue)
            {
                M17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M18_Click(object sender, EventArgs e)
        {
            string s = M18.Text;
            if (M18.BackColor == Color.SlateBlue)
            {
                M18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M19_Click(object sender, EventArgs e)
        {
            string s = M19.Text;
            if (M19.BackColor == Color.SlateBlue)
            {
                M19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void M20_Click(object sender, EventArgs e)
        {
            string s = M20.Text;
            if (M20.BackColor == Color.SlateBlue)
            {
                M20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (M20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                M20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N1_Click(object sender, EventArgs e)
        {
            string s = N1.Text;
            if (N1.BackColor == Color.SlateBlue)
            {
                N1.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N1.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N1.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N2_Click(object sender, EventArgs e)
        {
            string s = N2.Text;
            if (N2.BackColor == Color.SlateBlue)
            {
                N2.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N2.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N2.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N3_Click(object sender, EventArgs e)
        {
            string s = N3.Text;
            if (N3.BackColor == Color.SlateBlue)
            {
                N3.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N3.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N3.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N4_Click(object sender, EventArgs e)
        {
            string s = N4.Text;
            if (N4.BackColor == Color.SlateBlue)
            {
                N4.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N4.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N4.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N5_Click(object sender, EventArgs e)
        {
            string s = N5.Text;
            if (N5.BackColor == Color.SlateBlue)
            {
                N5.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N5.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N5.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N6_Click(object sender, EventArgs e)
        {
            string s = N6.Text;
            if (N6.BackColor == Color.SlateBlue)
            {
                N6.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N6.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N6.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N7_Click(object sender, EventArgs e)
        {
            string s = N7.Text;
            if (N7.BackColor == Color.SlateBlue)
            {
                N7.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N7.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N7.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N8_Click(object sender, EventArgs e)
        {
            string s = N8.Text;
            if (N8.BackColor == Color.SlateBlue)
            {
                N8.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N8.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N8.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N9_Click(object sender, EventArgs e)
        {
            string s = N9.Text;
            if (N9.BackColor == Color.SlateBlue)
            {
                N9.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N9.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N9.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N10_Click(object sender, EventArgs e)
        {
            string s = N10.Text;
            if (N10.BackColor == Color.SlateBlue)
            {
                N10.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N10.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N10.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N11_Click(object sender, EventArgs e)
        {
            string s = N11.Text;
            if (N11.BackColor == Color.SlateBlue)
            {
                N11.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N11.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N11.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N12_Click(object sender, EventArgs e)
        {
            string s = N12.Text;
            if (N12.BackColor == Color.SlateBlue)
            {
                N12.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N12.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N12.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N13_Click(object sender, EventArgs e)
        {
            string s = N13.Text;
            if (N13.BackColor == Color.SlateBlue)
            {
                N13.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N13.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N13.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N14_Click(object sender, EventArgs e)
        {
            string s = N14.Text;
            if (N14.BackColor == Color.SlateBlue)
            {
                N14.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N14.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N14.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N15_Click(object sender, EventArgs e)
        {
            string s = N15.Text;
            if (N15.BackColor == Color.SlateBlue)
            {
                N15.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N15.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N15.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N16_Click(object sender, EventArgs e)
        {
            string s = N16.Text;
            if (N16.BackColor == Color.SlateBlue)
            {
                N16.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N16.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N16.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N17_Click(object sender, EventArgs e)
        {
            string s = N17.Text;
            if (N17.BackColor == Color.SlateBlue)
            {
                N17.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N17.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N17.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N18_Click(object sender, EventArgs e)
        {
            string s = N18.Text;
            if (N18.BackColor == Color.SlateBlue)
            {
                N18.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N18.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N18.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N19_Click(object sender, EventArgs e)
        {
            string s = N19.Text;
            if (N19.BackColor == Color.SlateBlue)
            {
                N19.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N19.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N19.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        private void N20_Click(object sender, EventArgs e)
        {
            string s = N20.Text;
            if (N20.BackColor == Color.SlateBlue)
            {
                N20.BackColor = Color.DeepPink;
                labelSeat.Text = labelSeat.Text + s + ", ";
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) + 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
            else if (N20.BackColor == Color.DeepPink)
            {
                string s1 = labelSeat.Text.Replace(s + ", ", "");
                N20.BackColor = Color.SlateBlue;
                labelSeat.Text = s1;
                string m1 = labelGiaGhe.Text.Replace("đ", "");
                int m = Int32.Parse(m1) - 90000;
                labelGiaGhe.Text = m.ToString() + "đ";
            }
        }

        DataTable GetNumSeatBooked()
        {
            DataTable data = new DataTable();
            string query = "SELECT COUNT (*) FROM SEAT WHERE STATUS_SEAT='1' AND ID_TIME1='" + GetIdTime().Rows[0][0].ToString() + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetSeatBooked()
        {
            DataTable data = new DataTable();
            string query = "SELECT NAME_SEAT FROM SEAT WHERE STATUS_SEAT='1' AND ID_TIME1='"+ GetIdTime().Rows[0][0].ToString() + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetIdTime()
        {
            DataTable data = new DataTable();
            string query = "SELECT ID_TIME1 FROM TIME1 WHERE NAME_TIME1='" + (showtime1+":00") + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int num = Int32.Parse(GetNumSeatBooked().Rows[0][0].ToString());
            for (int j = 0; j < num; j++)
            {
                if (GetSeatBooked().Rows[j][0].ToString() == A1.Text)
                {
                    A1.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A2.Text)
                {
                    A2.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A3.Text)
                {
                    A3.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A4.Text)
                {
                    A4.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A5.Text)
                {
                    A5.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A6.Text)
                {
                    A6.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A7.Text)
                {
                    A7.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A8.Text)
                {
                    A8.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A9.Text)
                {
                    A9.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A10.Text)
                {
                    A10.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A11.Text)
                {
                    A11.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A12.Text)
                {
                    A12.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A13.Text)
                {
                    A13.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A14.Text)
                {
                    A14.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A15.Text)
                {
                    A15.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A16.Text)
                {
                    A16.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A17.Text)
                {
                    A17.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A18.Text)
                {
                    A18.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A19.Text)
                {
                    A19.BackColor = Color.Black;
                }
                if (GetSeatBooked().Rows[j][0].ToString() == A20.Text)
                {
                    A20.BackColor = Color.Black;
                }
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            MessageBox.Show(ghe1 + "|" + "|");
        }
    }
}
