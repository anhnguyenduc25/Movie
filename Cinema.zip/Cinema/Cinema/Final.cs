﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class Final : Form
    {
        string combo1;
        string ghe1;
        string discount1;
        string user1;
        string payment1;
        string numberPay1;
        string namePay1;
        string contentPay1;
        string price1;
        public Final(string combo, string ghe, string discount, string user, string image, string payment, string numberPay, string namePay, string contentPay, string price)
        {
            InitializeComponent();
            combo1 = combo;
            ghe1 = ghe;
            discount1 = discount;
            user1 = user;
            payment1 = payment;
            numberPay1 = numberPay;
            namePay1 = namePay;
            contentPay1 = contentPay;
            price1 = price;
            pictureBox1.BackgroundImage = Image.FromFile(image);
            labelPayment.Text = payment;
            labelNumberPay.Text = numberPay;
            labelNamePay.Text = namePay;
            labelContentPay.Text = (contentPay1 + (Int32.Parse(GetIdPaymentMethods().Rows[0][0].ToString()) + 1));
            labelPrice.Text = price + " VNĐ";
        }

        private void Final_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        DataTable GetIdPaymentMethods()
        {
            DataTable data = new DataTable();
            string query = "SELECT COUNT (*) FROM PAYMENT_METHODS";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable AddPaymentMethods()
        {
            DataTable data = new DataTable();
            string query = "INSERT INTO PAYMENT_METHODS(ID_PAYMENT_METHODS, NAME_PAYMENT_METHODS, CONTENT_PAYMENT_METHODS, PRICE_PAYMENT_METHODS,STATUS_PAYMENT_METHODS,ID_PAYMENT_SELECT) VALUES ('" + (Int32.Parse(GetIdPaymentMethods().Rows[0][0].ToString()) + 1) + "',N'" + payment1 + "',N'" + (contentPay1 + (Int32.Parse(GetIdPaymentMethods().Rows[0][0].ToString()) + 1)) + "','" + price1 + "','" + "0" + "','" + GetIdPaymentSelect().Rows[0][0].ToString() + "')";
            //MessageBox.Show(query);
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void buttonXacNhan_Click(object sender, EventArgs e)
        {
            if(buttonXacNhan.Text == "Xác nhận đã thanh toán !")
            {
                AddPaymentMethods();
                buttonXacNhan.Text = "Vui lòng chờ hệ thống xử lý !";
                buttonXacNhan.BackColor = Color.Salmon;
            }
        }

        DataTable GetStatusPaymentMethods()
        {
            DataTable data = new DataTable();
            string query = "SELECT STATUS_PAYMENT_METHODS FROM PAYMENT_METHODS WHERE NAME_PAYMENT_METHODS = N'" + payment1 + "' AND CONTENT_PAYMENT_METHODS = '" + labelContentPay.Text +"'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetIdPaymentSelect()
        {
            DataTable data = new DataTable();
            string query = "SELECT ID_PAYMENT_SELECT FROM PAYMENT_SELECT WHERE NAME_PAYMENT_SELECT = N'"+payment1+"'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }
        DataTable GetIdBill()
        {
            DataTable data = new DataTable();
            string query = "SELECT COUNT(*) FROM BILL";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }
        DataTable GetIdAccount()
        {
            DataTable data = new DataTable();
            string query = "SELECT ID_ACCOUNT FROM ACCOUNT WHERE USER_ACCOUNT=N'"+user1+"'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }
        DataTable GetIdPaymentMethods1()
        {
            DataTable data = new DataTable();
            string query = "SELECT ID_PAYMENT_METHODS FROM PAYMENT_METHODS WHERE PRICE_PAYMENT_METHODS='" + price1 + "' AND NAME_PAYMENT_METHODS = N'" + payment1 + "' AND CONTENT_PAYMENT_METHODS = '" + labelContentPay.Text + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (buttonXacNhan.Text == "Vui lòng chờ hệ thống xử lý !")
            {
                GetStatusPaymentMethods();
                if (GetStatusPaymentMethods().Rows[0][0].ToString() == "1")
                {
                    buttonXacNhan.Text = "Thanh toán thành công!";
                    buttonXacNhan.BackColor = Color.LightGreen;
                    AddBill();
                }
            }
        }

        DataTable AddBill()
        {
            DataTable data = new DataTable();
            string query = "INSERT INTO BILL(ID_BILL, TOTAL_PRICE, ID_ACCOUNT, ID_PAYMENT_METHODS) VALUES ('" + (Int32.Parse(GetIdBill().Rows[0][0].ToString()) + 1) + "','" + price1 + "','" + Int32.Parse(GetIdAccount().Rows[0][0].ToString()) + "','" + GetIdPaymentMethods1().Rows[0][0].ToString() + "')";
            //MessageBox.Show(query);
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
