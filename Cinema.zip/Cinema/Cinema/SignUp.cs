﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (textBoxPass.UseSystemPasswordChar == true)
            {
                textBoxPass.UseSystemPasswordChar = false;
            }
            else if (textBoxPass.UseSystemPasswordChar == false)
            {
                textBoxPass.UseSystemPasswordChar = true;
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (textBoxRePass.UseSystemPasswordChar == true)
            {
                textBoxRePass.UseSystemPasswordChar = false;
            }
            else if (textBoxRePass.UseSystemPasswordChar == false)
            {
                textBoxRePass.UseSystemPasswordChar = true;
            }
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.ShowDialog();
            this.Close();
        }

        private void textBoxUser_TextChanged(object sender, EventArgs e)
        {

        }

        DataTable CheckAccount()
        {
            string userName = textBoxUser.Text;
            DataTable data = new DataTable();
            string query = "select count(*) from ACCOUNT where USER_ACCOUNT='" + userName + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable AddAccount()
        {
            int IdAccount = Convert.ToInt32(getIdAccount().Rows[0][0]) + 1;
            string userName = textBoxUser.Text;
            string passWord = textBoxPass.Text;
            string type = "0";
            DataTable data = new DataTable();
            string query = "insert into ACCOUNT(ID_ACCOUNT , USER_ACCOUNT, PASSWORD_ACCOUNT, STATUS_ACCOUNT) values ('" + IdAccount + "','" + userName + "','" + passWord + "','" + type + "')";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable getIdAccount()
        {
            DataTable data = new DataTable();
            string query = "SELECT MAX(ID_ACCOUNT) FROM ACCOUNT";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void buttonSignUp_Click(object sender, EventArgs e)
        {
            string userName = textBoxUser.Text;
            string passWord = textBoxPass.Text;
            string rePassWord = textBoxRePass.Text;
            if (string.IsNullOrEmpty(textBoxUser.Text))
            {
                textBoxUser.Focus();
                errorProvider1.SetError(textBoxUser, "Vui lòng nhập tài khoản !");
            }
            else if (!string.IsNullOrEmpty(textBoxUser.Text))
            {
                errorProvider1.SetError(textBoxUser, null);
            }
            if (string.IsNullOrEmpty(textBoxPass.Text))
            {
                textBoxPass.Focus();
                errorProvider2.SetError(textBoxPass, "Vui lòng nhập mật khẩu !");
            }
            else if (!string.IsNullOrEmpty(textBoxPass.Text))
            {
                errorProvider2.SetError(textBoxPass, null);
            }
            if (string.IsNullOrEmpty(textBoxRePass.Text))
            {
                textBoxRePass.Focus();
                errorProvider3.SetError(textBoxRePass, "Vui lòng nhập lại mật khẩu !");
            }
            else if (!string.IsNullOrEmpty(textBoxRePass.Text))
            {
                errorProvider3.SetError(textBoxRePass, null);
            }
            if(!string.IsNullOrEmpty(textBoxUser.Text) && !string.IsNullOrEmpty(textBoxPass.Text) && !string.IsNullOrEmpty(textBoxRePass.Text))
            {
                if(textBoxUser.Text.Length < 8)
                {
                    MessageBox.Show("Vui lòng nhập tài khoản có 8 ký tự trở lên !");
                }
                if (passWord == rePassWord)
                {
                    if (CheckAccount().Rows[0][0].ToString() == "1")
                    {
                        MessageBox.Show("Tài khoản đã tồn tại, vui lòng chọn tài khoản khác !");
                        textBoxUser.Text = "";
                        textBoxPass.Text = "";
                        textBoxRePass.Text = "";
                    }
                    else
                    {
                        AddAccount();
                        MessageBox.Show("Tạo tài khoản thành công !");
                        Login login = new Login();
                        this.Hide();
                        login.ShowDialog();
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Mật khẩu nhập lại chưa khớp, vui lòng nhập lại !");
                    textBoxPass.Text = "";
                    textBoxRePass.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Chưa nhập đủ thông tin, vui lòng nhập lại !");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }
    }
}
