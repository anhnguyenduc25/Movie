﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class SelectPayment : Form
    {
        string combo1;
        string ghe1;
        string discount1;
        string user1;
        string image1;
        string payment1;
        string numberPay1;
        string namePay1;
        string contentPay1;
        string price1;
        public SelectPayment(string combo, string ghe, string discount, string user, string price)
        {
            combo1 = combo;
            ghe1 = ghe;
            discount1 = discount;
            user1 = user;
            price1 = price;
            InitializeComponent();
        }

        private void SelectPayment_Load(object sender, EventArgs e)
        {
        }

        private void radioButtonMomo_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButtonVietinbank_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButtonVietcombank_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButtonZaloPay_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButtonVnPay_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButtonMomo_Click(object sender, EventArgs e)
        {
            radioButtonMomo.Checked = true;
            radioButtonVietinbank.Checked = false;
            radioButtonVietcombank.Checked = false;
            radioButtonVnPay.Checked = false;
            radioButtonZaloPay.Checked = false;
        }

        private void radioButtonVietinbank_Click(object sender, EventArgs e)
        {
            radioButtonMomo.Checked = false;
            radioButtonVietinbank.Checked = true;
            radioButtonVietcombank.Checked = false;
            radioButtonVnPay.Checked = false;
            radioButtonZaloPay.Checked = false;
        }

        private void radioButtonVietcombank_Click(object sender, EventArgs e)
        {
            radioButtonMomo.Checked = false;
            radioButtonVietinbank.Checked = false;
            radioButtonVietcombank.Checked = true;
            radioButtonVnPay.Checked = false;
            radioButtonZaloPay.Checked = false;
        }

        private void radioButtonZaloPay_Click(object sender, EventArgs e)
        {
            radioButtonMomo.Checked = false;
            radioButtonVietinbank.Checked = false;
            radioButtonVietcombank.Checked = false;
            radioButtonVnPay.Checked = false;
            radioButtonZaloPay.Checked = true;
        }

        private void radioButtonVnPay_Click(object sender, EventArgs e)
        {
            radioButtonMomo.Checked = false;
            radioButtonVietinbank.Checked = false;
            radioButtonVietcombank.Checked = false;
            radioButtonVnPay.Checked = true;
            radioButtonZaloPay.Checked = false;
        }

        private void buttonXacNhan_Click(object sender, EventArgs e)
        {
            if(radioButtonMomo.Checked == true)
            {
                image1 = "D:/DOWNLOAD/Cinema/momo.jfif";
                payment1 = "Ví điện tử MoMo";
                numberPay1 = "03891688xx";
                namePay1 = "Nguyễn Đức Anh";
                contentPay1 = user1 + "_cgv_momo_bill";
                Final f = new Final(combo1, ghe1, discount1, user1, image1, payment1, numberPay1, namePay1, contentPay1, price1);
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
            else if(radioButtonVietinbank.Checked == true)
            {
                image1 = "D:/DOWNLOAD/Cinema/vietinbank.jpg";
                payment1 = "Ngân hàng VietinBank";
                numberPay1 = "1088720983xx";
                namePay1 = "Nguyễn Đức Anh";
                contentPay1 = user1 + "_cgv_vietinbank_bill";
                Final f = new Final(combo1, ghe1, discount1, user1, image1, payment1, numberPay1, namePay1, contentPay1, price1);
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
            else if (radioButtonVietcombank.Checked == true)
            {
                image1 = "D:/DOWNLOAD/Cinema/vietcombank.jpg";
                payment1 = "Ngân hàng VietcomBank";
                numberPay1 = "10253582xx";
                namePay1 = "Nguyễn Đức Anh";
                contentPay1 = user1 + "_cgv_vietcombank_bill";
                Final f = new Final(combo1, ghe1, discount1, user1, image1, payment1, numberPay1, namePay1, contentPay1, price1);
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
            else if (radioButtonZaloPay.Checked == true)
            {
                image1 = "D:/DOWNLOAD/Cinema/zalopay.png";
                payment1 = "Ví điện tử ZALO PAY";
                numberPay1 = "03847265xx";
                namePay1 = "Nguyễn Đức Anh";
                contentPay1 = user1 + "_cgv_zalopay_bill";
                Final f = new Final(combo1, ghe1, discount1, user1, image1, payment1, numberPay1, namePay1, contentPay1, price1);
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
            else if (radioButtonVnPay.Checked == true)
            {
                image1 = "D:/DOWNLOAD/Cinema/vnpay.png";
                payment1 = "Ví điện tử VN PAY";
                numberPay1 = "08681861xx";
                namePay1 = "Nguyễn Đức Anh";
                contentPay1 = user1 + "_cgv_vnpay_bill";
                Final f = new Final(combo1, ghe1, discount1, user1, image1, payment1, numberPay1, namePay1, contentPay1, price1);
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(ghe1 + "|" + combo1 + "|" + discount1);
        }
    }
}
