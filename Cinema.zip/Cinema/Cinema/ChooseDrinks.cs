﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class ChooseDrinks : Form
    {
        string giaCombo;
        string combo1;
        string user1;
        string showtime1;
        string dayOfWeek1;
        string cinemaPlace1;
        string name1;
        string giaVe;
        string ghe1;
        public ChooseDrinks(string user, string showtime, string dayOfWeek, string cinemaPlace, string name, string giaVe1, string ghe)
        {
            user1 = user;
            showtime1 = showtime;
            dayOfWeek1 = dayOfWeek;
            cinemaPlace1 = cinemaPlace;
            name1 = name;
            giaVe = giaVe1;
            ghe1 = ghe;
            InitializeComponent();
        }

        private void pictureBoxTang1_Click(object sender, EventArgs e)
        {
            int soluong = Int32.Parse(labelSoLuong1.Text)+1;
            labelSoLuong1.Text = soluong.ToString();
            if (soluong == 10)
                labelSoLuong1.Location = new Point(labelSoLuong1.Location.X - 5, labelSoLuong1.Location.Y);

            string s = labelGia1.Text;
            string m = labelGia1.Text.Replace("đ", "");
            int m1 = Int32.Parse(m);

            m1 = soluong * 249000;

            m = m1.ToString() + "đ";
            labelGia1.Text = m;

            string t1 = labelGia1.Text.Replace("đ", "");
            string t2 = labelGia2.Text.Replace("đ", "");
            string t3 = labelGia3.Text.Replace("đ", "");
            string t4 = labelGia4.Text.Replace("đ", "");
            int total = Int32.Parse(t1) + Int32.Parse(t2) + Int32.Parse(t3) + Int32.Parse(t4);
            labelGiaTong.Text = total.ToString() + "đ";
        }

        private void pictureBoxTang2_Click(object sender, EventArgs e)
        {
            int soluong = Int32.Parse(labelSoLuong2.Text) + 1;
            labelSoLuong2.Text = soluong.ToString();
            if (soluong == 10)
                labelSoLuong2.Location = new Point(labelSoLuong2.Location.X - 5, labelSoLuong2.Location.Y);

            string s = labelGia2.Text;
            string m = labelGia2.Text.Replace("đ", "");
            int m1 = Int32.Parse(m);

            m1 = soluong * 113000;

            m = m1.ToString() + "đ";
            labelGia2.Text = m;

            string t1 = labelGia1.Text.Replace("đ", "");
            string t2 = labelGia2.Text.Replace("đ", "");
            string t3 = labelGia3.Text.Replace("đ", "");
            string t4 = labelGia4.Text.Replace("đ", "");
            int total = Int32.Parse(t1) + Int32.Parse(t2) + Int32.Parse(t3) + Int32.Parse(t4);
            labelGiaTong.Text = total.ToString() + "đ";
        }

        private void pictureBoxTang3_Click(object sender, EventArgs e)
        {
            int soluong = Int32.Parse(labelSoLuong3.Text) + 1;
            labelSoLuong3.Text = soluong.ToString();
            if (soluong == 10)
                labelSoLuong3.Location = new Point(labelSoLuong3.Location.X - 5, labelSoLuong3.Location.Y);

            string s = labelGia3.Text;
            string m = labelGia3.Text.Replace("đ", "");
            int m1 = Int32.Parse(m);

            m1 = soluong * 102000;

            m = m1.ToString() + "đ";
            labelGia3.Text = m;

            string t1 = labelGia1.Text.Replace("đ", "");
            string t2 = labelGia2.Text.Replace("đ", "");
            string t3 = labelGia3.Text.Replace("đ", "");
            string t4 = labelGia4.Text.Replace("đ", "");
            int total = Int32.Parse(t1) + Int32.Parse(t2) + Int32.Parse(t3) + Int32.Parse(t4);
            labelGiaTong.Text = total.ToString() + "đ";
        }

        private void pictureBoxTang4_Click(object sender, EventArgs e)
        {
            int soluong = Int32.Parse(labelSoLuong4.Text) + 1;
            labelSoLuong4.Text = soluong.ToString();
            if (soluong == 10)
                labelSoLuong4.Location = new Point(labelSoLuong4.Location.X - 5, labelSoLuong4.Location.Y);

            string s = labelGia4.Text;
            string m = labelGia4.Text.Replace("đ", "");
            int m1 = Int32.Parse(m);

            m1 = soluong * 93000;

            m = m1.ToString() + "đ";
            labelGia4.Text = m;

            string t1 = labelGia1.Text.Replace("đ", "");
            string t2 = labelGia2.Text.Replace("đ", "");
            string t3 = labelGia3.Text.Replace("đ", "");
            string t4 = labelGia4.Text.Replace("đ", "");
            int total = Int32.Parse(t1) + Int32.Parse(t2) + Int32.Parse(t3) + Int32.Parse(t4);
            labelGiaTong.Text = total.ToString() + "đ";
        }

        private void pictureBoxGiam1_Click(object sender, EventArgs e)
        {
            int soluong = Int32.Parse(labelSoLuong1.Text);
            if (soluong > 0)
                soluong -= 1;
            else
                soluong = 0;
            labelSoLuong1.Text = soluong.ToString();
            if (soluong == 9)
                labelSoLuong1.Location = new Point(labelSoLuong1.Location.X + 5, labelSoLuong1.Location.Y);

            string s = labelGia1.Text;
            string m = labelGia1.Text.Replace("đ", "");
            int m1 = Int32.Parse(m);
            
            m1 = soluong * 249000;
            
            m = m1.ToString() + "đ";
            labelGia1.Text = m;

            string t1 = labelGia1.Text.Replace("đ", "");
            string t2 = labelGia2.Text.Replace("đ", "");
            string t3 = labelGia3.Text.Replace("đ", "");
            string t4 = labelGia4.Text.Replace("đ", "");
            int total = Int32.Parse(t1) + Int32.Parse(t2) + Int32.Parse(t3) + Int32.Parse(t4);
            labelGiaTong.Text = total.ToString() + "đ";
        }

        private void pictureBoxGiam2_Click(object sender, EventArgs e)
        {
            int soluong = Int32.Parse(labelSoLuong2.Text);
            if (soluong > 0)
                soluong -= 1;
            else
                soluong = 0;
            labelSoLuong2.Text = soluong.ToString();
            if (soluong == 9)
                labelSoLuong2.Location = new Point(labelSoLuong2.Location.X + 5, labelSoLuong2.Location.Y);

            string s = labelGia2.Text;
            string m = labelGia2.Text.Replace("đ", "");
            int m1 = Int32.Parse(m);

            m1 = soluong * 113000;

            m = m1.ToString() + "đ";
            labelGia2.Text = m;

            string t1 = labelGia1.Text.Replace("đ", "");
            string t2 = labelGia2.Text.Replace("đ", "");
            string t3 = labelGia3.Text.Replace("đ", "");
            string t4 = labelGia4.Text.Replace("đ", "");
            int total = Int32.Parse(t1) + Int32.Parse(t2) + Int32.Parse(t3) + Int32.Parse(t4);
            labelGiaTong.Text = total.ToString() + "đ";
        }

        private void pictureBoxGiam3_Click(object sender, EventArgs e)
        {
            int soluong = Int32.Parse(labelSoLuong3.Text);
            if (soluong > 0)
                soluong -= 1;
            else
                soluong = 0;
            labelSoLuong3.Text = soluong.ToString();
            if (soluong == 9)
                labelSoLuong3.Location = new Point(labelSoLuong3.Location.X + 5, labelSoLuong3.Location.Y);

            string s = labelGia3.Text;
            string m = labelGia3.Text.Replace("đ", "");
            int m1 = Int32.Parse(m);

            m1 = soluong * 102000;

            m = m1.ToString() + "đ";
            labelGia3.Text = m;

            string t1 = labelGia1.Text.Replace("đ", "");
            string t2 = labelGia2.Text.Replace("đ", "");
            string t3 = labelGia3.Text.Replace("đ", "");
            string t4 = labelGia4.Text.Replace("đ", "");
            int total = Int32.Parse(t1) + Int32.Parse(t2) + Int32.Parse(t3) + Int32.Parse(t4);
            labelGiaTong.Text = total.ToString() + "đ";
        }

        private void pictureBoxGiam4_Click(object sender, EventArgs e)
        {
            int soluong = Int32.Parse(labelSoLuong4.Text);
            if (soluong > 0)
                soluong -= 1;
            else
                soluong = 0;
            labelSoLuong4.Text = soluong.ToString();
            if (soluong == 9)
                labelSoLuong4.Location = new Point(labelSoLuong4.Location.X + 5, labelSoLuong4.Location.Y);

            string s = labelGia4.Text;
            string m = labelGia4.Text.Replace("đ", "");
            int m1 = Int32.Parse(m);

            m1 = soluong * 93000;

            m = m1.ToString() + "đ";
            labelGia4.Text = m;

            string t1 = labelGia1.Text.Replace("đ", "");
            string t2 = labelGia2.Text.Replace("đ", "");
            string t3 = labelGia3.Text.Replace("đ", "");
            string t4 = labelGia4.Text.Replace("đ", "");
            int total = Int32.Parse(t1) + Int32.Parse(t2) + Int32.Parse(t3) + Int32.Parse(t4);
            labelGiaTong.Text = total.ToString() + "đ";
        }

        private void labelSoLuong1_Click(object sender, EventArgs e)
        {
            
        }

        private void ChooseDrinks_Load(object sender, EventArgs e)
        {
            if(Int32.Parse(labelSoLuong1.Text) > 0)
            {
                combo1 = combo1 + labelName1 + ", ";
            }
            if (Int32.Parse(labelSoLuong2.Text) > 0)
            {
                combo1 = combo1 + labelName2 + ", ";
            }
            if (Int32.Parse(labelSoLuong3.Text) > 0)
            {
                combo1 = combo1 + labelName3 + ", ";
            }
            if (Int32.Parse(labelSoLuong4.Text) > 0)
            {
                combo1 = combo1 + labelName4 + ", ";
            }
        }

        private void labelGia1_Click(object sender, EventArgs e)
        {

        }

        private void labelGia2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxTiepTuc_Click(object sender, EventArgs e)
        {
            giaCombo = labelGiaTong.Text;
            Payment pay = new Payment(combo1, user1, showtime1, dayOfWeek1, cinemaPlace1, name1, giaVe, ghe1, giaCombo);
            this.Hide();
            pay.ShowDialog();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(ghe1 + "|" + combo1 + "|");
        }
    }
}
