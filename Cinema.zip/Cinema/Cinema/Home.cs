﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class Home : Form
    {
        string user1;
        string name;
        string pic;
        string category;
        string content;
        string actor;
        string director;
        string producer;
        string studio;
        string date;
        string time;
        string age;
        string timestart;
        public Home(string user)
        {
            user1 = user;
            InitializeComponent();
        }

        DataTable GetNumberMovie()
        {
            DataTable data = new DataTable();
            //Lấy số lượng bộ phim trong db
            string query = "select count (*) from MOVIE";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            int numberMovie = Int32.Parse(GetNumberMovie().Rows[0][0].ToString());
            label5.Text = numberMovie.ToString();
            for (int j = 0; j < numberMovie; j++)
            {
                for (int k = 1; k < 14; k++)
                {
                    if(j == 0 && j < numberMovie)
                    {
                        buttonPhim1.Visible = true;
                        pictureBoxphim1.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName1.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory1.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 1 && j < numberMovie)
                    {
                        buttonPhim2.Visible = true;
                        pictureBoxphim2.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName2.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory2.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 2 && j < numberMovie)
                    {
                        buttonPhim3.Visible = true;
                        pictureBoxphim3.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName3.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory3.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 3 && j < numberMovie)
                    {
                        buttonPhim4.Visible = true;
                        pictureBoxphim4.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName4.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory4.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 4 && j < numberMovie)
                    {
                        buttonPhim5.Visible = true;
                        pictureBoxphim5.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName5.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory5.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 5 && j < numberMovie)
                    {
                        buttonPhim6.Visible = true;
                        pictureBoxphim6.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName6.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory6.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 6 && j < numberMovie)
                    {
                        buttonPhim7.Visible = true;
                        pictureBoxphim7.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName7.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory7.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 7 && j < numberMovie)
                    {
                        buttonPhim8.Visible = true;
                        pictureBoxphim8.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName8.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory8.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 8 && j < numberMovie)
                    {
                        buttonPhim9.Visible = true;
                        pictureBoxphim9.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName9.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory9.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 9 && j < numberMovie)
                    {
                        buttonPhim10.Visible = true;
                        pictureBoxphim10.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName10.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory10.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 10 && j < numberMovie)
                    {
                        buttonPhim11.Visible = true;
                        pictureBoxphim11.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName11.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory11.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 11 && j < numberMovie)
                    {
                        buttonPhim12.Visible = true;
                        pictureBoxphim12.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName12.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory12.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 12 && j < numberMovie)
                    {
                        buttonPhim13.Visible = true;
                        pictureBoxphim13.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName13.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory13.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 13 && j < numberMovie)
                    {
                        buttonPhim14.Visible = true;
                        pictureBoxphim14.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName14.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory14.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 14 && j < numberMovie)
                    {
                        buttonPhim15.Visible = true;
                        pictureBoxphim15.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName15.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory15.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 15 && j < numberMovie)
                    {
                        buttonPhim16.Visible = true;
                        pictureBoxphim16.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName16.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory16.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 16 && j < numberMovie)
                    {
                        buttonPhim17.Visible = true;
                        pictureBoxphim17.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName17.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory17.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 17 && j < numberMovie)
                    {
                        buttonPhim18.Visible = true;
                        pictureBoxphim18.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName18.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory18.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 18 && j < numberMovie)
                    {
                        buttonPhim19.Visible = true;
                        pictureBoxphim19.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName19.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory19.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 19 && j < numberMovie)
                    {
                        buttonPhim20.Visible = true;
                        pictureBoxphim20.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName20.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory20.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 20 && j < numberMovie)
                    {
                        buttonPhim21.Visible = true;
                        pictureBoxphim21.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName21.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory21.Text = GetMovie().Rows[j][3].ToString();
                    }
                    if (j == 21 && j < numberMovie)
                    {
                        buttonPhim22.Visible = true;
                        pictureBoxphim22.Image = Image.FromFile(GetMovie().Rows[j][2].ToString());
                        labelName22.Text = GetMovie().Rows[j][1].ToString();
                        labelCategory22.Text = GetMovie().Rows[j][3].ToString();
                    }
                }
            }
            if (user1 == "")
            {
                pictureBox2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/login.png");
                pictureBox3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/register.png");
                label3.Text = "Đăng nhập";
                label4.Text = "Đăng ký";
                if (panelMenu.Visible == true)
                    panelMenu.Visible = false;
                if (panelMenu.Visible == false)
                    pictureBoxMenuShow.Visible = true;
            }
            else if (user1 != "")
            {
                pictureBox2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/bill.png");
                pictureBox3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/logout.png");
                label3.Text = "Lịch sử mua hàng";
                label4.Text = "Đăng xuất";
                if (panelMenu.Visible == true)
                    panelMenu.Visible = false;
                if (panelMenu.Visible == false)
                    pictureBoxMenuShow.Visible = true;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        int i = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            pictureBoxposter1.Controls.Clear();
            pictureBoxposter2.Controls.Clear();
            pictureBoxposter3.Controls.Clear();
            switch (i)
            {
                case 1:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster2.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster2.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster2.jpg");
                    break;
                case 2:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster3.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster3.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster3.jpg");
                    break;
                case 3:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster4.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster4.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster4.jpg");
                    break;
                case 4:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster5.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster5.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster5.jpg");
                    break;
                case 5:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster6.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster6.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster6.jpg");
                    break;
                case 6:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster7.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster7.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster7.jpg");
                    break;
                case 7:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster8.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster8.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster8.jpg");
                    break;
                case 8:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster9.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster9.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster9.jpg");
                    break;
                case 9:
                    pictureBoxposter1.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster1.jpg");
                    pictureBoxposter2.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster1.jpg");
                    pictureBoxposter3.BackgroundImage = Image.FromFile("D:/DOWNLOAD/Cinema/poster1.jpg");
                    i = 0;
                    break;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 1)
            {
                name = GetMovie().Rows[0][1].ToString();
                pic = GetMovie().Rows[0][2].ToString();
                category = GetMovie().Rows[0][3].ToString();
                content = GetMovie().Rows[0][4].ToString();
                actor = GetMovie().Rows[0][5].ToString();
                director = GetMovie().Rows[0][6].ToString();
                producer = GetMovie().Rows[0][7].ToString();
                studio = GetMovie().Rows[0][8].ToString();
                date = GetMovie().Rows[0][9].ToString();
                time = GetMovie().Rows[0][10].ToString();
                age = GetMovie().Rows[0][11].ToString();
                timestart = GetMovie().Rows[0][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            buyticket1.Show();
        }

        DataTable GetMovie()
        {
            DataTable data = new DataTable();
            string query = "SELECT * FROM MOVIE";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }    
            return data;
        }

        public void pictureBoxphim1_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 1)
            {
                name = GetMovie().Rows[0][1].ToString();
                pic = GetMovie().Rows[0][2].ToString();
                category = GetMovie().Rows[0][3].ToString();
                content = GetMovie().Rows[0][4].ToString();
                actor = GetMovie().Rows[0][5].ToString();
                director = GetMovie().Rows[0][6].ToString();
                producer = GetMovie().Rows[0][7].ToString();
                studio = GetMovie().Rows[0][8].ToString();
                date = GetMovie().Rows[0][9].ToString();
                time = GetMovie().Rows[0][10].ToString();
                age = GetMovie().Rows[0][11].ToString();
                timestart = GetMovie().Rows[0][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBoxphim2_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 3)
            {
                name = GetMovie().Rows[2][1].ToString();
                pic = GetMovie().Rows[2][2].ToString();
                category = GetMovie().Rows[2][3].ToString();
                content = GetMovie().Rows[2][4].ToString();
                actor = GetMovie().Rows[2][5].ToString();
                director = GetMovie().Rows[2][6].ToString();
                producer = GetMovie().Rows[2][7].ToString();
                studio = GetMovie().Rows[2][8].ToString();
                date = GetMovie().Rows[2][9].ToString();
                time = GetMovie().Rows[2][10].ToString();
                age = GetMovie().Rows[2][11].ToString();
                timestart = GetMovie().Rows[2][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBoxphim4_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 5)
            {
                name = GetMovie().Rows[4][1].ToString();
                pic = GetMovie().Rows[4][2].ToString();
                category = GetMovie().Rows[4][3].ToString();
                content = GetMovie().Rows[4][4].ToString();
                actor = GetMovie().Rows[4][5].ToString();
                director = GetMovie().Rows[4][6].ToString();
                producer = GetMovie().Rows[4][7].ToString();
                studio = GetMovie().Rows[4][8].ToString();
                date = GetMovie().Rows[4][9].ToString();
                time = GetMovie().Rows[4][10].ToString();
                age = GetMovie().Rows[4][11].ToString();
                timestart = GetMovie().Rows[4][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBoxphim3_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 7)
            {
                name = GetMovie().Rows[6][1].ToString();
                pic = GetMovie().Rows[6][2].ToString();
                category = GetMovie().Rows[6][3].ToString();
                content = GetMovie().Rows[6][4].ToString();
                actor = GetMovie().Rows[6][5].ToString();
                director = GetMovie().Rows[6][6].ToString();
                producer = GetMovie().Rows[6][7].ToString();
                studio = GetMovie().Rows[6][8].ToString();
                date = GetMovie().Rows[6][9].ToString();
                time = GetMovie().Rows[6][10].ToString();
                age = GetMovie().Rows[6][11].ToString();
                timestart = GetMovie().Rows[6][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 9)
            {
                name = GetMovie().Rows[8][1].ToString();
                pic = GetMovie().Rows[8][2].ToString();
                category = GetMovie().Rows[8][3].ToString();
                content = GetMovie().Rows[8][4].ToString();
                actor = GetMovie().Rows[8][5].ToString();
                director = GetMovie().Rows[8][6].ToString();
                producer = GetMovie().Rows[8][7].ToString();
                studio = GetMovie().Rows[8][8].ToString();
                date = GetMovie().Rows[8][9].ToString();
                time = GetMovie().Rows[8][10].ToString();
                age = GetMovie().Rows[8][11].ToString();
                timestart = GetMovie().Rows[8][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 11)
            {
                name = GetMovie().Rows[10][1].ToString();
                pic = GetMovie().Rows[10][2].ToString();
                category = GetMovie().Rows[10][3].ToString();
                content = GetMovie().Rows[10][4].ToString();
                actor = GetMovie().Rows[10][5].ToString();
                director = GetMovie().Rows[10][6].ToString();
                producer = GetMovie().Rows[10][7].ToString();
                studio = GetMovie().Rows[10][8].ToString();
                date = GetMovie().Rows[10][9].ToString();
                time = GetMovie().Rows[10][10].ToString();
                age = GetMovie().Rows[10][11].ToString();
                timestart = GetMovie().Rows[10][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 12)
            {
                name = GetMovie().Rows[11][1].ToString();
                pic = GetMovie().Rows[11][2].ToString();
                category = GetMovie().Rows[11][3].ToString();
                content = GetMovie().Rows[11][4].ToString();
                actor = GetMovie().Rows[11][5].ToString();
                director = GetMovie().Rows[11][6].ToString();
                producer = GetMovie().Rows[11][7].ToString();
                studio = GetMovie().Rows[11][8].ToString();
                date = GetMovie().Rows[11][9].ToString();
                time = GetMovie().Rows[11][10].ToString();
                age = GetMovie().Rows[11][11].ToString();
                timestart = GetMovie().Rows[11][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox24_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 10)
            {
                name = GetMovie().Rows[9][1].ToString();
                pic = GetMovie().Rows[9][2].ToString();
                category = GetMovie().Rows[9][3].ToString();
                content = GetMovie().Rows[9][4].ToString();
                actor = GetMovie().Rows[9][5].ToString();
                director = GetMovie().Rows[9][6].ToString();
                producer = GetMovie().Rows[9][7].ToString();
                studio = GetMovie().Rows[9][8].ToString();
                date = GetMovie().Rows[9][9].ToString();
                time = GetMovie().Rows[9][10].ToString();
                age = GetMovie().Rows[9][11].ToString();
                timestart = GetMovie().Rows[9][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox26_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 8)
            {
                name = GetMovie().Rows[7][1].ToString();
                pic = GetMovie().Rows[7][2].ToString();
                category = GetMovie().Rows[7][3].ToString();
                content = GetMovie().Rows[7][4].ToString();
                actor = GetMovie().Rows[7][5].ToString();
                director = GetMovie().Rows[7][6].ToString();
                producer = GetMovie().Rows[7][7].ToString();
                studio = GetMovie().Rows[7][8].ToString();
                date = GetMovie().Rows[7][9].ToString();
                time = GetMovie().Rows[7][10].ToString();
                age = GetMovie().Rows[7][11].ToString();
                timestart = GetMovie().Rows[7][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 6)
            {
                name = GetMovie().Rows[5][1].ToString();
                pic = GetMovie().Rows[5][2].ToString();
                category = GetMovie().Rows[5][3].ToString();
                content = GetMovie().Rows[5][4].ToString();
                actor = GetMovie().Rows[5][5].ToString();
                director = GetMovie().Rows[5][6].ToString();
                producer = GetMovie().Rows[5][7].ToString();
                studio = GetMovie().Rows[5][8].ToString();
                date = GetMovie().Rows[5][9].ToString();
                time = GetMovie().Rows[5][10].ToString();
                age = GetMovie().Rows[5][11].ToString();
                timestart = GetMovie().Rows[5][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBoxphim5_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 4)
            {
                name = GetMovie().Rows[3][1].ToString();
                pic = GetMovie().Rows[3][2].ToString();
                category = GetMovie().Rows[3][3].ToString();
                content = GetMovie().Rows[3][4].ToString();
                actor = GetMovie().Rows[3][5].ToString();
                director = GetMovie().Rows[3][6].ToString();
                producer = GetMovie().Rows[3][7].ToString();
                studio = GetMovie().Rows[3][8].ToString();
                date = GetMovie().Rows[3][9].ToString();
                time = GetMovie().Rows[3][10].ToString();
                age = GetMovie().Rows[3][11].ToString();
                timestart = GetMovie().Rows[3][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 2)
            {
                name = GetMovie().Rows[1][1].ToString();
                pic = GetMovie().Rows[1][2].ToString();
                category = GetMovie().Rows[1][3].ToString();
                content = GetMovie().Rows[1][4].ToString();
                actor = GetMovie().Rows[1][5].ToString();
                director = GetMovie().Rows[1][6].ToString();
                producer = GetMovie().Rows[1][7].ToString();
                studio = GetMovie().Rows[1][8].ToString();
                date = GetMovie().Rows[1][9].ToString();
                time = GetMovie().Rows[1][10].ToString();
                age = GetMovie().Rows[1][11].ToString();
                timestart = GetMovie().Rows[1][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 13)
            {
                name = GetMovie().Rows[12][1].ToString();
                pic = GetMovie().Rows[12][2].ToString();
                category = GetMovie().Rows[12][3].ToString();
                content = GetMovie().Rows[12][4].ToString();
                actor = GetMovie().Rows[12][5].ToString();
                director = GetMovie().Rows[12][6].ToString();
                producer = GetMovie().Rows[12][7].ToString();
                studio = GetMovie().Rows[12][8].ToString();
                date = GetMovie().Rows[12][9].ToString();
                time = GetMovie().Rows[12][10].ToString();
                age = GetMovie().Rows[12][11].ToString();
                timestart = GetMovie().Rows[12][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox20_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 15)
            {
                name = GetMovie().Rows[14][1].ToString();
                pic = GetMovie().Rows[14][2].ToString();
                category = GetMovie().Rows[14][3].ToString();
                content = GetMovie().Rows[14][4].ToString();
                actor = GetMovie().Rows[14][5].ToString();
                director = GetMovie().Rows[14][6].ToString();
                producer = GetMovie().Rows[14][7].ToString();
                studio = GetMovie().Rows[14][8].ToString();
                date = GetMovie().Rows[14][9].ToString();
                time = GetMovie().Rows[14][10].ToString();
                age = GetMovie().Rows[14][11].ToString();
                timestart = GetMovie().Rows[14][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 17)
            {
                name = GetMovie().Rows[16][1].ToString();
                pic = GetMovie().Rows[16][2].ToString();
                category = GetMovie().Rows[16][3].ToString();
                content = GetMovie().Rows[16][4].ToString();
                actor = GetMovie().Rows[16][5].ToString();
                director = GetMovie().Rows[16][6].ToString();
                producer = GetMovie().Rows[16][7].ToString();
                studio = GetMovie().Rows[16][8].ToString();
                date = GetMovie().Rows[16][9].ToString();
                time = GetMovie().Rows[16][10].ToString();
                age = GetMovie().Rows[16][11].ToString();
                timestart = GetMovie().Rows[16][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox23_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 19)
            {
                name = GetMovie().Rows[18][1].ToString();
                pic = GetMovie().Rows[18][2].ToString();
                category = GetMovie().Rows[18][3].ToString();
                content = GetMovie().Rows[18][4].ToString();
                actor = GetMovie().Rows[18][5].ToString();
                director = GetMovie().Rows[18][6].ToString();
                producer = GetMovie().Rows[18][7].ToString();
                studio = GetMovie().Rows[18][8].ToString();
                date = GetMovie().Rows[18][9].ToString();
                time = GetMovie().Rows[18][10].ToString();
                age = GetMovie().Rows[18][11].ToString();
                timestart = GetMovie().Rows[18][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox22_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 21)
            {
                name = GetMovie().Rows[20][1].ToString();
                pic = GetMovie().Rows[20][2].ToString();
                category = GetMovie().Rows[20][3].ToString();
                content = GetMovie().Rows[20][4].ToString();
                actor = GetMovie().Rows[20][5].ToString();
                director = GetMovie().Rows[20][6].ToString();
                producer = GetMovie().Rows[20][7].ToString();
                studio = GetMovie().Rows[20][8].ToString();
                date = GetMovie().Rows[20][9].ToString();
                time = GetMovie().Rows[20][10].ToString();
                age = GetMovie().Rows[20][11].ToString();
                timestart = GetMovie().Rows[20][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox21_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 22)
            {
                name = GetMovie().Rows[21][1].ToString();
                pic = GetMovie().Rows[21][2].ToString();
                category = GetMovie().Rows[21][3].ToString();
                content = GetMovie().Rows[21][4].ToString();
                actor = GetMovie().Rows[21][5].ToString();
                director = GetMovie().Rows[21][6].ToString();
                producer = GetMovie().Rows[21][7].ToString();
                studio = GetMovie().Rows[21][8].ToString();
                date = GetMovie().Rows[21][9].ToString();
                time = GetMovie().Rows[21][10].ToString();
                age = GetMovie().Rows[21][11].ToString();
                timestart = GetMovie().Rows[21][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 20)
            {
                name = GetMovie().Rows[19][1].ToString();
                pic = GetMovie().Rows[19][2].ToString();
                category = GetMovie().Rows[19][3].ToString();
                content = GetMovie().Rows[19][4].ToString();
                actor = GetMovie().Rows[19][5].ToString();
                director = GetMovie().Rows[19][6].ToString();
                producer = GetMovie().Rows[19][7].ToString();
                studio = GetMovie().Rows[19][8].ToString();
                date = GetMovie().Rows[19][9].ToString();
                time = GetMovie().Rows[19][10].ToString();
                age = GetMovie().Rows[19][11].ToString();
                timestart = GetMovie().Rows[19][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 18)
            {
                name = GetMovie().Rows[17][1].ToString();
                pic = GetMovie().Rows[17][2].ToString();
                category = GetMovie().Rows[17][3].ToString();
                content = GetMovie().Rows[17][4].ToString();
                actor = GetMovie().Rows[17][5].ToString();
                director = GetMovie().Rows[17][6].ToString();
                producer = GetMovie().Rows[17][7].ToString();
                studio = GetMovie().Rows[17][8].ToString();
                date = GetMovie().Rows[17][9].ToString();
                time = GetMovie().Rows[17][10].ToString();
                age = GetMovie().Rows[17][11].ToString();
                timestart = GetMovie().Rows[17][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 16)
            {
                name = GetMovie().Rows[15][1].ToString();
                pic = GetMovie().Rows[15][2].ToString();
                category = GetMovie().Rows[15][3].ToString();
                content = GetMovie().Rows[15][4].ToString();
                actor = GetMovie().Rows[15][5].ToString();
                director = GetMovie().Rows[15][6].ToString();
                producer = GetMovie().Rows[15][7].ToString();
                studio = GetMovie().Rows[15][8].ToString();
                date = GetMovie().Rows[15][9].ToString();
                time = GetMovie().Rows[15][10].ToString();
                age = GetMovie().Rows[15][11].ToString();
                timestart = GetMovie().Rows[15][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 14)
            {
                name = GetMovie().Rows[13][1].ToString();
                pic = GetMovie().Rows[13][2].ToString();
                category = GetMovie().Rows[13][3].ToString();
                content = GetMovie().Rows[13][4].ToString();
                actor = GetMovie().Rows[13][5].ToString();
                director = GetMovie().Rows[13][6].ToString();
                producer = GetMovie().Rows[13][7].ToString();
                studio = GetMovie().Rows[13][8].ToString();
                date = GetMovie().Rows[13][9].ToString();
                time = GetMovie().Rows[13][10].ToString();
                age = GetMovie().Rows[13][11].ToString();
                timestart = GetMovie().Rows[13][12].ToString();
            }
            Information buyticket = new Information(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket.ShowDialog();
            buyticket.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 3)
            {
                name = GetMovie().Rows[2][1].ToString();
                pic = GetMovie().Rows[2][2].ToString();
                category = GetMovie().Rows[2][3].ToString();
                content = GetMovie().Rows[2][4].ToString();
                actor = GetMovie().Rows[2][5].ToString();
                director = GetMovie().Rows[2][6].ToString();
                producer = GetMovie().Rows[2][7].ToString();
                studio = GetMovie().Rows[2][8].ToString();
                date = GetMovie().Rows[2][9].ToString();
                time = GetMovie().Rows[2][10].ToString();
                age = GetMovie().Rows[2][11].ToString();
                timestart = GetMovie().Rows[2][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            buyticket1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 5)
            {
                name = GetMovie().Rows[4][1].ToString();
                pic = GetMovie().Rows[4][2].ToString();
                category = GetMovie().Rows[4][3].ToString();
                content = GetMovie().Rows[4][4].ToString();
                actor = GetMovie().Rows[4][5].ToString();
                director = GetMovie().Rows[4][6].ToString();
                producer = GetMovie().Rows[4][7].ToString();
                studio = GetMovie().Rows[4][8].ToString();
                date = GetMovie().Rows[4][9].ToString();
                time = GetMovie().Rows[4][10].ToString();
                age = GetMovie().Rows[4][11].ToString();
                timestart = GetMovie().Rows[4][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 7)
            {
                name = GetMovie().Rows[6][1].ToString();
                pic = GetMovie().Rows[6][2].ToString();
                category = GetMovie().Rows[6][3].ToString();
                content = GetMovie().Rows[6][4].ToString();
                actor = GetMovie().Rows[6][5].ToString();
                director = GetMovie().Rows[6][6].ToString();
                producer = GetMovie().Rows[6][7].ToString();
                studio = GetMovie().Rows[6][8].ToString();
                date = GetMovie().Rows[6][9].ToString();
                time = GetMovie().Rows[6][10].ToString();
                age = GetMovie().Rows[6][11].ToString();
                timestart = GetMovie().Rows[6][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 9)
            {
                name = GetMovie().Rows[8][1].ToString();
                pic = GetMovie().Rows[8][2].ToString();
                category = GetMovie().Rows[8][3].ToString();
                content = GetMovie().Rows[8][4].ToString();
                actor = GetMovie().Rows[8][5].ToString();
                director = GetMovie().Rows[8][6].ToString();
                producer = GetMovie().Rows[8][7].ToString();
                studio = GetMovie().Rows[8][8].ToString();
                date = GetMovie().Rows[8][9].ToString();
                time = GetMovie().Rows[8][10].ToString();
                age = GetMovie().Rows[8][11].ToString();
                timestart = GetMovie().Rows[8][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 11)
            {
                name = GetMovie().Rows[10][1].ToString();
                pic = GetMovie().Rows[10][2].ToString();
                category = GetMovie().Rows[10][3].ToString();
                content = GetMovie().Rows[10][4].ToString();
                actor = GetMovie().Rows[10][5].ToString();
                director = GetMovie().Rows[10][6].ToString();
                producer = GetMovie().Rows[10][7].ToString();
                studio = GetMovie().Rows[10][8].ToString();
                date = GetMovie().Rows[10][9].ToString();
                time = GetMovie().Rows[10][10].ToString();
                age = GetMovie().Rows[10][11].ToString();
                timestart = GetMovie().Rows[10][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 12)
            {
                name = GetMovie().Rows[11][1].ToString();
                pic = GetMovie().Rows[11][2].ToString();
                category = GetMovie().Rows[11][3].ToString();
                content = GetMovie().Rows[11][4].ToString();
                actor = GetMovie().Rows[11][5].ToString();
                director = GetMovie().Rows[11][6].ToString();
                producer = GetMovie().Rows[11][7].ToString();
                studio = GetMovie().Rows[11][8].ToString();
                date = GetMovie().Rows[11][9].ToString();
                time = GetMovie().Rows[11][10].ToString();
                age = GetMovie().Rows[11][11].ToString();
                timestart = GetMovie().Rows[11][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 10)
            {
                name = GetMovie().Rows[9][1].ToString();
                pic = GetMovie().Rows[9][2].ToString();
                category = GetMovie().Rows[9][3].ToString();
                content = GetMovie().Rows[9][4].ToString();
                actor = GetMovie().Rows[9][5].ToString();
                director = GetMovie().Rows[9][6].ToString();
                producer = GetMovie().Rows[9][7].ToString();
                studio = GetMovie().Rows[9][8].ToString();
                date = GetMovie().Rows[9][9].ToString();
                time = GetMovie().Rows[9][10].ToString();
                age = GetMovie().Rows[9][11].ToString();
                timestart = GetMovie().Rows[9][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 8)
            {
                name = GetMovie().Rows[7][1].ToString();
                pic = GetMovie().Rows[7][2].ToString();
                category = GetMovie().Rows[7][3].ToString();
                content = GetMovie().Rows[7][4].ToString();
                actor = GetMovie().Rows[7][5].ToString();
                director = GetMovie().Rows[7][6].ToString();
                producer = GetMovie().Rows[7][7].ToString();
                studio = GetMovie().Rows[7][8].ToString();
                date = GetMovie().Rows[7][9].ToString();
                time = GetMovie().Rows[7][10].ToString();
                age = GetMovie().Rows[7][11].ToString();
                timestart = GetMovie().Rows[7][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 6)
            {
                name = GetMovie().Rows[5][1].ToString();
                pic = GetMovie().Rows[5][2].ToString();
                category = GetMovie().Rows[5][3].ToString();
                content = GetMovie().Rows[5][4].ToString();
                actor = GetMovie().Rows[5][5].ToString();
                director = GetMovie().Rows[5][6].ToString();
                producer = GetMovie().Rows[5][7].ToString();
                studio = GetMovie().Rows[5][8].ToString();
                date = GetMovie().Rows[5][9].ToString();
                time = GetMovie().Rows[5][10].ToString();
                age = GetMovie().Rows[5][11].ToString();
                timestart = GetMovie().Rows[5][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 4)
            {
                name = GetMovie().Rows[3][1].ToString();
                pic = GetMovie().Rows[3][2].ToString();
                category = GetMovie().Rows[3][3].ToString();
                content = GetMovie().Rows[3][4].ToString();
                actor = GetMovie().Rows[3][5].ToString();
                director = GetMovie().Rows[3][6].ToString();
                producer = GetMovie().Rows[3][7].ToString();
                studio = GetMovie().Rows[3][8].ToString();
                date = GetMovie().Rows[3][9].ToString();
                time = GetMovie().Rows[3][10].ToString();
                age = GetMovie().Rows[3][11].ToString();
                timestart = GetMovie().Rows[3][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 2)
            {
                name = GetMovie().Rows[1][1].ToString();
                pic = GetMovie().Rows[1][2].ToString();
                category = GetMovie().Rows[1][3].ToString();
                content = GetMovie().Rows[1][4].ToString();
                actor = GetMovie().Rows[1][5].ToString();
                director = GetMovie().Rows[1][6].ToString();
                producer = GetMovie().Rows[1][7].ToString();
                studio = GetMovie().Rows[1][8].ToString();
                date = GetMovie().Rows[1][9].ToString();
                time = GetMovie().Rows[1][10].ToString();
                age = GetMovie().Rows[1][11].ToString();
                timestart = GetMovie().Rows[1][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 13)
            {
                name = GetMovie().Rows[12][1].ToString();
                pic = GetMovie().Rows[12][2].ToString();
                category = GetMovie().Rows[12][3].ToString();
                content = GetMovie().Rows[12][4].ToString();
                actor = GetMovie().Rows[12][5].ToString();
                director = GetMovie().Rows[12][6].ToString();
                producer = GetMovie().Rows[12][7].ToString();
                studio = GetMovie().Rows[12][8].ToString();
                date = GetMovie().Rows[12][9].ToString();
                time = GetMovie().Rows[12][10].ToString();
                age = GetMovie().Rows[12][11].ToString();
                timestart = GetMovie().Rows[12][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 15)
            {
                name = GetMovie().Rows[14][1].ToString();
                pic = GetMovie().Rows[14][2].ToString();
                category = GetMovie().Rows[14][3].ToString();
                content = GetMovie().Rows[14][4].ToString();
                actor = GetMovie().Rows[14][5].ToString();
                director = GetMovie().Rows[14][6].ToString();
                producer = GetMovie().Rows[14][7].ToString();
                studio = GetMovie().Rows[14][8].ToString();
                date = GetMovie().Rows[14][9].ToString();
                time = GetMovie().Rows[14][10].ToString();
                age = GetMovie().Rows[14][11].ToString();
                timestart = GetMovie().Rows[14][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 17)
            {
                name = GetMovie().Rows[16][1].ToString();
                pic = GetMovie().Rows[16][2].ToString();
                category = GetMovie().Rows[16][3].ToString();
                content = GetMovie().Rows[16][4].ToString();
                actor = GetMovie().Rows[16][5].ToString();
                director = GetMovie().Rows[16][6].ToString();
                producer = GetMovie().Rows[16][7].ToString();
                studio = GetMovie().Rows[16][8].ToString();
                date = GetMovie().Rows[16][9].ToString();
                time = GetMovie().Rows[16][10].ToString();
                age = GetMovie().Rows[16][11].ToString();
                timestart = GetMovie().Rows[16][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 19)
            {
                name = GetMovie().Rows[18][1].ToString();
                pic = GetMovie().Rows[18][2].ToString();
                category = GetMovie().Rows[18][3].ToString();
                content = GetMovie().Rows[18][4].ToString();
                actor = GetMovie().Rows[18][5].ToString();
                director = GetMovie().Rows[18][6].ToString();
                producer = GetMovie().Rows[18][7].ToString();
                studio = GetMovie().Rows[18][8].ToString();
                date = GetMovie().Rows[18][9].ToString();
                time = GetMovie().Rows[18][10].ToString();
                age = GetMovie().Rows[18][11].ToString();
                timestart = GetMovie().Rows[18][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 21)
            {
                name = GetMovie().Rows[20][1].ToString();
                pic = GetMovie().Rows[20][2].ToString();
                category = GetMovie().Rows[20][3].ToString();
                content = GetMovie().Rows[20][4].ToString();
                actor = GetMovie().Rows[20][5].ToString();
                director = GetMovie().Rows[20][6].ToString();
                producer = GetMovie().Rows[20][7].ToString();
                studio = GetMovie().Rows[20][8].ToString();
                date = GetMovie().Rows[20][9].ToString();
                time = GetMovie().Rows[20][10].ToString();
                age = GetMovie().Rows[20][11].ToString();
                timestart = GetMovie().Rows[20][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 14)
            {
                name = GetMovie().Rows[13][1].ToString();
                pic = GetMovie().Rows[13][2].ToString();
                category = GetMovie().Rows[13][3].ToString();
                content = GetMovie().Rows[13][4].ToString();
                actor = GetMovie().Rows[13][5].ToString();
                director = GetMovie().Rows[13][6].ToString();
                producer = GetMovie().Rows[13][7].ToString();
                studio = GetMovie().Rows[13][8].ToString();
                date = GetMovie().Rows[13][9].ToString();
                time = GetMovie().Rows[13][10].ToString();
                age = GetMovie().Rows[13][11].ToString();
                timestart = GetMovie().Rows[13][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 16)
            {
                name = GetMovie().Rows[15][1].ToString();
                pic = GetMovie().Rows[15][2].ToString();
                category = GetMovie().Rows[15][3].ToString();
                content = GetMovie().Rows[15][4].ToString();
                actor = GetMovie().Rows[15][5].ToString();
                director = GetMovie().Rows[15][6].ToString();
                producer = GetMovie().Rows[15][7].ToString();
                studio = GetMovie().Rows[15][8].ToString();
                date = GetMovie().Rows[15][9].ToString();
                time = GetMovie().Rows[15][10].ToString();
                age = GetMovie().Rows[15][11].ToString();
                timestart = GetMovie().Rows[15][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 18)
            {
                name = GetMovie().Rows[17][1].ToString();
                pic = GetMovie().Rows[17][2].ToString();
                category = GetMovie().Rows[17][3].ToString();
                content = GetMovie().Rows[17][4].ToString();
                actor = GetMovie().Rows[17][5].ToString();
                director = GetMovie().Rows[17][6].ToString();
                producer = GetMovie().Rows[17][7].ToString();
                studio = GetMovie().Rows[17][8].ToString();
                date = GetMovie().Rows[17][9].ToString();
                time = GetMovie().Rows[17][10].ToString();
                age = GetMovie().Rows[17][11].ToString();
                timestart = GetMovie().Rows[17][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 20)
            {
                name = GetMovie().Rows[19][1].ToString();
                pic = GetMovie().Rows[19][2].ToString();
                category = GetMovie().Rows[19][3].ToString();
                content = GetMovie().Rows[19][4].ToString();
                actor = GetMovie().Rows[19][5].ToString();
                director = GetMovie().Rows[19][6].ToString();
                producer = GetMovie().Rows[19][7].ToString();
                studio = GetMovie().Rows[19][8].ToString();
                date = GetMovie().Rows[19][9].ToString();
                time = GetMovie().Rows[19][10].ToString();
                age = GetMovie().Rows[19][11].ToString();
                timestart = GetMovie().Rows[19][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(GetNumberMovie().Rows[0][0].ToString()) >= 22)
            {
                name = GetMovie().Rows[21][1].ToString();
                pic = GetMovie().Rows[21][2].ToString();
                category = GetMovie().Rows[21][3].ToString();
                content = GetMovie().Rows[21][4].ToString();
                actor = GetMovie().Rows[21][5].ToString();
                director = GetMovie().Rows[21][6].ToString();
                producer = GetMovie().Rows[21][7].ToString();
                studio = GetMovie().Rows[21][8].ToString();
                date = GetMovie().Rows[21][9].ToString();
                time = GetMovie().Rows[21][10].ToString();
                age = GetMovie().Rows[21][11].ToString();
                timestart = GetMovie().Rows[21][12].ToString();
            }
            BuyTicket buyticket1 = new BuyTicket(timestart, user1, pic, name, category, content, actor, director, producer, studio, date, time, age);
            this.Hide();
            buyticket1.ShowDialog();
            this.Show();
        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {
                if (panelMenu.Visible == true)
                    panelMenu.Visible = false;
                if (panelMenu.Visible == false)
                    pictureBoxMenuShow.Visible = true;
        }

        private void pictureBoxMenuHide_Click(object sender, EventArgs e)
        {
            if (panelMenu.Visible == true)
                pictureBoxMenuHide.Visible = false;
            if(panelMenu.Visible == false)
                panelMenu.Visible = true;
        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            if(user1 == "")
            {
                Login login = new Login();
                this.Hide();
                login.ShowDialog();
                this.Show();
            }
            else if(user1 != "")
            {
                Bill bill = new Bill();
                this.Hide();
                bill.ShowDialog();
                this.Show();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (user1 == "")
            {
                SignUp signUp = new SignUp();
                this.Hide();
                signUp.ShowDialog();
                this.Show();
            }
            else if (user1 != "")
            {
                this.Close();
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {

        }

        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DateTime d1 = DateTime.Now;
            string day = d1.AddDays(1).Day.ToString();
            string month = d1.AddDays(1).Month.ToString();
            string year = d1.AddDays(1).Year.ToString();
            string dateNew = year + "/" + month + "/" + day;
            MessageBox.Show(dateNew);
        }
    }
}
