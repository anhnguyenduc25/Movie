﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class Information : Form
    {
        string user1;
        string pic1;
        string name1;
        string category1;
        string content1;
        string actor1;
        string director1;
        string producer1;
        string studio1;
        string date1;
        string time1;
        string age1;
        string timestart1;
        public Information(string timestart, string user, string pic, string name, string category, string content, string actor, string director, string producer, string studio, string date, string time, string age)
        {
            InitializeComponent();
            timestart1 = timestart;
            user1 = user;
            pic1 = pic;
            name1 = name;
            category1 = category;
            content1 = content;
            actor1 = actor;
            director1 = director;
            producer1 = producer;
            studio1 = studio;
            date1 = date;
            time1 = time;
            age1 = age;
            pictureBoxPhim.BackgroundImage = Image.FromFile(pic);
            labelName.Text = name;
            labelContent.Text = content;
            labelActor.Text = actor;
            labelDirector.Text = director;
            labelProducer.Text = producer;
            labelStudio.Text = studio;
            labelDate.Text = date;
            labelTime.Text = time;
            labelAge.Text = age;
            if(labelProducer.Text == "")
            {
                label10.Text = "";
            }
            if (labelStudio.Text == "")
            {
                label12.Text = "";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            buttonInformation.BackColor = Color.Salmon;
            buttonBuyTicket.BackColor = Color.White;
            buttonCalendar.BackColor = Color.White;
            buttonEvaluate.BackColor = Color.White;
            buttonNews.BackColor = Color.White;
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Calendar buyticket = new Calendar(timestart1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
            this.Close();
            buyticket.ShowDialog();
            this.Show();
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            buttonEvaluate.BackColor = Color.Salmon;
            buttonBuyTicket.BackColor = Color.White;
            buttonCalendar.BackColor = Color.White;
            buttonInformation.BackColor = Color.White;
            buttonNews.BackColor = Color.White;
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            buttonNews.BackColor = Color.Salmon;
            buttonBuyTicket.BackColor = Color.White;
            buttonCalendar.BackColor = Color.White;
            buttonEvaluate.BackColor = Color.White;
            buttonInformation.BackColor = Color.White;
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            BuyTicket buyticket = new BuyTicket(timestart1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
            this.Close();
            buyticket.ShowDialog();
            this.Show();
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BuyTicket buyticket = new BuyTicket(timestart1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
            this.Close();
            buyticket.ShowDialog();
            this.Show();
        }

        public void pictureBoxPhim_Click(object sender, EventArgs e)
        {
            
        }

        public void labelName_Click(object sender, EventArgs e)
        {

        }

        public void labelActor_Click(object sender, EventArgs e)
        {

        }

        public void labelDirector_Click(object sender, EventArgs e)
        {

        }

        public void labelProducer_Click(object sender, EventArgs e)
        {

        }

        public void labelStudio_Click(object sender, EventArgs e)
        {

        }

        public void labelContent_Click(object sender, EventArgs e)
        {

        }

        public void labelDate_Click(object sender, EventArgs e)
        {

        }

        public void labelTime_Click(object sender, EventArgs e)
        {

        }

        public void labelAge_Click(object sender, EventArgs e)
        {

        }

        private void Information_Load(object sender, EventArgs e)
        {
            
        }
    }
}
