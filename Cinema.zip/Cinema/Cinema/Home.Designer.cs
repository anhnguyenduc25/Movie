﻿
namespace Cinema
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBoxMenuHide = new System.Windows.Forms.PictureBox();
            this.buttonPhim22 = new System.Windows.Forms.Button();
            this.buttonPhim21 = new System.Windows.Forms.Button();
            this.buttonPhim20 = new System.Windows.Forms.Button();
            this.buttonPhim18 = new System.Windows.Forms.Button();
            this.buttonPhim19 = new System.Windows.Forms.Button();
            this.buttonPhim17 = new System.Windows.Forms.Button();
            this.buttonPhim16 = new System.Windows.Forms.Button();
            this.buttonPhim14 = new System.Windows.Forms.Button();
            this.buttonPhim15 = new System.Windows.Forms.Button();
            this.buttonPhim13 = new System.Windows.Forms.Button();
            this.buttonPhim12 = new System.Windows.Forms.Button();
            this.buttonPhim10 = new System.Windows.Forms.Button();
            this.buttonPhim11 = new System.Windows.Forms.Button();
            this.buttonPhim9 = new System.Windows.Forms.Button();
            this.buttonPhim8 = new System.Windows.Forms.Button();
            this.buttonPhim6 = new System.Windows.Forms.Button();
            this.buttonPhim4 = new System.Windows.Forms.Button();
            this.buttonPhim2 = new System.Windows.Forms.Button();
            this.buttonPhim7 = new System.Windows.Forms.Button();
            this.buttonPhim5 = new System.Windows.Forms.Button();
            this.buttonPhim3 = new System.Windows.Forms.Button();
            this.buttonPhim1 = new System.Windows.Forms.Button();
            this.labelCategory12 = new System.Windows.Forms.Label();
            this.labelName12 = new System.Windows.Forms.Label();
            this.labelCategory14 = new System.Windows.Forms.Label();
            this.labelName14 = new System.Windows.Forms.Label();
            this.labelCategory16 = new System.Windows.Forms.Label();
            this.labelName16 = new System.Windows.Forms.Label();
            this.labelCategory18 = new System.Windows.Forms.Label();
            this.labelName18 = new System.Windows.Forms.Label();
            this.labelCategory20 = new System.Windows.Forms.Label();
            this.labelName20 = new System.Windows.Forms.Label();
            this.labelCategory22 = new System.Windows.Forms.Label();
            this.labelName22 = new System.Windows.Forms.Label();
            this.labelCategory21 = new System.Windows.Forms.Label();
            this.labelName21 = new System.Windows.Forms.Label();
            this.labelCategory19 = new System.Windows.Forms.Label();
            this.labelName19 = new System.Windows.Forms.Label();
            this.labelCategory17 = new System.Windows.Forms.Label();
            this.labelName17 = new System.Windows.Forms.Label();
            this.labelCategory15 = new System.Windows.Forms.Label();
            this.labelName15 = new System.Windows.Forms.Label();
            this.labelCategory13 = new System.Windows.Forms.Label();
            this.labelName13 = new System.Windows.Forms.Label();
            this.labelCategory11 = new System.Windows.Forms.Label();
            this.labelName11 = new System.Windows.Forms.Label();
            this.labelCategory10 = new System.Windows.Forms.Label();
            this.labelName10 = new System.Windows.Forms.Label();
            this.labelCategory8 = new System.Windows.Forms.Label();
            this.labelName8 = new System.Windows.Forms.Label();
            this.labelCategory6 = new System.Windows.Forms.Label();
            this.labelName6 = new System.Windows.Forms.Label();
            this.labelCategory4 = new System.Windows.Forms.Label();
            this.labelName4 = new System.Windows.Forms.Label();
            this.labelCategory9 = new System.Windows.Forms.Label();
            this.labelName9 = new System.Windows.Forms.Label();
            this.labelCategory7 = new System.Windows.Forms.Label();
            this.labelName7 = new System.Windows.Forms.Label();
            this.labelCategory5 = new System.Windows.Forms.Label();
            this.labelName5 = new System.Windows.Forms.Label();
            this.labelCategory2 = new System.Windows.Forms.Label();
            this.labelName2 = new System.Windows.Forms.Label();
            this.labelCategory3 = new System.Windows.Forms.Label();
            this.labelName3 = new System.Windows.Forms.Label();
            this.pictureBoxphim13 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim10 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim14 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim20 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim16 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim18 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim12 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim6 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBoxphim15 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim22 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim21 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim19 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim11 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim9 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim17 = new System.Windows.Forms.PictureBox();
            this.labelCategory1 = new System.Windows.Forms.Label();
            this.labelName1 = new System.Windows.Forms.Label();
            this.pictureBoxphim2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxphim7 = new System.Windows.Forms.PictureBox();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBoxMenuShow = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBoxposter2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxposter1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxposter3 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMenuHide)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim7)).BeginInit();
            this.panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMenuShow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxposter2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxposter1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxposter3)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 3500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.pictureBoxMenuHide);
            this.panel1.Controls.Add(this.buttonPhim22);
            this.panel1.Controls.Add(this.buttonPhim21);
            this.panel1.Controls.Add(this.buttonPhim20);
            this.panel1.Controls.Add(this.buttonPhim18);
            this.panel1.Controls.Add(this.buttonPhim19);
            this.panel1.Controls.Add(this.buttonPhim17);
            this.panel1.Controls.Add(this.buttonPhim16);
            this.panel1.Controls.Add(this.buttonPhim14);
            this.panel1.Controls.Add(this.buttonPhim15);
            this.panel1.Controls.Add(this.buttonPhim13);
            this.panel1.Controls.Add(this.buttonPhim12);
            this.panel1.Controls.Add(this.buttonPhim10);
            this.panel1.Controls.Add(this.buttonPhim11);
            this.panel1.Controls.Add(this.buttonPhim9);
            this.panel1.Controls.Add(this.buttonPhim8);
            this.panel1.Controls.Add(this.buttonPhim6);
            this.panel1.Controls.Add(this.buttonPhim4);
            this.panel1.Controls.Add(this.buttonPhim2);
            this.panel1.Controls.Add(this.buttonPhim7);
            this.panel1.Controls.Add(this.buttonPhim5);
            this.panel1.Controls.Add(this.buttonPhim3);
            this.panel1.Controls.Add(this.buttonPhim1);
            this.panel1.Controls.Add(this.labelCategory12);
            this.panel1.Controls.Add(this.labelName12);
            this.panel1.Controls.Add(this.labelCategory14);
            this.panel1.Controls.Add(this.labelName14);
            this.panel1.Controls.Add(this.labelCategory16);
            this.panel1.Controls.Add(this.labelName16);
            this.panel1.Controls.Add(this.labelCategory18);
            this.panel1.Controls.Add(this.labelName18);
            this.panel1.Controls.Add(this.labelCategory20);
            this.panel1.Controls.Add(this.labelName20);
            this.panel1.Controls.Add(this.labelCategory22);
            this.panel1.Controls.Add(this.labelName22);
            this.panel1.Controls.Add(this.labelCategory21);
            this.panel1.Controls.Add(this.labelName21);
            this.panel1.Controls.Add(this.labelCategory19);
            this.panel1.Controls.Add(this.labelName19);
            this.panel1.Controls.Add(this.labelCategory17);
            this.panel1.Controls.Add(this.labelName17);
            this.panel1.Controls.Add(this.labelCategory15);
            this.panel1.Controls.Add(this.labelName15);
            this.panel1.Controls.Add(this.labelCategory13);
            this.panel1.Controls.Add(this.labelName13);
            this.panel1.Controls.Add(this.labelCategory11);
            this.panel1.Controls.Add(this.labelName11);
            this.panel1.Controls.Add(this.labelCategory10);
            this.panel1.Controls.Add(this.labelName10);
            this.panel1.Controls.Add(this.labelCategory8);
            this.panel1.Controls.Add(this.labelName8);
            this.panel1.Controls.Add(this.labelCategory6);
            this.panel1.Controls.Add(this.labelName6);
            this.panel1.Controls.Add(this.labelCategory4);
            this.panel1.Controls.Add(this.labelName4);
            this.panel1.Controls.Add(this.labelCategory9);
            this.panel1.Controls.Add(this.labelName9);
            this.panel1.Controls.Add(this.labelCategory7);
            this.panel1.Controls.Add(this.labelName7);
            this.panel1.Controls.Add(this.labelCategory5);
            this.panel1.Controls.Add(this.labelName5);
            this.panel1.Controls.Add(this.labelCategory2);
            this.panel1.Controls.Add(this.labelName2);
            this.panel1.Controls.Add(this.labelCategory3);
            this.panel1.Controls.Add(this.labelName3);
            this.panel1.Controls.Add(this.pictureBoxphim13);
            this.panel1.Controls.Add(this.pictureBoxphim10);
            this.panel1.Controls.Add(this.pictureBoxphim8);
            this.panel1.Controls.Add(this.pictureBoxphim14);
            this.panel1.Controls.Add(this.pictureBoxphim20);
            this.panel1.Controls.Add(this.pictureBoxphim16);
            this.panel1.Controls.Add(this.pictureBoxphim18);
            this.panel1.Controls.Add(this.pictureBoxphim12);
            this.panel1.Controls.Add(this.pictureBoxphim6);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBoxphim15);
            this.panel1.Controls.Add(this.pictureBoxphim22);
            this.panel1.Controls.Add(this.pictureBoxphim21);
            this.panel1.Controls.Add(this.pictureBoxphim19);
            this.panel1.Controls.Add(this.pictureBoxphim11);
            this.panel1.Controls.Add(this.pictureBoxphim9);
            this.panel1.Controls.Add(this.pictureBoxphim17);
            this.panel1.Controls.Add(this.labelCategory1);
            this.panel1.Controls.Add(this.labelName1);
            this.panel1.Controls.Add(this.pictureBoxphim2);
            this.panel1.Controls.Add(this.pictureBoxphim4);
            this.panel1.Controls.Add(this.pictureBoxphim1);
            this.panel1.Controls.Add(this.pictureBoxphim5);
            this.panel1.Controls.Add(this.pictureBoxphim3);
            this.panel1.Controls.Add(this.pictureBoxphim7);
            this.panel1.Location = new System.Drawing.Point(3, 183);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1657, 811);
            this.panel1.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(256, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 25);
            this.label5.TabIndex = 169;
            // 
            // pictureBoxMenuHide
            // 
            this.pictureBoxMenuHide.BackColor = System.Drawing.Color.White;
            this.pictureBoxMenuHide.BackgroundImage = global::Cinema.Properties.Resources.square1;
            this.pictureBoxMenuHide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxMenuHide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxMenuHide.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxMenuHide.Name = "pictureBoxMenuHide";
            this.pictureBoxMenuHide.Size = new System.Drawing.Size(53, 52);
            this.pictureBoxMenuHide.TabIndex = 168;
            this.pictureBoxMenuHide.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBoxMenuHide, "Đăng nhập\r\nĐăng ký");
            this.pictureBoxMenuHide.Click += new System.EventHandler(this.pictureBoxMenuHide_Click);
            // 
            // buttonPhim22
            // 
            this.buttonPhim22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim22.ForeColor = System.Drawing.Color.White;
            this.buttonPhim22.Location = new System.Drawing.Point(2378, 699);
            this.buttonPhim22.Name = "buttonPhim22";
            this.buttonPhim22.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim22.TabIndex = 167;
            this.buttonPhim22.Text = "Đặt vé";
            this.buttonPhim22.UseVisualStyleBackColor = false;
            this.buttonPhim22.Visible = false;
            this.buttonPhim22.Click += new System.EventHandler(this.button22_Click);
            // 
            // buttonPhim21
            // 
            this.buttonPhim21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim21.ForeColor = System.Drawing.Color.White;
            this.buttonPhim21.Location = new System.Drawing.Point(2378, 328);
            this.buttonPhim21.Name = "buttonPhim21";
            this.buttonPhim21.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim21.TabIndex = 166;
            this.buttonPhim21.Text = "Đặt vé";
            this.buttonPhim21.UseVisualStyleBackColor = false;
            this.buttonPhim21.Visible = false;
            this.buttonPhim21.Click += new System.EventHandler(this.button21_Click);
            // 
            // buttonPhim20
            // 
            this.buttonPhim20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim20.ForeColor = System.Drawing.Color.White;
            this.buttonPhim20.Location = new System.Drawing.Point(2148, 699);
            this.buttonPhim20.Name = "buttonPhim20";
            this.buttonPhim20.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim20.TabIndex = 165;
            this.buttonPhim20.Text = "Đặt vé";
            this.buttonPhim20.UseVisualStyleBackColor = false;
            this.buttonPhim20.Visible = false;
            this.buttonPhim20.Click += new System.EventHandler(this.button19_Click);
            // 
            // buttonPhim18
            // 
            this.buttonPhim18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim18.ForeColor = System.Drawing.Color.White;
            this.buttonPhim18.Location = new System.Drawing.Point(1915, 699);
            this.buttonPhim18.Name = "buttonPhim18";
            this.buttonPhim18.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim18.TabIndex = 164;
            this.buttonPhim18.Text = "Đặt vé";
            this.buttonPhim18.UseVisualStyleBackColor = false;
            this.buttonPhim18.Visible = false;
            this.buttonPhim18.Click += new System.EventHandler(this.button20_Click);
            // 
            // buttonPhim19
            // 
            this.buttonPhim19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim19.ForeColor = System.Drawing.Color.White;
            this.buttonPhim19.Location = new System.Drawing.Point(2148, 328);
            this.buttonPhim19.Name = "buttonPhim19";
            this.buttonPhim19.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim19.TabIndex = 163;
            this.buttonPhim19.Text = "Đặt vé";
            this.buttonPhim19.UseVisualStyleBackColor = false;
            this.buttonPhim19.Visible = false;
            this.buttonPhim19.Click += new System.EventHandler(this.button17_Click);
            // 
            // buttonPhim17
            // 
            this.buttonPhim17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim17.ForeColor = System.Drawing.Color.White;
            this.buttonPhim17.Location = new System.Drawing.Point(1915, 328);
            this.buttonPhim17.Name = "buttonPhim17";
            this.buttonPhim17.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim17.TabIndex = 162;
            this.buttonPhim17.Text = "Đặt vé";
            this.buttonPhim17.UseVisualStyleBackColor = false;
            this.buttonPhim17.Visible = false;
            this.buttonPhim17.Click += new System.EventHandler(this.button18_Click);
            // 
            // buttonPhim16
            // 
            this.buttonPhim16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim16.ForeColor = System.Drawing.Color.White;
            this.buttonPhim16.Location = new System.Drawing.Point(1685, 699);
            this.buttonPhim16.Name = "buttonPhim16";
            this.buttonPhim16.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim16.TabIndex = 161;
            this.buttonPhim16.Text = "Đặt vé";
            this.buttonPhim16.UseVisualStyleBackColor = false;
            this.buttonPhim16.Visible = false;
            this.buttonPhim16.Click += new System.EventHandler(this.button15_Click);
            // 
            // buttonPhim14
            // 
            this.buttonPhim14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim14.ForeColor = System.Drawing.Color.White;
            this.buttonPhim14.Location = new System.Drawing.Point(1452, 699);
            this.buttonPhim14.Name = "buttonPhim14";
            this.buttonPhim14.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim14.TabIndex = 160;
            this.buttonPhim14.Text = "Đặt vé";
            this.buttonPhim14.UseVisualStyleBackColor = false;
            this.buttonPhim14.Visible = false;
            this.buttonPhim14.Click += new System.EventHandler(this.button16_Click);
            // 
            // buttonPhim15
            // 
            this.buttonPhim15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim15.ForeColor = System.Drawing.Color.White;
            this.buttonPhim15.Location = new System.Drawing.Point(1685, 328);
            this.buttonPhim15.Name = "buttonPhim15";
            this.buttonPhim15.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim15.TabIndex = 159;
            this.buttonPhim15.Text = "Đặt vé";
            this.buttonPhim15.UseVisualStyleBackColor = false;
            this.buttonPhim15.Visible = false;
            this.buttonPhim15.Click += new System.EventHandler(this.button13_Click);
            // 
            // buttonPhim13
            // 
            this.buttonPhim13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim13.ForeColor = System.Drawing.Color.White;
            this.buttonPhim13.Location = new System.Drawing.Point(1452, 328);
            this.buttonPhim13.Name = "buttonPhim13";
            this.buttonPhim13.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim13.TabIndex = 158;
            this.buttonPhim13.Text = "Đặt vé";
            this.buttonPhim13.UseVisualStyleBackColor = false;
            this.buttonPhim13.Visible = false;
            this.buttonPhim13.Click += new System.EventHandler(this.button14_Click);
            // 
            // buttonPhim12
            // 
            this.buttonPhim12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim12.ForeColor = System.Drawing.Color.White;
            this.buttonPhim12.Location = new System.Drawing.Point(1221, 699);
            this.buttonPhim12.Name = "buttonPhim12";
            this.buttonPhim12.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim12.TabIndex = 157;
            this.buttonPhim12.Text = "Đặt vé";
            this.buttonPhim12.UseVisualStyleBackColor = false;
            this.buttonPhim12.Visible = false;
            this.buttonPhim12.Click += new System.EventHandler(this.button11_Click);
            // 
            // buttonPhim10
            // 
            this.buttonPhim10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim10.ForeColor = System.Drawing.Color.White;
            this.buttonPhim10.Location = new System.Drawing.Point(992, 699);
            this.buttonPhim10.Name = "buttonPhim10";
            this.buttonPhim10.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim10.TabIndex = 156;
            this.buttonPhim10.Text = "Đặt vé";
            this.buttonPhim10.UseVisualStyleBackColor = false;
            this.buttonPhim10.Visible = false;
            this.buttonPhim10.Click += new System.EventHandler(this.button12_Click);
            // 
            // buttonPhim11
            // 
            this.buttonPhim11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim11.ForeColor = System.Drawing.Color.White;
            this.buttonPhim11.Location = new System.Drawing.Point(1221, 328);
            this.buttonPhim11.Name = "buttonPhim11";
            this.buttonPhim11.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim11.TabIndex = 155;
            this.buttonPhim11.Text = "Đặt vé";
            this.buttonPhim11.UseVisualStyleBackColor = false;
            this.buttonPhim11.Visible = false;
            this.buttonPhim11.Click += new System.EventHandler(this.button9_Click);
            // 
            // buttonPhim9
            // 
            this.buttonPhim9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim9.ForeColor = System.Drawing.Color.White;
            this.buttonPhim9.Location = new System.Drawing.Point(992, 328);
            this.buttonPhim9.Name = "buttonPhim9";
            this.buttonPhim9.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim9.TabIndex = 154;
            this.buttonPhim9.Text = "Đặt vé";
            this.buttonPhim9.UseVisualStyleBackColor = false;
            this.buttonPhim9.Visible = false;
            this.buttonPhim9.Click += new System.EventHandler(this.button10_Click);
            // 
            // buttonPhim8
            // 
            this.buttonPhim8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim8.ForeColor = System.Drawing.Color.White;
            this.buttonPhim8.Location = new System.Drawing.Point(766, 699);
            this.buttonPhim8.Name = "buttonPhim8";
            this.buttonPhim8.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim8.TabIndex = 153;
            this.buttonPhim8.Text = "Đặt vé";
            this.buttonPhim8.UseVisualStyleBackColor = false;
            this.buttonPhim8.Visible = false;
            this.buttonPhim8.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonPhim6
            // 
            this.buttonPhim6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim6.ForeColor = System.Drawing.Color.White;
            this.buttonPhim6.Location = new System.Drawing.Point(537, 699);
            this.buttonPhim6.Name = "buttonPhim6";
            this.buttonPhim6.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim6.TabIndex = 152;
            this.buttonPhim6.Text = "Đặt vé";
            this.buttonPhim6.UseVisualStyleBackColor = false;
            this.buttonPhim6.Visible = false;
            this.buttonPhim6.Click += new System.EventHandler(this.button8_Click);
            // 
            // buttonPhim4
            // 
            this.buttonPhim4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim4.ForeColor = System.Drawing.Color.White;
            this.buttonPhim4.Location = new System.Drawing.Point(312, 699);
            this.buttonPhim4.Name = "buttonPhim4";
            this.buttonPhim4.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim4.TabIndex = 151;
            this.buttonPhim4.Text = "Đặt vé";
            this.buttonPhim4.UseVisualStyleBackColor = false;
            this.buttonPhim4.Visible = false;
            this.buttonPhim4.Click += new System.EventHandler(this.button5_Click);
            // 
            // buttonPhim2
            // 
            this.buttonPhim2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim2.ForeColor = System.Drawing.Color.White;
            this.buttonPhim2.Location = new System.Drawing.Point(83, 699);
            this.buttonPhim2.Name = "buttonPhim2";
            this.buttonPhim2.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim2.TabIndex = 150;
            this.buttonPhim2.Text = "Đặt vé";
            this.buttonPhim2.UseVisualStyleBackColor = false;
            this.buttonPhim2.Visible = false;
            this.buttonPhim2.Click += new System.EventHandler(this.button6_Click);
            // 
            // buttonPhim7
            // 
            this.buttonPhim7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim7.ForeColor = System.Drawing.Color.White;
            this.buttonPhim7.Location = new System.Drawing.Point(766, 328);
            this.buttonPhim7.Name = "buttonPhim7";
            this.buttonPhim7.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim7.TabIndex = 149;
            this.buttonPhim7.Text = "Đặt vé";
            this.buttonPhim7.UseVisualStyleBackColor = false;
            this.buttonPhim7.Visible = false;
            this.buttonPhim7.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonPhim5
            // 
            this.buttonPhim5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim5.ForeColor = System.Drawing.Color.White;
            this.buttonPhim5.Location = new System.Drawing.Point(537, 328);
            this.buttonPhim5.Name = "buttonPhim5";
            this.buttonPhim5.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim5.TabIndex = 148;
            this.buttonPhim5.Text = "Đặt vé";
            this.buttonPhim5.UseVisualStyleBackColor = false;
            this.buttonPhim5.Visible = false;
            this.buttonPhim5.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonPhim3
            // 
            this.buttonPhim3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim3.ForeColor = System.Drawing.Color.White;
            this.buttonPhim3.Location = new System.Drawing.Point(312, 328);
            this.buttonPhim3.Name = "buttonPhim3";
            this.buttonPhim3.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim3.TabIndex = 147;
            this.buttonPhim3.Text = "Đặt vé";
            this.buttonPhim3.UseVisualStyleBackColor = false;
            this.buttonPhim3.Visible = false;
            this.buttonPhim3.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonPhim1
            // 
            this.buttonPhim1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.buttonPhim1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPhim1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhim1.ForeColor = System.Drawing.Color.White;
            this.buttonPhim1.Location = new System.Drawing.Point(83, 328);
            this.buttonPhim1.Name = "buttonPhim1";
            this.buttonPhim1.Size = new System.Drawing.Size(82, 32);
            this.buttonPhim1.TabIndex = 146;
            this.buttonPhim1.Text = "Đặt vé";
            this.buttonPhim1.UseVisualStyleBackColor = false;
            this.buttonPhim1.Visible = false;
            this.buttonPhim1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelCategory12
            // 
            this.labelCategory12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory12.ForeColor = System.Drawing.Color.White;
            this.labelCategory12.Location = new System.Drawing.Point(1163, 760);
            this.labelCategory12.Name = "labelCategory12";
            this.labelCategory12.Size = new System.Drawing.Size(213, 23);
            this.labelCategory12.TabIndex = 145;
            // 
            // labelName12
            // 
            this.labelName12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName12.ForeColor = System.Drawing.Color.White;
            this.labelName12.Location = new System.Drawing.Point(1163, 737);
            this.labelName12.Name = "labelName12";
            this.labelName12.Size = new System.Drawing.Size(200, 23);
            this.labelName12.TabIndex = 144;
            // 
            // labelCategory14
            // 
            this.labelCategory14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory14.ForeColor = System.Drawing.Color.White;
            this.labelCategory14.Location = new System.Drawing.Point(1394, 760);
            this.labelCategory14.Name = "labelCategory14";
            this.labelCategory14.Size = new System.Drawing.Size(213, 23);
            this.labelCategory14.TabIndex = 143;
            // 
            // labelName14
            // 
            this.labelName14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName14.ForeColor = System.Drawing.Color.White;
            this.labelName14.Location = new System.Drawing.Point(1394, 737);
            this.labelName14.Name = "labelName14";
            this.labelName14.Size = new System.Drawing.Size(200, 23);
            this.labelName14.TabIndex = 142;
            // 
            // labelCategory16
            // 
            this.labelCategory16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory16.ForeColor = System.Drawing.Color.White;
            this.labelCategory16.Location = new System.Drawing.Point(1624, 760);
            this.labelCategory16.Name = "labelCategory16";
            this.labelCategory16.Size = new System.Drawing.Size(213, 23);
            this.labelCategory16.TabIndex = 141;
            // 
            // labelName16
            // 
            this.labelName16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName16.ForeColor = System.Drawing.Color.White;
            this.labelName16.Location = new System.Drawing.Point(1624, 737);
            this.labelName16.Name = "labelName16";
            this.labelName16.Size = new System.Drawing.Size(200, 23);
            this.labelName16.TabIndex = 140;
            // 
            // labelCategory18
            // 
            this.labelCategory18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory18.ForeColor = System.Drawing.Color.White;
            this.labelCategory18.Location = new System.Drawing.Point(1858, 760);
            this.labelCategory18.Name = "labelCategory18";
            this.labelCategory18.Size = new System.Drawing.Size(213, 23);
            this.labelCategory18.TabIndex = 139;
            // 
            // labelName18
            // 
            this.labelName18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName18.ForeColor = System.Drawing.Color.White;
            this.labelName18.Location = new System.Drawing.Point(1858, 737);
            this.labelName18.Name = "labelName18";
            this.labelName18.Size = new System.Drawing.Size(200, 23);
            this.labelName18.TabIndex = 138;
            // 
            // labelCategory20
            // 
            this.labelCategory20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory20.ForeColor = System.Drawing.Color.White;
            this.labelCategory20.Location = new System.Drawing.Point(2087, 760);
            this.labelCategory20.Name = "labelCategory20";
            this.labelCategory20.Size = new System.Drawing.Size(213, 23);
            this.labelCategory20.TabIndex = 137;
            // 
            // labelName20
            // 
            this.labelName20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName20.ForeColor = System.Drawing.Color.White;
            this.labelName20.Location = new System.Drawing.Point(2087, 737);
            this.labelName20.Name = "labelName20";
            this.labelName20.Size = new System.Drawing.Size(200, 23);
            this.labelName20.TabIndex = 136;
            // 
            // labelCategory22
            // 
            this.labelCategory22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory22.ForeColor = System.Drawing.Color.White;
            this.labelCategory22.Location = new System.Drawing.Point(2315, 760);
            this.labelCategory22.Name = "labelCategory22";
            this.labelCategory22.Size = new System.Drawing.Size(213, 23);
            this.labelCategory22.TabIndex = 135;
            // 
            // labelName22
            // 
            this.labelName22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName22.ForeColor = System.Drawing.Color.White;
            this.labelName22.Location = new System.Drawing.Point(2315, 737);
            this.labelName22.Name = "labelName22";
            this.labelName22.Size = new System.Drawing.Size(200, 23);
            this.labelName22.TabIndex = 134;
            // 
            // labelCategory21
            // 
            this.labelCategory21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory21.ForeColor = System.Drawing.Color.White;
            this.labelCategory21.Location = new System.Drawing.Point(2314, 389);
            this.labelCategory21.Name = "labelCategory21";
            this.labelCategory21.Size = new System.Drawing.Size(213, 23);
            this.labelCategory21.TabIndex = 133;
            // 
            // labelName21
            // 
            this.labelName21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName21.ForeColor = System.Drawing.Color.White;
            this.labelName21.Location = new System.Drawing.Point(2314, 366);
            this.labelName21.Name = "labelName21";
            this.labelName21.Size = new System.Drawing.Size(200, 23);
            this.labelName21.TabIndex = 132;
            // 
            // labelCategory19
            // 
            this.labelCategory19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory19.ForeColor = System.Drawing.Color.White;
            this.labelCategory19.Location = new System.Drawing.Point(2087, 389);
            this.labelCategory19.Name = "labelCategory19";
            this.labelCategory19.Size = new System.Drawing.Size(213, 23);
            this.labelCategory19.TabIndex = 131;
            // 
            // labelName19
            // 
            this.labelName19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName19.ForeColor = System.Drawing.Color.White;
            this.labelName19.Location = new System.Drawing.Point(2087, 366);
            this.labelName19.Name = "labelName19";
            this.labelName19.Size = new System.Drawing.Size(200, 23);
            this.labelName19.TabIndex = 130;
            // 
            // labelCategory17
            // 
            this.labelCategory17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory17.ForeColor = System.Drawing.Color.White;
            this.labelCategory17.Location = new System.Drawing.Point(1857, 389);
            this.labelCategory17.Name = "labelCategory17";
            this.labelCategory17.Size = new System.Drawing.Size(213, 23);
            this.labelCategory17.TabIndex = 129;
            // 
            // labelName17
            // 
            this.labelName17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName17.ForeColor = System.Drawing.Color.White;
            this.labelName17.Location = new System.Drawing.Point(1857, 366);
            this.labelName17.Name = "labelName17";
            this.labelName17.Size = new System.Drawing.Size(200, 23);
            this.labelName17.TabIndex = 128;
            // 
            // labelCategory15
            // 
            this.labelCategory15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory15.ForeColor = System.Drawing.Color.White;
            this.labelCategory15.Location = new System.Drawing.Point(1624, 389);
            this.labelCategory15.Name = "labelCategory15";
            this.labelCategory15.Size = new System.Drawing.Size(213, 23);
            this.labelCategory15.TabIndex = 127;
            // 
            // labelName15
            // 
            this.labelName15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName15.ForeColor = System.Drawing.Color.White;
            this.labelName15.Location = new System.Drawing.Point(1624, 366);
            this.labelName15.Name = "labelName15";
            this.labelName15.Size = new System.Drawing.Size(200, 23);
            this.labelName15.TabIndex = 126;
            // 
            // labelCategory13
            // 
            this.labelCategory13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory13.ForeColor = System.Drawing.Color.White;
            this.labelCategory13.Location = new System.Drawing.Point(1393, 389);
            this.labelCategory13.Name = "labelCategory13";
            this.labelCategory13.Size = new System.Drawing.Size(213, 23);
            this.labelCategory13.TabIndex = 125;
            // 
            // labelName13
            // 
            this.labelName13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName13.ForeColor = System.Drawing.Color.White;
            this.labelName13.Location = new System.Drawing.Point(1393, 366);
            this.labelName13.Name = "labelName13";
            this.labelName13.Size = new System.Drawing.Size(200, 23);
            this.labelName13.TabIndex = 124;
            // 
            // labelCategory11
            // 
            this.labelCategory11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory11.ForeColor = System.Drawing.Color.White;
            this.labelCategory11.Location = new System.Drawing.Point(1163, 389);
            this.labelCategory11.Name = "labelCategory11";
            this.labelCategory11.Size = new System.Drawing.Size(213, 23);
            this.labelCategory11.TabIndex = 123;
            // 
            // labelName11
            // 
            this.labelName11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName11.ForeColor = System.Drawing.Color.White;
            this.labelName11.Location = new System.Drawing.Point(1163, 366);
            this.labelName11.Name = "labelName11";
            this.labelName11.Size = new System.Drawing.Size(200, 23);
            this.labelName11.TabIndex = 122;
            // 
            // labelCategory10
            // 
            this.labelCategory10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory10.ForeColor = System.Drawing.Color.White;
            this.labelCategory10.Location = new System.Drawing.Point(932, 760);
            this.labelCategory10.Name = "labelCategory10";
            this.labelCategory10.Size = new System.Drawing.Size(213, 23);
            this.labelCategory10.TabIndex = 121;
            // 
            // labelName10
            // 
            this.labelName10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName10.ForeColor = System.Drawing.Color.White;
            this.labelName10.Location = new System.Drawing.Point(932, 737);
            this.labelName10.Name = "labelName10";
            this.labelName10.Size = new System.Drawing.Size(200, 23);
            this.labelName10.TabIndex = 120;
            // 
            // labelCategory8
            // 
            this.labelCategory8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory8.ForeColor = System.Drawing.Color.White;
            this.labelCategory8.Location = new System.Drawing.Point(703, 760);
            this.labelCategory8.Name = "labelCategory8";
            this.labelCategory8.Size = new System.Drawing.Size(213, 23);
            this.labelCategory8.TabIndex = 119;
            // 
            // labelName8
            // 
            this.labelName8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName8.ForeColor = System.Drawing.Color.White;
            this.labelName8.Location = new System.Drawing.Point(703, 737);
            this.labelName8.Name = "labelName8";
            this.labelName8.Size = new System.Drawing.Size(200, 23);
            this.labelName8.TabIndex = 118;
            // 
            // labelCategory6
            // 
            this.labelCategory6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory6.ForeColor = System.Drawing.Color.White;
            this.labelCategory6.Location = new System.Drawing.Point(474, 757);
            this.labelCategory6.Name = "labelCategory6";
            this.labelCategory6.Size = new System.Drawing.Size(213, 23);
            this.labelCategory6.TabIndex = 117;
            // 
            // labelName6
            // 
            this.labelName6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName6.ForeColor = System.Drawing.Color.White;
            this.labelName6.Location = new System.Drawing.Point(474, 734);
            this.labelName6.Name = "labelName6";
            this.labelName6.Size = new System.Drawing.Size(200, 23);
            this.labelName6.TabIndex = 116;
            // 
            // labelCategory4
            // 
            this.labelCategory4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory4.ForeColor = System.Drawing.Color.White;
            this.labelCategory4.Location = new System.Drawing.Point(252, 760);
            this.labelCategory4.Name = "labelCategory4";
            this.labelCategory4.Size = new System.Drawing.Size(213, 23);
            this.labelCategory4.TabIndex = 115;
            // 
            // labelName4
            // 
            this.labelName4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName4.ForeColor = System.Drawing.Color.White;
            this.labelName4.Location = new System.Drawing.Point(252, 737);
            this.labelName4.Name = "labelName4";
            this.labelName4.Size = new System.Drawing.Size(200, 23);
            this.labelName4.TabIndex = 114;
            // 
            // labelCategory9
            // 
            this.labelCategory9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory9.ForeColor = System.Drawing.Color.White;
            this.labelCategory9.Location = new System.Drawing.Point(933, 389);
            this.labelCategory9.Name = "labelCategory9";
            this.labelCategory9.Size = new System.Drawing.Size(213, 23);
            this.labelCategory9.TabIndex = 113;
            // 
            // labelName9
            // 
            this.labelName9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName9.ForeColor = System.Drawing.Color.White;
            this.labelName9.Location = new System.Drawing.Point(933, 366);
            this.labelName9.Name = "labelName9";
            this.labelName9.Size = new System.Drawing.Size(200, 23);
            this.labelName9.TabIndex = 112;
            // 
            // labelCategory7
            // 
            this.labelCategory7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory7.ForeColor = System.Drawing.Color.White;
            this.labelCategory7.Location = new System.Drawing.Point(703, 389);
            this.labelCategory7.Name = "labelCategory7";
            this.labelCategory7.Size = new System.Drawing.Size(213, 23);
            this.labelCategory7.TabIndex = 111;
            // 
            // labelName7
            // 
            this.labelName7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName7.ForeColor = System.Drawing.Color.White;
            this.labelName7.Location = new System.Drawing.Point(703, 366);
            this.labelName7.Name = "labelName7";
            this.labelName7.Size = new System.Drawing.Size(200, 23);
            this.labelName7.TabIndex = 110;
            // 
            // labelCategory5
            // 
            this.labelCategory5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory5.ForeColor = System.Drawing.Color.White;
            this.labelCategory5.Location = new System.Drawing.Point(478, 389);
            this.labelCategory5.Name = "labelCategory5";
            this.labelCategory5.Size = new System.Drawing.Size(213, 23);
            this.labelCategory5.TabIndex = 109;
            // 
            // labelName5
            // 
            this.labelName5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName5.ForeColor = System.Drawing.Color.White;
            this.labelName5.Location = new System.Drawing.Point(478, 366);
            this.labelName5.Name = "labelName5";
            this.labelName5.Size = new System.Drawing.Size(200, 23);
            this.labelName5.TabIndex = 108;
            // 
            // labelCategory2
            // 
            this.labelCategory2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory2.ForeColor = System.Drawing.Color.White;
            this.labelCategory2.Location = new System.Drawing.Point(25, 760);
            this.labelCategory2.Name = "labelCategory2";
            this.labelCategory2.Size = new System.Drawing.Size(213, 23);
            this.labelCategory2.TabIndex = 107;
            // 
            // labelName2
            // 
            this.labelName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName2.ForeColor = System.Drawing.Color.White;
            this.labelName2.Location = new System.Drawing.Point(25, 737);
            this.labelName2.Name = "labelName2";
            this.labelName2.Size = new System.Drawing.Size(200, 23);
            this.labelName2.TabIndex = 106;
            // 
            // labelCategory3
            // 
            this.labelCategory3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory3.ForeColor = System.Drawing.Color.White;
            this.labelCategory3.Location = new System.Drawing.Point(252, 389);
            this.labelCategory3.Name = "labelCategory3";
            this.labelCategory3.Size = new System.Drawing.Size(213, 23);
            this.labelCategory3.TabIndex = 105;
            // 
            // labelName3
            // 
            this.labelName3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName3.ForeColor = System.Drawing.Color.White;
            this.labelName3.Location = new System.Drawing.Point(252, 366);
            this.labelName3.Name = "labelName3";
            this.labelName3.Size = new System.Drawing.Size(200, 23);
            this.labelName3.TabIndex = 104;
            // 
            // pictureBoxphim13
            // 
            this.pictureBoxphim13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim13.Location = new System.Drawing.Point(1393, 60);
            this.pictureBoxphim13.Name = "pictureBoxphim13";
            this.pictureBoxphim13.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim13.TabIndex = 103;
            this.pictureBoxphim13.TabStop = false;
            this.pictureBoxphim13.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // pictureBoxphim10
            // 
            this.pictureBoxphim10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim10.Location = new System.Drawing.Point(933, 431);
            this.pictureBoxphim10.Name = "pictureBoxphim10";
            this.pictureBoxphim10.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim10.TabIndex = 102;
            this.pictureBoxphim10.TabStop = false;
            this.pictureBoxphim10.Click += new System.EventHandler(this.pictureBox24_Click);
            // 
            // pictureBoxphim8
            // 
            this.pictureBoxphim8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim8.Location = new System.Drawing.Point(703, 431);
            this.pictureBoxphim8.Name = "pictureBoxphim8";
            this.pictureBoxphim8.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim8.TabIndex = 100;
            this.pictureBoxphim8.TabStop = false;
            this.pictureBoxphim8.Click += new System.EventHandler(this.pictureBox26_Click);
            // 
            // pictureBoxphim14
            // 
            this.pictureBoxphim14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim14.Location = new System.Drawing.Point(1393, 431);
            this.pictureBoxphim14.Name = "pictureBoxphim14";
            this.pictureBoxphim14.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim14.TabIndex = 94;
            this.pictureBoxphim14.TabStop = false;
            this.pictureBoxphim14.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBoxphim20
            // 
            this.pictureBoxphim20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim20.Location = new System.Drawing.Point(2087, 431);
            this.pictureBoxphim20.Name = "pictureBoxphim20";
            this.pictureBoxphim20.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim20.TabIndex = 93;
            this.pictureBoxphim20.TabStop = false;
            this.pictureBoxphim20.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBoxphim16
            // 
            this.pictureBoxphim16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim16.Location = new System.Drawing.Point(1624, 431);
            this.pictureBoxphim16.Name = "pictureBoxphim16";
            this.pictureBoxphim16.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim16.TabIndex = 90;
            this.pictureBoxphim16.TabStop = false;
            this.pictureBoxphim16.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBoxphim18
            // 
            this.pictureBoxphim18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim18.Location = new System.Drawing.Point(1857, 431);
            this.pictureBoxphim18.Name = "pictureBoxphim18";
            this.pictureBoxphim18.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim18.TabIndex = 92;
            this.pictureBoxphim18.TabStop = false;
            this.pictureBoxphim18.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBoxphim12
            // 
            this.pictureBoxphim12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim12.Location = new System.Drawing.Point(1163, 431);
            this.pictureBoxphim12.Name = "pictureBoxphim12";
            this.pictureBoxphim12.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim12.TabIndex = 89;
            this.pictureBoxphim12.TabStop = false;
            this.pictureBoxphim12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBoxphim6
            // 
            this.pictureBoxphim6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim6.Location = new System.Drawing.Point(478, 431);
            this.pictureBoxphim6.Name = "pictureBoxphim6";
            this.pictureBoxphim6.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim6.TabIndex = 91;
            this.pictureBoxphim6.TabStop = false;
            this.pictureBoxphim6.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(64, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 24);
            this.label2.TabIndex = 87;
            this.label2.Text = "⭐Mới ra mắt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(63, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 25);
            this.label1.TabIndex = 86;
            this.label1.Text = "Phim đang chiếu:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBoxphim15
            // 
            this.pictureBoxphim15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim15.Location = new System.Drawing.Point(1624, 60);
            this.pictureBoxphim15.Name = "pictureBoxphim15";
            this.pictureBoxphim15.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim15.TabIndex = 85;
            this.pictureBoxphim15.TabStop = false;
            this.pictureBoxphim15.Click += new System.EventHandler(this.pictureBox20_Click);
            // 
            // pictureBoxphim22
            // 
            this.pictureBoxphim22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim22.Location = new System.Drawing.Point(2317, 431);
            this.pictureBoxphim22.Name = "pictureBoxphim22";
            this.pictureBoxphim22.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim22.TabIndex = 84;
            this.pictureBoxphim22.TabStop = false;
            this.pictureBoxphim22.Click += new System.EventHandler(this.pictureBox21_Click);
            // 
            // pictureBoxphim21
            // 
            this.pictureBoxphim21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim21.Location = new System.Drawing.Point(2320, 60);
            this.pictureBoxphim21.Name = "pictureBoxphim21";
            this.pictureBoxphim21.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim21.TabIndex = 83;
            this.pictureBoxphim21.TabStop = false;
            this.pictureBoxphim21.Click += new System.EventHandler(this.pictureBox22_Click);
            // 
            // pictureBoxphim19
            // 
            this.pictureBoxphim19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim19.Location = new System.Drawing.Point(2087, 60);
            this.pictureBoxphim19.Name = "pictureBoxphim19";
            this.pictureBoxphim19.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim19.TabIndex = 82;
            this.pictureBoxphim19.TabStop = false;
            this.pictureBoxphim19.Click += new System.EventHandler(this.pictureBox23_Click);
            // 
            // pictureBoxphim11
            // 
            this.pictureBoxphim11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim11.Location = new System.Drawing.Point(1163, 60);
            this.pictureBoxphim11.Name = "pictureBoxphim11";
            this.pictureBoxphim11.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim11.TabIndex = 81;
            this.pictureBoxphim11.TabStop = false;
            this.pictureBoxphim11.Click += new System.EventHandler(this.pictureBox16_Click);
            // 
            // pictureBoxphim9
            // 
            this.pictureBoxphim9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim9.Location = new System.Drawing.Point(933, 60);
            this.pictureBoxphim9.Name = "pictureBoxphim9";
            this.pictureBoxphim9.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim9.TabIndex = 80;
            this.pictureBoxphim9.TabStop = false;
            this.pictureBoxphim9.Click += new System.EventHandler(this.pictureBox17_Click);
            // 
            // pictureBoxphim17
            // 
            this.pictureBoxphim17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim17.Location = new System.Drawing.Point(1857, 60);
            this.pictureBoxphim17.Name = "pictureBoxphim17";
            this.pictureBoxphim17.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim17.TabIndex = 79;
            this.pictureBoxphim17.TabStop = false;
            this.pictureBoxphim17.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // labelCategory1
            // 
            this.labelCategory1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory1.ForeColor = System.Drawing.Color.White;
            this.labelCategory1.Location = new System.Drawing.Point(25, 389);
            this.labelCategory1.Name = "labelCategory1";
            this.labelCategory1.Size = new System.Drawing.Size(213, 23);
            this.labelCategory1.TabIndex = 78;
            // 
            // labelName1
            // 
            this.labelName1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName1.ForeColor = System.Drawing.Color.White;
            this.labelName1.Location = new System.Drawing.Point(25, 366);
            this.labelName1.Name = "labelName1";
            this.labelName1.Size = new System.Drawing.Size(200, 23);
            this.labelName1.TabIndex = 77;
            // 
            // pictureBoxphim2
            // 
            this.pictureBoxphim2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim2.Location = new System.Drawing.Point(25, 431);
            this.pictureBoxphim2.Name = "pictureBoxphim2";
            this.pictureBoxphim2.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim2.TabIndex = 76;
            this.pictureBoxphim2.TabStop = false;
            this.pictureBoxphim2.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBoxphim4
            // 
            this.pictureBoxphim4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim4.Location = new System.Drawing.Point(252, 431);
            this.pictureBoxphim4.Name = "pictureBoxphim4";
            this.pictureBoxphim4.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim4.TabIndex = 75;
            this.pictureBoxphim4.TabStop = false;
            this.pictureBoxphim4.Click += new System.EventHandler(this.pictureBoxphim5_Click);
            // 
            // pictureBoxphim1
            // 
            this.pictureBoxphim1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim1.Location = new System.Drawing.Point(25, 60);
            this.pictureBoxphim1.Name = "pictureBoxphim1";
            this.pictureBoxphim1.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim1.TabIndex = 72;
            this.pictureBoxphim1.TabStop = false;
            this.pictureBoxphim1.Click += new System.EventHandler(this.pictureBoxphim1_Click);
            // 
            // pictureBoxphim5
            // 
            this.pictureBoxphim5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim5.Location = new System.Drawing.Point(478, 60);
            this.pictureBoxphim5.Name = "pictureBoxphim5";
            this.pictureBoxphim5.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim5.TabIndex = 74;
            this.pictureBoxphim5.TabStop = false;
            this.pictureBoxphim5.Click += new System.EventHandler(this.pictureBoxphim4_Click);
            // 
            // pictureBoxphim3
            // 
            this.pictureBoxphim3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim3.Location = new System.Drawing.Point(252, 60);
            this.pictureBoxphim3.Name = "pictureBoxphim3";
            this.pictureBoxphim3.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim3.TabIndex = 71;
            this.pictureBoxphim3.TabStop = false;
            this.pictureBoxphim3.Click += new System.EventHandler(this.pictureBoxphim2_Click);
            // 
            // pictureBoxphim7
            // 
            this.pictureBoxphim7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxphim7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxphim7.Location = new System.Drawing.Point(703, 60);
            this.pictureBoxphim7.Name = "pictureBoxphim7";
            this.pictureBoxphim7.Size = new System.Drawing.Size(200, 300);
            this.pictureBoxphim7.TabIndex = 73;
            this.pictureBoxphim7.TabStop = false;
            this.pictureBoxphim7.Click += new System.EventHandler(this.pictureBoxphim3_Click);
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panelMenu.Controls.Add(this.pictureBox1);
            this.panelMenu.Controls.Add(this.pictureBox3);
            this.panelMenu.Controls.Add(this.pictureBox2);
            this.panelMenu.Controls.Add(this.label4);
            this.panelMenu.Controls.Add(this.pictureBoxMenuShow);
            this.panelMenu.Controls.Add(this.label3);
            this.panelMenu.Location = new System.Drawing.Point(3, 183);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(250, 156);
            this.panelMenu.TabIndex = 168;
            this.panelMenu.Visible = false;
            this.panelMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMenu_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Cinema.Properties.Resources.line;
            this.pictureBox1.Location = new System.Drawing.Point(0, 54);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 1);
            this.pictureBox1.TabIndex = 171;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(7, 103);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(26, 25);
            this.pictureBox3.TabIndex = 170;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(7, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(26, 25);
            this.pictureBox2.TabIndex = 169;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(37, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 24);
            this.label4.TabIndex = 89;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // pictureBoxMenuShow
            // 
            this.pictureBoxMenuShow.BackColor = System.Drawing.Color.White;
            this.pictureBoxMenuShow.BackgroundImage = global::Cinema.Properties.Resources.square1;
            this.pictureBoxMenuShow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxMenuShow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxMenuShow.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxMenuShow.Name = "pictureBoxMenuShow";
            this.pictureBoxMenuShow.Size = new System.Drawing.Size(53, 52);
            this.pictureBoxMenuShow.TabIndex = 13;
            this.pictureBoxMenuShow.TabStop = false;
            this.pictureBoxMenuShow.Click += new System.EventHandler(this.pictureBox1_Click_2);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(37, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 24);
            this.label3.TabIndex = 88;
            this.label3.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipTitle = "Menu";
            // 
            // pictureBoxposter2
            // 
            this.pictureBoxposter2.BackgroundImage = global::Cinema.Properties.Resources.poster1;
            this.pictureBoxposter2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxposter2.Location = new System.Drawing.Point(560, 0);
            this.pictureBoxposter2.Name = "pictureBoxposter2";
            this.pictureBoxposter2.Size = new System.Drawing.Size(560, 180);
            this.pictureBoxposter2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxposter2.TabIndex = 2;
            this.pictureBoxposter2.TabStop = false;
            // 
            // pictureBoxposter1
            // 
            this.pictureBoxposter1.BackgroundImage = global::Cinema.Properties.Resources.poster1;
            this.pictureBoxposter1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxposter1.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxposter1.Name = "pictureBoxposter1";
            this.pictureBoxposter1.Size = new System.Drawing.Size(560, 180);
            this.pictureBoxposter1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxposter1.TabIndex = 0;
            this.pictureBoxposter1.TabStop = false;
            this.pictureBoxposter1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBoxposter3
            // 
            this.pictureBoxposter3.BackgroundImage = global::Cinema.Properties.Resources.poster1;
            this.pictureBoxposter3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxposter3.Location = new System.Drawing.Point(1120, 0);
            this.pictureBoxposter3.Name = "pictureBoxposter3";
            this.pictureBoxposter3.Size = new System.Drawing.Size(560, 180);
            this.pictureBoxposter3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxposter3.TabIndex = 12;
            this.pictureBoxposter3.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1664, 994);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBoxposter2);
            this.Controls.Add(this.pictureBoxposter1);
            this.Controls.Add(this.pictureBoxposter3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trang chủ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMenuHide)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxphim7)).EndInit();
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMenuShow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxposter2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxposter1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxposter3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxposter1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBoxposter2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBoxposter3;
        private System.Windows.Forms.PictureBox pictureBoxphim13;
        private System.Windows.Forms.PictureBox pictureBoxphim10;
        private System.Windows.Forms.PictureBox pictureBoxphim8;
        private System.Windows.Forms.PictureBox pictureBoxphim14;
        private System.Windows.Forms.PictureBox pictureBoxphim20;
        private System.Windows.Forms.PictureBox pictureBoxphim16;
        private System.Windows.Forms.PictureBox pictureBoxphim18;
        private System.Windows.Forms.PictureBox pictureBoxphim12;
        private System.Windows.Forms.PictureBox pictureBoxphim6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBoxphim15;
        private System.Windows.Forms.PictureBox pictureBoxphim22;
        private System.Windows.Forms.PictureBox pictureBoxphim21;
        private System.Windows.Forms.PictureBox pictureBoxphim19;
        private System.Windows.Forms.PictureBox pictureBoxphim11;
        private System.Windows.Forms.PictureBox pictureBoxphim9;
        private System.Windows.Forms.PictureBox pictureBoxphim17;
        private System.Windows.Forms.Label labelCategory1;
        private System.Windows.Forms.Label labelName1;
        private System.Windows.Forms.PictureBox pictureBoxphim2;
        private System.Windows.Forms.PictureBox pictureBoxphim4;
        private System.Windows.Forms.PictureBox pictureBoxphim1;
        private System.Windows.Forms.PictureBox pictureBoxphim5;
        private System.Windows.Forms.PictureBox pictureBoxphim3;
        private System.Windows.Forms.PictureBox pictureBoxphim7;
        private System.Windows.Forms.Label labelCategory12;
        private System.Windows.Forms.Label labelName12;
        private System.Windows.Forms.Label labelCategory14;
        private System.Windows.Forms.Label labelName14;
        private System.Windows.Forms.Label labelCategory16;
        private System.Windows.Forms.Label labelName16;
        private System.Windows.Forms.Label labelCategory18;
        private System.Windows.Forms.Label labelName18;
        private System.Windows.Forms.Label labelCategory20;
        private System.Windows.Forms.Label labelName20;
        private System.Windows.Forms.Label labelCategory22;
        private System.Windows.Forms.Label labelName22;
        private System.Windows.Forms.Label labelCategory21;
        private System.Windows.Forms.Label labelName21;
        private System.Windows.Forms.Label labelCategory19;
        private System.Windows.Forms.Label labelName19;
        private System.Windows.Forms.Label labelCategory17;
        private System.Windows.Forms.Label labelName17;
        private System.Windows.Forms.Label labelCategory15;
        private System.Windows.Forms.Label labelName15;
        private System.Windows.Forms.Label labelCategory13;
        private System.Windows.Forms.Label labelName13;
        private System.Windows.Forms.Label labelCategory11;
        private System.Windows.Forms.Label labelName11;
        private System.Windows.Forms.Label labelCategory10;
        private System.Windows.Forms.Label labelName10;
        private System.Windows.Forms.Label labelCategory8;
        private System.Windows.Forms.Label labelName8;
        private System.Windows.Forms.Label labelCategory6;
        private System.Windows.Forms.Label labelName6;
        private System.Windows.Forms.Label labelCategory4;
        private System.Windows.Forms.Label labelName4;
        private System.Windows.Forms.Label labelCategory9;
        private System.Windows.Forms.Label labelName9;
        private System.Windows.Forms.Label labelCategory7;
        private System.Windows.Forms.Label labelName7;
        private System.Windows.Forms.Label labelCategory5;
        private System.Windows.Forms.Label labelName5;
        private System.Windows.Forms.Label labelCategory2;
        private System.Windows.Forms.Label labelName2;
        private System.Windows.Forms.Label labelCategory3;
        private System.Windows.Forms.Label labelName3;
        private System.Windows.Forms.Button buttonPhim1;
        private System.Windows.Forms.Button buttonPhim22;
        private System.Windows.Forms.Button buttonPhim21;
        private System.Windows.Forms.Button buttonPhim20;
        private System.Windows.Forms.Button buttonPhim18;
        private System.Windows.Forms.Button buttonPhim19;
        private System.Windows.Forms.Button buttonPhim17;
        private System.Windows.Forms.Button buttonPhim16;
        private System.Windows.Forms.Button buttonPhim14;
        private System.Windows.Forms.Button buttonPhim15;
        private System.Windows.Forms.Button buttonPhim13;
        private System.Windows.Forms.Button buttonPhim12;
        private System.Windows.Forms.Button buttonPhim10;
        private System.Windows.Forms.Button buttonPhim11;
        private System.Windows.Forms.Button buttonPhim9;
        private System.Windows.Forms.Button buttonPhim8;
        private System.Windows.Forms.Button buttonPhim6;
        private System.Windows.Forms.Button buttonPhim4;
        private System.Windows.Forms.Button buttonPhim2;
        private System.Windows.Forms.Button buttonPhim7;
        private System.Windows.Forms.Button buttonPhim5;
        private System.Windows.Forms.Button buttonPhim3;
        private System.Windows.Forms.PictureBox pictureBoxMenuShow;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBoxMenuHide;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
    }
}

