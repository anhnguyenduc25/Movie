﻿
namespace Cinema
{
    partial class ChooseSeat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChooseSeat));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.A1 = new System.Windows.Forms.Button();
            this.A2 = new System.Windows.Forms.Button();
            this.A3 = new System.Windows.Forms.Button();
            this.A4 = new System.Windows.Forms.Button();
            this.A5 = new System.Windows.Forms.Button();
            this.A6 = new System.Windows.Forms.Button();
            this.A7 = new System.Windows.Forms.Button();
            this.A8 = new System.Windows.Forms.Button();
            this.A9 = new System.Windows.Forms.Button();
            this.A10 = new System.Windows.Forms.Button();
            this.A20 = new System.Windows.Forms.Button();
            this.A19 = new System.Windows.Forms.Button();
            this.A18 = new System.Windows.Forms.Button();
            this.A17 = new System.Windows.Forms.Button();
            this.A16 = new System.Windows.Forms.Button();
            this.A15 = new System.Windows.Forms.Button();
            this.A14 = new System.Windows.Forms.Button();
            this.A13 = new System.Windows.Forms.Button();
            this.A12 = new System.Windows.Forms.Button();
            this.A11 = new System.Windows.Forms.Button();
            this.B20 = new System.Windows.Forms.Button();
            this.B19 = new System.Windows.Forms.Button();
            this.B18 = new System.Windows.Forms.Button();
            this.B17 = new System.Windows.Forms.Button();
            this.B16 = new System.Windows.Forms.Button();
            this.B15 = new System.Windows.Forms.Button();
            this.B14 = new System.Windows.Forms.Button();
            this.B13 = new System.Windows.Forms.Button();
            this.B12 = new System.Windows.Forms.Button();
            this.B11 = new System.Windows.Forms.Button();
            this.B10 = new System.Windows.Forms.Button();
            this.B9 = new System.Windows.Forms.Button();
            this.B8 = new System.Windows.Forms.Button();
            this.B7 = new System.Windows.Forms.Button();
            this.B6 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.C20 = new System.Windows.Forms.Button();
            this.C19 = new System.Windows.Forms.Button();
            this.C18 = new System.Windows.Forms.Button();
            this.C17 = new System.Windows.Forms.Button();
            this.C16 = new System.Windows.Forms.Button();
            this.C15 = new System.Windows.Forms.Button();
            this.C14 = new System.Windows.Forms.Button();
            this.C13 = new System.Windows.Forms.Button();
            this.C12 = new System.Windows.Forms.Button();
            this.C11 = new System.Windows.Forms.Button();
            this.C10 = new System.Windows.Forms.Button();
            this.C9 = new System.Windows.Forms.Button();
            this.C8 = new System.Windows.Forms.Button();
            this.C7 = new System.Windows.Forms.Button();
            this.C6 = new System.Windows.Forms.Button();
            this.C5 = new System.Windows.Forms.Button();
            this.C4 = new System.Windows.Forms.Button();
            this.C3 = new System.Windows.Forms.Button();
            this.C2 = new System.Windows.Forms.Button();
            this.C1 = new System.Windows.Forms.Button();
            this.D20 = new System.Windows.Forms.Button();
            this.D19 = new System.Windows.Forms.Button();
            this.D18 = new System.Windows.Forms.Button();
            this.D17 = new System.Windows.Forms.Button();
            this.D16 = new System.Windows.Forms.Button();
            this.D15 = new System.Windows.Forms.Button();
            this.D14 = new System.Windows.Forms.Button();
            this.D13 = new System.Windows.Forms.Button();
            this.D12 = new System.Windows.Forms.Button();
            this.D11 = new System.Windows.Forms.Button();
            this.D10 = new System.Windows.Forms.Button();
            this.D9 = new System.Windows.Forms.Button();
            this.D8 = new System.Windows.Forms.Button();
            this.D7 = new System.Windows.Forms.Button();
            this.D6 = new System.Windows.Forms.Button();
            this.D5 = new System.Windows.Forms.Button();
            this.D4 = new System.Windows.Forms.Button();
            this.D3 = new System.Windows.Forms.Button();
            this.D2 = new System.Windows.Forms.Button();
            this.D1 = new System.Windows.Forms.Button();
            this.E20 = new System.Windows.Forms.Button();
            this.E19 = new System.Windows.Forms.Button();
            this.E18 = new System.Windows.Forms.Button();
            this.E17 = new System.Windows.Forms.Button();
            this.E16 = new System.Windows.Forms.Button();
            this.E15 = new System.Windows.Forms.Button();
            this.E14 = new System.Windows.Forms.Button();
            this.E13 = new System.Windows.Forms.Button();
            this.E12 = new System.Windows.Forms.Button();
            this.E11 = new System.Windows.Forms.Button();
            this.E10 = new System.Windows.Forms.Button();
            this.E9 = new System.Windows.Forms.Button();
            this.E8 = new System.Windows.Forms.Button();
            this.E7 = new System.Windows.Forms.Button();
            this.E6 = new System.Windows.Forms.Button();
            this.E5 = new System.Windows.Forms.Button();
            this.E4 = new System.Windows.Forms.Button();
            this.E3 = new System.Windows.Forms.Button();
            this.E2 = new System.Windows.Forms.Button();
            this.E1 = new System.Windows.Forms.Button();
            this.F20 = new System.Windows.Forms.Button();
            this.F19 = new System.Windows.Forms.Button();
            this.F18 = new System.Windows.Forms.Button();
            this.F17 = new System.Windows.Forms.Button();
            this.F16 = new System.Windows.Forms.Button();
            this.F5 = new System.Windows.Forms.Button();
            this.F4 = new System.Windows.Forms.Button();
            this.F3 = new System.Windows.Forms.Button();
            this.F2 = new System.Windows.Forms.Button();
            this.F1 = new System.Windows.Forms.Button();
            this.G20 = new System.Windows.Forms.Button();
            this.G19 = new System.Windows.Forms.Button();
            this.G18 = new System.Windows.Forms.Button();
            this.G17 = new System.Windows.Forms.Button();
            this.G16 = new System.Windows.Forms.Button();
            this.G5 = new System.Windows.Forms.Button();
            this.G4 = new System.Windows.Forms.Button();
            this.G3 = new System.Windows.Forms.Button();
            this.G2 = new System.Windows.Forms.Button();
            this.G1 = new System.Windows.Forms.Button();
            this.H20 = new System.Windows.Forms.Button();
            this.H19 = new System.Windows.Forms.Button();
            this.H18 = new System.Windows.Forms.Button();
            this.H17 = new System.Windows.Forms.Button();
            this.H16 = new System.Windows.Forms.Button();
            this.H5 = new System.Windows.Forms.Button();
            this.H4 = new System.Windows.Forms.Button();
            this.H3 = new System.Windows.Forms.Button();
            this.H2 = new System.Windows.Forms.Button();
            this.H1 = new System.Windows.Forms.Button();
            this.I20 = new System.Windows.Forms.Button();
            this.I19 = new System.Windows.Forms.Button();
            this.I18 = new System.Windows.Forms.Button();
            this.I17 = new System.Windows.Forms.Button();
            this.I16 = new System.Windows.Forms.Button();
            this.I5 = new System.Windows.Forms.Button();
            this.I4 = new System.Windows.Forms.Button();
            this.I3 = new System.Windows.Forms.Button();
            this.I2 = new System.Windows.Forms.Button();
            this.I1 = new System.Windows.Forms.Button();
            this.J20 = new System.Windows.Forms.Button();
            this.J19 = new System.Windows.Forms.Button();
            this.J18 = new System.Windows.Forms.Button();
            this.J17 = new System.Windows.Forms.Button();
            this.J16 = new System.Windows.Forms.Button();
            this.J15 = new System.Windows.Forms.Button();
            this.J14 = new System.Windows.Forms.Button();
            this.J13 = new System.Windows.Forms.Button();
            this.J12 = new System.Windows.Forms.Button();
            this.J11 = new System.Windows.Forms.Button();
            this.J10 = new System.Windows.Forms.Button();
            this.J9 = new System.Windows.Forms.Button();
            this.J8 = new System.Windows.Forms.Button();
            this.J7 = new System.Windows.Forms.Button();
            this.J6 = new System.Windows.Forms.Button();
            this.J5 = new System.Windows.Forms.Button();
            this.J4 = new System.Windows.Forms.Button();
            this.J3 = new System.Windows.Forms.Button();
            this.J2 = new System.Windows.Forms.Button();
            this.J1 = new System.Windows.Forms.Button();
            this.K20 = new System.Windows.Forms.Button();
            this.K19 = new System.Windows.Forms.Button();
            this.K18 = new System.Windows.Forms.Button();
            this.K17 = new System.Windows.Forms.Button();
            this.K16 = new System.Windows.Forms.Button();
            this.K15 = new System.Windows.Forms.Button();
            this.K14 = new System.Windows.Forms.Button();
            this.K13 = new System.Windows.Forms.Button();
            this.K12 = new System.Windows.Forms.Button();
            this.K11 = new System.Windows.Forms.Button();
            this.K10 = new System.Windows.Forms.Button();
            this.K9 = new System.Windows.Forms.Button();
            this.K8 = new System.Windows.Forms.Button();
            this.K7 = new System.Windows.Forms.Button();
            this.K6 = new System.Windows.Forms.Button();
            this.K5 = new System.Windows.Forms.Button();
            this.K4 = new System.Windows.Forms.Button();
            this.K3 = new System.Windows.Forms.Button();
            this.K2 = new System.Windows.Forms.Button();
            this.K1 = new System.Windows.Forms.Button();
            this.L20 = new System.Windows.Forms.Button();
            this.L19 = new System.Windows.Forms.Button();
            this.L18 = new System.Windows.Forms.Button();
            this.L17 = new System.Windows.Forms.Button();
            this.L16 = new System.Windows.Forms.Button();
            this.L15 = new System.Windows.Forms.Button();
            this.L14 = new System.Windows.Forms.Button();
            this.L13 = new System.Windows.Forms.Button();
            this.L12 = new System.Windows.Forms.Button();
            this.L11 = new System.Windows.Forms.Button();
            this.L10 = new System.Windows.Forms.Button();
            this.L9 = new System.Windows.Forms.Button();
            this.L8 = new System.Windows.Forms.Button();
            this.L7 = new System.Windows.Forms.Button();
            this.L6 = new System.Windows.Forms.Button();
            this.L5 = new System.Windows.Forms.Button();
            this.L4 = new System.Windows.Forms.Button();
            this.L3 = new System.Windows.Forms.Button();
            this.L2 = new System.Windows.Forms.Button();
            this.L1 = new System.Windows.Forms.Button();
            this.M20 = new System.Windows.Forms.Button();
            this.M19 = new System.Windows.Forms.Button();
            this.M18 = new System.Windows.Forms.Button();
            this.M17 = new System.Windows.Forms.Button();
            this.M16 = new System.Windows.Forms.Button();
            this.M15 = new System.Windows.Forms.Button();
            this.M14 = new System.Windows.Forms.Button();
            this.M13 = new System.Windows.Forms.Button();
            this.M12 = new System.Windows.Forms.Button();
            this.M11 = new System.Windows.Forms.Button();
            this.M10 = new System.Windows.Forms.Button();
            this.M9 = new System.Windows.Forms.Button();
            this.M8 = new System.Windows.Forms.Button();
            this.M7 = new System.Windows.Forms.Button();
            this.M6 = new System.Windows.Forms.Button();
            this.M5 = new System.Windows.Forms.Button();
            this.M4 = new System.Windows.Forms.Button();
            this.M3 = new System.Windows.Forms.Button();
            this.M2 = new System.Windows.Forms.Button();
            this.M1 = new System.Windows.Forms.Button();
            this.N20 = new System.Windows.Forms.Button();
            this.N19 = new System.Windows.Forms.Button();
            this.N18 = new System.Windows.Forms.Button();
            this.N17 = new System.Windows.Forms.Button();
            this.N16 = new System.Windows.Forms.Button();
            this.N15 = new System.Windows.Forms.Button();
            this.N14 = new System.Windows.Forms.Button();
            this.N13 = new System.Windows.Forms.Button();
            this.N12 = new System.Windows.Forms.Button();
            this.N11 = new System.Windows.Forms.Button();
            this.N10 = new System.Windows.Forms.Button();
            this.N9 = new System.Windows.Forms.Button();
            this.N8 = new System.Windows.Forms.Button();
            this.N7 = new System.Windows.Forms.Button();
            this.N6 = new System.Windows.Forms.Button();
            this.N5 = new System.Windows.Forms.Button();
            this.N4 = new System.Windows.Forms.Button();
            this.N3 = new System.Windows.Forms.Button();
            this.N2 = new System.Windows.Forms.Button();
            this.N1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button284 = new System.Windows.Forms.Button();
            this.button283 = new System.Windows.Forms.Button();
            this.button282 = new System.Windows.Forms.Button();
            this.button281 = new System.Windows.Forms.Button();
            this.labelName = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.buttonPayment = new System.Windows.Forms.Button();
            this.labelGiaGhe = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelSeat = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelTime = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.F6 = new System.Windows.Forms.Button();
            this.F7 = new System.Windows.Forms.Button();
            this.I15 = new System.Windows.Forms.Button();
            this.I14 = new System.Windows.Forms.Button();
            this.F8 = new System.Windows.Forms.Button();
            this.I13 = new System.Windows.Forms.Button();
            this.I12 = new System.Windows.Forms.Button();
            this.F9 = new System.Windows.Forms.Button();
            this.I11 = new System.Windows.Forms.Button();
            this.I10 = new System.Windows.Forms.Button();
            this.F10 = new System.Windows.Forms.Button();
            this.I9 = new System.Windows.Forms.Button();
            this.I8 = new System.Windows.Forms.Button();
            this.F11 = new System.Windows.Forms.Button();
            this.I7 = new System.Windows.Forms.Button();
            this.I6 = new System.Windows.Forms.Button();
            this.F12 = new System.Windows.Forms.Button();
            this.H15 = new System.Windows.Forms.Button();
            this.H14 = new System.Windows.Forms.Button();
            this.F13 = new System.Windows.Forms.Button();
            this.H13 = new System.Windows.Forms.Button();
            this.H12 = new System.Windows.Forms.Button();
            this.F14 = new System.Windows.Forms.Button();
            this.H11 = new System.Windows.Forms.Button();
            this.H10 = new System.Windows.Forms.Button();
            this.F15 = new System.Windows.Forms.Button();
            this.H9 = new System.Windows.Forms.Button();
            this.H8 = new System.Windows.Forms.Button();
            this.G6 = new System.Windows.Forms.Button();
            this.H7 = new System.Windows.Forms.Button();
            this.H6 = new System.Windows.Forms.Button();
            this.G7 = new System.Windows.Forms.Button();
            this.G15 = new System.Windows.Forms.Button();
            this.G14 = new System.Windows.Forms.Button();
            this.G8 = new System.Windows.Forms.Button();
            this.G13 = new System.Windows.Forms.Button();
            this.G12 = new System.Windows.Forms.Button();
            this.G9 = new System.Windows.Forms.Button();
            this.G11 = new System.Windows.Forms.Button();
            this.G10 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(84, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1114, 17);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(585, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "MÀN HÌNH";
            // 
            // A1
            // 
            this.A1.BackColor = System.Drawing.Color.SlateBlue;
            this.A1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.ForeColor = System.Drawing.Color.White;
            this.A1.Location = new System.Drawing.Point(84, 45);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(50, 50);
            this.A1.TabIndex = 2;
            this.A1.Text = "A1";
            this.A1.UseVisualStyleBackColor = false;
            this.A1.Click += new System.EventHandler(this.A1_Click);
            // 
            // A2
            // 
            this.A2.BackColor = System.Drawing.Color.SlateBlue;
            this.A2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.ForeColor = System.Drawing.Color.White;
            this.A2.Location = new System.Drawing.Point(140, 45);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(50, 50);
            this.A2.TabIndex = 3;
            this.A2.Text = "A2";
            this.A2.UseVisualStyleBackColor = false;
            this.A2.Click += new System.EventHandler(this.A2_Click);
            // 
            // A3
            // 
            this.A3.BackColor = System.Drawing.Color.SlateBlue;
            this.A3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.ForeColor = System.Drawing.Color.White;
            this.A3.Location = new System.Drawing.Point(196, 45);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(50, 50);
            this.A3.TabIndex = 4;
            this.A3.Text = "A3";
            this.A3.UseVisualStyleBackColor = false;
            this.A3.Click += new System.EventHandler(this.A3_Click);
            // 
            // A4
            // 
            this.A4.BackColor = System.Drawing.Color.SlateBlue;
            this.A4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A4.ForeColor = System.Drawing.Color.White;
            this.A4.Location = new System.Drawing.Point(252, 45);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(50, 50);
            this.A4.TabIndex = 5;
            this.A4.Text = "A4";
            this.A4.UseVisualStyleBackColor = false;
            this.A4.Click += new System.EventHandler(this.A4_Click);
            // 
            // A5
            // 
            this.A5.BackColor = System.Drawing.Color.SlateBlue;
            this.A5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A5.ForeColor = System.Drawing.Color.White;
            this.A5.Location = new System.Drawing.Point(308, 45);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(50, 50);
            this.A5.TabIndex = 6;
            this.A5.Text = "A5";
            this.A5.UseVisualStyleBackColor = false;
            this.A5.Click += new System.EventHandler(this.A5_Click);
            // 
            // A6
            // 
            this.A6.BackColor = System.Drawing.Color.SlateBlue;
            this.A6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A6.ForeColor = System.Drawing.Color.White;
            this.A6.Location = new System.Drawing.Point(364, 45);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(50, 50);
            this.A6.TabIndex = 7;
            this.A6.Text = "A6";
            this.A6.UseVisualStyleBackColor = false;
            this.A6.Click += new System.EventHandler(this.A6_Click);
            // 
            // A7
            // 
            this.A7.BackColor = System.Drawing.Color.SlateBlue;
            this.A7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A7.ForeColor = System.Drawing.Color.White;
            this.A7.Location = new System.Drawing.Point(420, 45);
            this.A7.Name = "A7";
            this.A7.Size = new System.Drawing.Size(50, 50);
            this.A7.TabIndex = 8;
            this.A7.Text = "A7";
            this.A7.UseVisualStyleBackColor = false;
            this.A7.Click += new System.EventHandler(this.A7_Click);
            // 
            // A8
            // 
            this.A8.BackColor = System.Drawing.Color.SlateBlue;
            this.A8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A8.ForeColor = System.Drawing.Color.White;
            this.A8.Location = new System.Drawing.Point(476, 45);
            this.A8.Name = "A8";
            this.A8.Size = new System.Drawing.Size(50, 50);
            this.A8.TabIndex = 9;
            this.A8.Text = "A8";
            this.A8.UseVisualStyleBackColor = false;
            this.A8.Click += new System.EventHandler(this.A8_Click);
            // 
            // A9
            // 
            this.A9.BackColor = System.Drawing.Color.SlateBlue;
            this.A9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A9.ForeColor = System.Drawing.Color.White;
            this.A9.Location = new System.Drawing.Point(532, 45);
            this.A9.Name = "A9";
            this.A9.Size = new System.Drawing.Size(50, 50);
            this.A9.TabIndex = 10;
            this.A9.Text = "A9";
            this.A9.UseVisualStyleBackColor = false;
            this.A9.Click += new System.EventHandler(this.A9_Click);
            // 
            // A10
            // 
            this.A10.BackColor = System.Drawing.Color.SlateBlue;
            this.A10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A10.ForeColor = System.Drawing.Color.White;
            this.A10.Location = new System.Drawing.Point(588, 45);
            this.A10.Name = "A10";
            this.A10.Size = new System.Drawing.Size(50, 50);
            this.A10.TabIndex = 11;
            this.A10.Text = "A10";
            this.A10.UseVisualStyleBackColor = false;
            this.A10.Click += new System.EventHandler(this.A10_Click);
            // 
            // A20
            // 
            this.A20.BackColor = System.Drawing.Color.SlateBlue;
            this.A20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A20.ForeColor = System.Drawing.Color.White;
            this.A20.Location = new System.Drawing.Point(1148, 45);
            this.A20.Name = "A20";
            this.A20.Size = new System.Drawing.Size(50, 50);
            this.A20.TabIndex = 21;
            this.A20.Text = "A20";
            this.A20.UseVisualStyleBackColor = false;
            this.A20.Click += new System.EventHandler(this.A20_Click);
            // 
            // A19
            // 
            this.A19.BackColor = System.Drawing.Color.SlateBlue;
            this.A19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A19.ForeColor = System.Drawing.Color.White;
            this.A19.Location = new System.Drawing.Point(1092, 45);
            this.A19.Name = "A19";
            this.A19.Size = new System.Drawing.Size(50, 50);
            this.A19.TabIndex = 20;
            this.A19.Text = "A19";
            this.A19.UseVisualStyleBackColor = false;
            this.A19.Click += new System.EventHandler(this.A19_Click);
            // 
            // A18
            // 
            this.A18.BackColor = System.Drawing.Color.SlateBlue;
            this.A18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A18.ForeColor = System.Drawing.Color.White;
            this.A18.Location = new System.Drawing.Point(1036, 45);
            this.A18.Name = "A18";
            this.A18.Size = new System.Drawing.Size(50, 50);
            this.A18.TabIndex = 19;
            this.A18.Text = "A18";
            this.A18.UseVisualStyleBackColor = false;
            this.A18.Click += new System.EventHandler(this.A18_Click);
            // 
            // A17
            // 
            this.A17.BackColor = System.Drawing.Color.SlateBlue;
            this.A17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A17.ForeColor = System.Drawing.Color.White;
            this.A17.Location = new System.Drawing.Point(980, 45);
            this.A17.Name = "A17";
            this.A17.Size = new System.Drawing.Size(50, 50);
            this.A17.TabIndex = 18;
            this.A17.Text = "A17";
            this.A17.UseVisualStyleBackColor = false;
            this.A17.Click += new System.EventHandler(this.A17_Click);
            // 
            // A16
            // 
            this.A16.BackColor = System.Drawing.Color.SlateBlue;
            this.A16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A16.ForeColor = System.Drawing.Color.White;
            this.A16.Location = new System.Drawing.Point(924, 45);
            this.A16.Name = "A16";
            this.A16.Size = new System.Drawing.Size(50, 50);
            this.A16.TabIndex = 17;
            this.A16.Text = "A16";
            this.A16.UseVisualStyleBackColor = false;
            this.A16.Click += new System.EventHandler(this.A16_Click);
            // 
            // A15
            // 
            this.A15.BackColor = System.Drawing.Color.SlateBlue;
            this.A15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A15.ForeColor = System.Drawing.Color.White;
            this.A15.Location = new System.Drawing.Point(868, 45);
            this.A15.Name = "A15";
            this.A15.Size = new System.Drawing.Size(50, 50);
            this.A15.TabIndex = 16;
            this.A15.Text = "A15";
            this.A15.UseVisualStyleBackColor = false;
            this.A15.Click += new System.EventHandler(this.A15_Click);
            // 
            // A14
            // 
            this.A14.BackColor = System.Drawing.Color.SlateBlue;
            this.A14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A14.ForeColor = System.Drawing.Color.White;
            this.A14.Location = new System.Drawing.Point(812, 45);
            this.A14.Name = "A14";
            this.A14.Size = new System.Drawing.Size(50, 50);
            this.A14.TabIndex = 15;
            this.A14.Text = "A14";
            this.A14.UseVisualStyleBackColor = false;
            this.A14.Click += new System.EventHandler(this.A14_Click);
            // 
            // A13
            // 
            this.A13.BackColor = System.Drawing.Color.SlateBlue;
            this.A13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A13.ForeColor = System.Drawing.Color.White;
            this.A13.Location = new System.Drawing.Point(756, 45);
            this.A13.Name = "A13";
            this.A13.Size = new System.Drawing.Size(50, 50);
            this.A13.TabIndex = 14;
            this.A13.Text = "A13";
            this.A13.UseVisualStyleBackColor = false;
            this.A13.Click += new System.EventHandler(this.A13_Click);
            // 
            // A12
            // 
            this.A12.BackColor = System.Drawing.Color.SlateBlue;
            this.A12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A12.ForeColor = System.Drawing.Color.White;
            this.A12.Location = new System.Drawing.Point(700, 45);
            this.A12.Name = "A12";
            this.A12.Size = new System.Drawing.Size(50, 50);
            this.A12.TabIndex = 13;
            this.A12.Text = "A12";
            this.A12.UseVisualStyleBackColor = false;
            this.A12.Click += new System.EventHandler(this.A12_Click);
            // 
            // A11
            // 
            this.A11.BackColor = System.Drawing.Color.SlateBlue;
            this.A11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.A11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A11.ForeColor = System.Drawing.Color.White;
            this.A11.Location = new System.Drawing.Point(644, 45);
            this.A11.Name = "A11";
            this.A11.Size = new System.Drawing.Size(50, 50);
            this.A11.TabIndex = 12;
            this.A11.Text = "A11";
            this.A11.UseVisualStyleBackColor = false;
            this.A11.Click += new System.EventHandler(this.A11_Click);
            // 
            // B20
            // 
            this.B20.BackColor = System.Drawing.Color.SlateBlue;
            this.B20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B20.ForeColor = System.Drawing.Color.White;
            this.B20.Location = new System.Drawing.Point(1148, 101);
            this.B20.Name = "B20";
            this.B20.Size = new System.Drawing.Size(50, 50);
            this.B20.TabIndex = 41;
            this.B20.Text = "B20";
            this.B20.UseVisualStyleBackColor = false;
            this.B20.Click += new System.EventHandler(this.B20_Click);
            // 
            // B19
            // 
            this.B19.BackColor = System.Drawing.Color.SlateBlue;
            this.B19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B19.ForeColor = System.Drawing.Color.White;
            this.B19.Location = new System.Drawing.Point(1092, 101);
            this.B19.Name = "B19";
            this.B19.Size = new System.Drawing.Size(50, 50);
            this.B19.TabIndex = 40;
            this.B19.Text = "B19";
            this.B19.UseVisualStyleBackColor = false;
            this.B19.Click += new System.EventHandler(this.B19_Click);
            // 
            // B18
            // 
            this.B18.BackColor = System.Drawing.Color.SlateBlue;
            this.B18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B18.ForeColor = System.Drawing.Color.White;
            this.B18.Location = new System.Drawing.Point(1036, 101);
            this.B18.Name = "B18";
            this.B18.Size = new System.Drawing.Size(50, 50);
            this.B18.TabIndex = 39;
            this.B18.Text = "B18";
            this.B18.UseVisualStyleBackColor = false;
            this.B18.Click += new System.EventHandler(this.B18_Click);
            // 
            // B17
            // 
            this.B17.BackColor = System.Drawing.Color.SlateBlue;
            this.B17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B17.ForeColor = System.Drawing.Color.White;
            this.B17.Location = new System.Drawing.Point(980, 101);
            this.B17.Name = "B17";
            this.B17.Size = new System.Drawing.Size(50, 50);
            this.B17.TabIndex = 38;
            this.B17.Text = "B17";
            this.B17.UseVisualStyleBackColor = false;
            this.B17.Click += new System.EventHandler(this.B17_Click);
            // 
            // B16
            // 
            this.B16.BackColor = System.Drawing.Color.SlateBlue;
            this.B16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B16.ForeColor = System.Drawing.Color.White;
            this.B16.Location = new System.Drawing.Point(924, 101);
            this.B16.Name = "B16";
            this.B16.Size = new System.Drawing.Size(50, 50);
            this.B16.TabIndex = 37;
            this.B16.Text = "B16";
            this.B16.UseVisualStyleBackColor = false;
            this.B16.Click += new System.EventHandler(this.B16_Click);
            // 
            // B15
            // 
            this.B15.BackColor = System.Drawing.Color.SlateBlue;
            this.B15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B15.ForeColor = System.Drawing.Color.White;
            this.B15.Location = new System.Drawing.Point(868, 101);
            this.B15.Name = "B15";
            this.B15.Size = new System.Drawing.Size(50, 50);
            this.B15.TabIndex = 36;
            this.B15.Text = "B15";
            this.B15.UseVisualStyleBackColor = false;
            this.B15.Click += new System.EventHandler(this.B15_Click);
            // 
            // B14
            // 
            this.B14.BackColor = System.Drawing.Color.SlateBlue;
            this.B14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B14.ForeColor = System.Drawing.Color.White;
            this.B14.Location = new System.Drawing.Point(812, 101);
            this.B14.Name = "B14";
            this.B14.Size = new System.Drawing.Size(50, 50);
            this.B14.TabIndex = 35;
            this.B14.Text = "B14";
            this.B14.UseVisualStyleBackColor = false;
            this.B14.Click += new System.EventHandler(this.B14_Click);
            // 
            // B13
            // 
            this.B13.BackColor = System.Drawing.Color.SlateBlue;
            this.B13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B13.ForeColor = System.Drawing.Color.White;
            this.B13.Location = new System.Drawing.Point(756, 101);
            this.B13.Name = "B13";
            this.B13.Size = new System.Drawing.Size(50, 50);
            this.B13.TabIndex = 34;
            this.B13.Text = "B13";
            this.B13.UseVisualStyleBackColor = false;
            this.B13.Click += new System.EventHandler(this.B13_Click);
            // 
            // B12
            // 
            this.B12.BackColor = System.Drawing.Color.SlateBlue;
            this.B12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B12.ForeColor = System.Drawing.Color.White;
            this.B12.Location = new System.Drawing.Point(700, 101);
            this.B12.Name = "B12";
            this.B12.Size = new System.Drawing.Size(50, 50);
            this.B12.TabIndex = 33;
            this.B12.Text = "B12";
            this.B12.UseVisualStyleBackColor = false;
            this.B12.Click += new System.EventHandler(this.B12_Click);
            // 
            // B11
            // 
            this.B11.BackColor = System.Drawing.Color.SlateBlue;
            this.B11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B11.ForeColor = System.Drawing.Color.White;
            this.B11.Location = new System.Drawing.Point(644, 101);
            this.B11.Name = "B11";
            this.B11.Size = new System.Drawing.Size(50, 50);
            this.B11.TabIndex = 32;
            this.B11.Text = "B11";
            this.B11.UseVisualStyleBackColor = false;
            this.B11.Click += new System.EventHandler(this.B11_Click);
            // 
            // B10
            // 
            this.B10.BackColor = System.Drawing.Color.SlateBlue;
            this.B10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B10.ForeColor = System.Drawing.Color.White;
            this.B10.Location = new System.Drawing.Point(588, 101);
            this.B10.Name = "B10";
            this.B10.Size = new System.Drawing.Size(50, 50);
            this.B10.TabIndex = 31;
            this.B10.Text = "B10";
            this.B10.UseVisualStyleBackColor = false;
            this.B10.Click += new System.EventHandler(this.B10_Click);
            // 
            // B9
            // 
            this.B9.BackColor = System.Drawing.Color.SlateBlue;
            this.B9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B9.ForeColor = System.Drawing.Color.White;
            this.B9.Location = new System.Drawing.Point(532, 101);
            this.B9.Name = "B9";
            this.B9.Size = new System.Drawing.Size(50, 50);
            this.B9.TabIndex = 30;
            this.B9.Text = "B9";
            this.B9.UseVisualStyleBackColor = false;
            this.B9.Click += new System.EventHandler(this.B9_Click);
            // 
            // B8
            // 
            this.B8.BackColor = System.Drawing.Color.SlateBlue;
            this.B8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B8.ForeColor = System.Drawing.Color.White;
            this.B8.Location = new System.Drawing.Point(476, 101);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(50, 50);
            this.B8.TabIndex = 29;
            this.B8.Text = "B8";
            this.B8.UseVisualStyleBackColor = false;
            this.B8.Click += new System.EventHandler(this.B8_Click);
            // 
            // B7
            // 
            this.B7.BackColor = System.Drawing.Color.SlateBlue;
            this.B7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B7.ForeColor = System.Drawing.Color.White;
            this.B7.Location = new System.Drawing.Point(420, 101);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(50, 50);
            this.B7.TabIndex = 28;
            this.B7.Text = "B7";
            this.B7.UseVisualStyleBackColor = false;
            this.B7.Click += new System.EventHandler(this.B7_Click);
            // 
            // B6
            // 
            this.B6.BackColor = System.Drawing.Color.SlateBlue;
            this.B6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B6.ForeColor = System.Drawing.Color.White;
            this.B6.Location = new System.Drawing.Point(364, 101);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(50, 50);
            this.B6.TabIndex = 27;
            this.B6.Text = "B6";
            this.B6.UseVisualStyleBackColor = false;
            this.B6.Click += new System.EventHandler(this.B6_Click);
            // 
            // B5
            // 
            this.B5.BackColor = System.Drawing.Color.SlateBlue;
            this.B5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B5.ForeColor = System.Drawing.Color.White;
            this.B5.Location = new System.Drawing.Point(308, 101);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(50, 50);
            this.B5.TabIndex = 26;
            this.B5.Text = "B5";
            this.B5.UseVisualStyleBackColor = false;
            this.B5.Click += new System.EventHandler(this.B5_Click);
            // 
            // B4
            // 
            this.B4.BackColor = System.Drawing.Color.SlateBlue;
            this.B4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.ForeColor = System.Drawing.Color.White;
            this.B4.Location = new System.Drawing.Point(252, 101);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(50, 50);
            this.B4.TabIndex = 25;
            this.B4.Text = "B4";
            this.B4.UseVisualStyleBackColor = false;
            this.B4.Click += new System.EventHandler(this.B4_Click);
            // 
            // B3
            // 
            this.B3.BackColor = System.Drawing.Color.SlateBlue;
            this.B3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.ForeColor = System.Drawing.Color.White;
            this.B3.Location = new System.Drawing.Point(196, 101);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(50, 50);
            this.B3.TabIndex = 24;
            this.B3.Text = "B3";
            this.B3.UseVisualStyleBackColor = false;
            this.B3.Click += new System.EventHandler(this.B3_Click);
            // 
            // B2
            // 
            this.B2.BackColor = System.Drawing.Color.SlateBlue;
            this.B2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.ForeColor = System.Drawing.Color.White;
            this.B2.Location = new System.Drawing.Point(140, 101);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(50, 50);
            this.B2.TabIndex = 23;
            this.B2.Text = "B2";
            this.B2.UseVisualStyleBackColor = false;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // B1
            // 
            this.B1.BackColor = System.Drawing.Color.SlateBlue;
            this.B1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.ForeColor = System.Drawing.Color.White;
            this.B1.Location = new System.Drawing.Point(84, 101);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(50, 50);
            this.B1.TabIndex = 22;
            this.B1.Text = "B1";
            this.B1.UseVisualStyleBackColor = false;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // C20
            // 
            this.C20.BackColor = System.Drawing.Color.SlateBlue;
            this.C20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C20.ForeColor = System.Drawing.Color.White;
            this.C20.Location = new System.Drawing.Point(1148, 157);
            this.C20.Name = "C20";
            this.C20.Size = new System.Drawing.Size(50, 50);
            this.C20.TabIndex = 61;
            this.C20.Text = "C20";
            this.C20.UseVisualStyleBackColor = false;
            this.C20.Click += new System.EventHandler(this.C20_Click);
            // 
            // C19
            // 
            this.C19.BackColor = System.Drawing.Color.SlateBlue;
            this.C19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C19.ForeColor = System.Drawing.Color.White;
            this.C19.Location = new System.Drawing.Point(1092, 157);
            this.C19.Name = "C19";
            this.C19.Size = new System.Drawing.Size(50, 50);
            this.C19.TabIndex = 60;
            this.C19.Text = "C19";
            this.C19.UseVisualStyleBackColor = false;
            this.C19.Click += new System.EventHandler(this.C19_Click);
            // 
            // C18
            // 
            this.C18.BackColor = System.Drawing.Color.SlateBlue;
            this.C18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C18.ForeColor = System.Drawing.Color.White;
            this.C18.Location = new System.Drawing.Point(1036, 157);
            this.C18.Name = "C18";
            this.C18.Size = new System.Drawing.Size(50, 50);
            this.C18.TabIndex = 59;
            this.C18.Text = "C18";
            this.C18.UseVisualStyleBackColor = false;
            this.C18.Click += new System.EventHandler(this.C18_Click);
            // 
            // C17
            // 
            this.C17.BackColor = System.Drawing.Color.SlateBlue;
            this.C17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C17.ForeColor = System.Drawing.Color.White;
            this.C17.Location = new System.Drawing.Point(980, 157);
            this.C17.Name = "C17";
            this.C17.Size = new System.Drawing.Size(50, 50);
            this.C17.TabIndex = 58;
            this.C17.Text = "C17";
            this.C17.UseVisualStyleBackColor = false;
            this.C17.Click += new System.EventHandler(this.C17_Click);
            // 
            // C16
            // 
            this.C16.BackColor = System.Drawing.Color.SlateBlue;
            this.C16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C16.ForeColor = System.Drawing.Color.White;
            this.C16.Location = new System.Drawing.Point(924, 157);
            this.C16.Name = "C16";
            this.C16.Size = new System.Drawing.Size(50, 50);
            this.C16.TabIndex = 57;
            this.C16.Text = "C16";
            this.C16.UseVisualStyleBackColor = false;
            this.C16.Click += new System.EventHandler(this.C16_Click);
            // 
            // C15
            // 
            this.C15.BackColor = System.Drawing.Color.SlateBlue;
            this.C15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C15.ForeColor = System.Drawing.Color.White;
            this.C15.Location = new System.Drawing.Point(868, 157);
            this.C15.Name = "C15";
            this.C15.Size = new System.Drawing.Size(50, 50);
            this.C15.TabIndex = 56;
            this.C15.Text = "C15";
            this.C15.UseVisualStyleBackColor = false;
            this.C15.Click += new System.EventHandler(this.C15_Click);
            // 
            // C14
            // 
            this.C14.BackColor = System.Drawing.Color.SlateBlue;
            this.C14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C14.ForeColor = System.Drawing.Color.White;
            this.C14.Location = new System.Drawing.Point(812, 157);
            this.C14.Name = "C14";
            this.C14.Size = new System.Drawing.Size(50, 50);
            this.C14.TabIndex = 55;
            this.C14.Text = "C14";
            this.C14.UseVisualStyleBackColor = false;
            this.C14.Click += new System.EventHandler(this.C14_Click);
            // 
            // C13
            // 
            this.C13.BackColor = System.Drawing.Color.SlateBlue;
            this.C13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C13.ForeColor = System.Drawing.Color.White;
            this.C13.Location = new System.Drawing.Point(756, 157);
            this.C13.Name = "C13";
            this.C13.Size = new System.Drawing.Size(50, 50);
            this.C13.TabIndex = 54;
            this.C13.Text = "C13";
            this.C13.UseVisualStyleBackColor = false;
            this.C13.Click += new System.EventHandler(this.C13_Click);
            // 
            // C12
            // 
            this.C12.BackColor = System.Drawing.Color.SlateBlue;
            this.C12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C12.ForeColor = System.Drawing.Color.White;
            this.C12.Location = new System.Drawing.Point(700, 157);
            this.C12.Name = "C12";
            this.C12.Size = new System.Drawing.Size(50, 50);
            this.C12.TabIndex = 53;
            this.C12.Text = "C12";
            this.C12.UseVisualStyleBackColor = false;
            this.C12.Click += new System.EventHandler(this.C12_Click);
            // 
            // C11
            // 
            this.C11.BackColor = System.Drawing.Color.SlateBlue;
            this.C11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C11.ForeColor = System.Drawing.Color.White;
            this.C11.Location = new System.Drawing.Point(644, 157);
            this.C11.Name = "C11";
            this.C11.Size = new System.Drawing.Size(50, 50);
            this.C11.TabIndex = 52;
            this.C11.Text = "C11";
            this.C11.UseVisualStyleBackColor = false;
            this.C11.Click += new System.EventHandler(this.C11_Click);
            // 
            // C10
            // 
            this.C10.BackColor = System.Drawing.Color.SlateBlue;
            this.C10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C10.ForeColor = System.Drawing.Color.White;
            this.C10.Location = new System.Drawing.Point(588, 157);
            this.C10.Name = "C10";
            this.C10.Size = new System.Drawing.Size(50, 50);
            this.C10.TabIndex = 51;
            this.C10.Text = "C10";
            this.C10.UseVisualStyleBackColor = false;
            this.C10.Click += new System.EventHandler(this.C10_Click);
            // 
            // C9
            // 
            this.C9.BackColor = System.Drawing.Color.SlateBlue;
            this.C9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C9.ForeColor = System.Drawing.Color.White;
            this.C9.Location = new System.Drawing.Point(532, 157);
            this.C9.Name = "C9";
            this.C9.Size = new System.Drawing.Size(50, 50);
            this.C9.TabIndex = 50;
            this.C9.Text = "C9";
            this.C9.UseVisualStyleBackColor = false;
            this.C9.Click += new System.EventHandler(this.C9_Click);
            // 
            // C8
            // 
            this.C8.BackColor = System.Drawing.Color.SlateBlue;
            this.C8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C8.ForeColor = System.Drawing.Color.White;
            this.C8.Location = new System.Drawing.Point(476, 157);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(50, 50);
            this.C8.TabIndex = 49;
            this.C8.Text = "C8";
            this.C8.UseVisualStyleBackColor = false;
            this.C8.Click += new System.EventHandler(this.C8_Click);
            // 
            // C7
            // 
            this.C7.BackColor = System.Drawing.Color.SlateBlue;
            this.C7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C7.ForeColor = System.Drawing.Color.White;
            this.C7.Location = new System.Drawing.Point(420, 157);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(50, 50);
            this.C7.TabIndex = 48;
            this.C7.Text = "C7";
            this.C7.UseVisualStyleBackColor = false;
            this.C7.Click += new System.EventHandler(this.C7_Click);
            // 
            // C6
            // 
            this.C6.BackColor = System.Drawing.Color.SlateBlue;
            this.C6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C6.ForeColor = System.Drawing.Color.White;
            this.C6.Location = new System.Drawing.Point(364, 157);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(50, 50);
            this.C6.TabIndex = 47;
            this.C6.Text = "C6";
            this.C6.UseVisualStyleBackColor = false;
            this.C6.Click += new System.EventHandler(this.C6_Click);
            // 
            // C5
            // 
            this.C5.BackColor = System.Drawing.Color.SlateBlue;
            this.C5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5.ForeColor = System.Drawing.Color.White;
            this.C5.Location = new System.Drawing.Point(308, 157);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(50, 50);
            this.C5.TabIndex = 46;
            this.C5.Text = "C5";
            this.C5.UseVisualStyleBackColor = false;
            this.C5.Click += new System.EventHandler(this.C5_Click);
            // 
            // C4
            // 
            this.C4.BackColor = System.Drawing.Color.SlateBlue;
            this.C4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4.ForeColor = System.Drawing.Color.White;
            this.C4.Location = new System.Drawing.Point(252, 157);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(50, 50);
            this.C4.TabIndex = 45;
            this.C4.Text = "C4";
            this.C4.UseVisualStyleBackColor = false;
            this.C4.Click += new System.EventHandler(this.C4_Click);
            // 
            // C3
            // 
            this.C3.BackColor = System.Drawing.Color.SlateBlue;
            this.C3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.ForeColor = System.Drawing.Color.White;
            this.C3.Location = new System.Drawing.Point(196, 157);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(50, 50);
            this.C3.TabIndex = 44;
            this.C3.Text = "C3";
            this.C3.UseVisualStyleBackColor = false;
            this.C3.Click += new System.EventHandler(this.C3_Click);
            // 
            // C2
            // 
            this.C2.BackColor = System.Drawing.Color.SlateBlue;
            this.C2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.ForeColor = System.Drawing.Color.White;
            this.C2.Location = new System.Drawing.Point(140, 157);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(50, 50);
            this.C2.TabIndex = 43;
            this.C2.Text = "C2";
            this.C2.UseVisualStyleBackColor = false;
            this.C2.Click += new System.EventHandler(this.C2_Click);
            // 
            // C1
            // 
            this.C1.BackColor = System.Drawing.Color.SlateBlue;
            this.C1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.ForeColor = System.Drawing.Color.White;
            this.C1.Location = new System.Drawing.Point(84, 157);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(50, 50);
            this.C1.TabIndex = 42;
            this.C1.Text = "C1";
            this.C1.UseVisualStyleBackColor = false;
            this.C1.Click += new System.EventHandler(this.C1_Click);
            // 
            // D20
            // 
            this.D20.BackColor = System.Drawing.Color.SlateBlue;
            this.D20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D20.ForeColor = System.Drawing.Color.White;
            this.D20.Location = new System.Drawing.Point(1148, 213);
            this.D20.Name = "D20";
            this.D20.Size = new System.Drawing.Size(50, 50);
            this.D20.TabIndex = 81;
            this.D20.Text = "D20";
            this.D20.UseVisualStyleBackColor = false;
            this.D20.Click += new System.EventHandler(this.D20_Click);
            // 
            // D19
            // 
            this.D19.BackColor = System.Drawing.Color.SlateBlue;
            this.D19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D19.ForeColor = System.Drawing.Color.White;
            this.D19.Location = new System.Drawing.Point(1092, 213);
            this.D19.Name = "D19";
            this.D19.Size = new System.Drawing.Size(50, 50);
            this.D19.TabIndex = 80;
            this.D19.Text = "D19";
            this.D19.UseVisualStyleBackColor = false;
            this.D19.Click += new System.EventHandler(this.D19_Click);
            // 
            // D18
            // 
            this.D18.BackColor = System.Drawing.Color.SlateBlue;
            this.D18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D18.ForeColor = System.Drawing.Color.White;
            this.D18.Location = new System.Drawing.Point(1036, 213);
            this.D18.Name = "D18";
            this.D18.Size = new System.Drawing.Size(50, 50);
            this.D18.TabIndex = 79;
            this.D18.Text = "D18";
            this.D18.UseVisualStyleBackColor = false;
            this.D18.Click += new System.EventHandler(this.D18_Click);
            // 
            // D17
            // 
            this.D17.BackColor = System.Drawing.Color.SlateBlue;
            this.D17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D17.ForeColor = System.Drawing.Color.White;
            this.D17.Location = new System.Drawing.Point(980, 213);
            this.D17.Name = "D17";
            this.D17.Size = new System.Drawing.Size(50, 50);
            this.D17.TabIndex = 78;
            this.D17.Text = "D17";
            this.D17.UseVisualStyleBackColor = false;
            this.D17.Click += new System.EventHandler(this.D17_Click);
            // 
            // D16
            // 
            this.D16.BackColor = System.Drawing.Color.SlateBlue;
            this.D16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D16.ForeColor = System.Drawing.Color.White;
            this.D16.Location = new System.Drawing.Point(924, 213);
            this.D16.Name = "D16";
            this.D16.Size = new System.Drawing.Size(50, 50);
            this.D16.TabIndex = 77;
            this.D16.Text = "D16";
            this.D16.UseVisualStyleBackColor = false;
            this.D16.Click += new System.EventHandler(this.D16_Click);
            // 
            // D15
            // 
            this.D15.BackColor = System.Drawing.Color.SlateBlue;
            this.D15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D15.ForeColor = System.Drawing.Color.White;
            this.D15.Location = new System.Drawing.Point(868, 213);
            this.D15.Name = "D15";
            this.D15.Size = new System.Drawing.Size(50, 50);
            this.D15.TabIndex = 76;
            this.D15.Text = "D15";
            this.D15.UseVisualStyleBackColor = false;
            this.D15.Click += new System.EventHandler(this.D15_Click);
            // 
            // D14
            // 
            this.D14.BackColor = System.Drawing.Color.SlateBlue;
            this.D14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D14.ForeColor = System.Drawing.Color.White;
            this.D14.Location = new System.Drawing.Point(812, 213);
            this.D14.Name = "D14";
            this.D14.Size = new System.Drawing.Size(50, 50);
            this.D14.TabIndex = 75;
            this.D14.Text = "D14";
            this.D14.UseVisualStyleBackColor = false;
            this.D14.Click += new System.EventHandler(this.D14_Click);
            // 
            // D13
            // 
            this.D13.BackColor = System.Drawing.Color.SlateBlue;
            this.D13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D13.ForeColor = System.Drawing.Color.White;
            this.D13.Location = new System.Drawing.Point(756, 213);
            this.D13.Name = "D13";
            this.D13.Size = new System.Drawing.Size(50, 50);
            this.D13.TabIndex = 74;
            this.D13.Text = "D13";
            this.D13.UseVisualStyleBackColor = false;
            this.D13.Click += new System.EventHandler(this.D13_Click);
            // 
            // D12
            // 
            this.D12.BackColor = System.Drawing.Color.SlateBlue;
            this.D12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D12.ForeColor = System.Drawing.Color.White;
            this.D12.Location = new System.Drawing.Point(700, 213);
            this.D12.Name = "D12";
            this.D12.Size = new System.Drawing.Size(50, 50);
            this.D12.TabIndex = 73;
            this.D12.Text = "D12";
            this.D12.UseVisualStyleBackColor = false;
            this.D12.Click += new System.EventHandler(this.D12_Click);
            // 
            // D11
            // 
            this.D11.BackColor = System.Drawing.Color.SlateBlue;
            this.D11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D11.ForeColor = System.Drawing.Color.White;
            this.D11.Location = new System.Drawing.Point(644, 213);
            this.D11.Name = "D11";
            this.D11.Size = new System.Drawing.Size(50, 50);
            this.D11.TabIndex = 72;
            this.D11.Text = "D11";
            this.D11.UseVisualStyleBackColor = false;
            this.D11.Click += new System.EventHandler(this.D11_Click);
            // 
            // D10
            // 
            this.D10.BackColor = System.Drawing.Color.SlateBlue;
            this.D10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D10.ForeColor = System.Drawing.Color.White;
            this.D10.Location = new System.Drawing.Point(588, 213);
            this.D10.Name = "D10";
            this.D10.Size = new System.Drawing.Size(50, 50);
            this.D10.TabIndex = 71;
            this.D10.Text = "D10";
            this.D10.UseVisualStyleBackColor = false;
            this.D10.Click += new System.EventHandler(this.D10_Click);
            // 
            // D9
            // 
            this.D9.BackColor = System.Drawing.Color.SlateBlue;
            this.D9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D9.ForeColor = System.Drawing.Color.White;
            this.D9.Location = new System.Drawing.Point(532, 213);
            this.D9.Name = "D9";
            this.D9.Size = new System.Drawing.Size(50, 50);
            this.D9.TabIndex = 70;
            this.D9.Text = "D9";
            this.D9.UseVisualStyleBackColor = false;
            this.D9.Click += new System.EventHandler(this.D9_Click);
            // 
            // D8
            // 
            this.D8.BackColor = System.Drawing.Color.SlateBlue;
            this.D8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D8.ForeColor = System.Drawing.Color.White;
            this.D8.Location = new System.Drawing.Point(476, 213);
            this.D8.Name = "D8";
            this.D8.Size = new System.Drawing.Size(50, 50);
            this.D8.TabIndex = 69;
            this.D8.Text = "D8";
            this.D8.UseVisualStyleBackColor = false;
            this.D8.Click += new System.EventHandler(this.D8_Click);
            // 
            // D7
            // 
            this.D7.BackColor = System.Drawing.Color.SlateBlue;
            this.D7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D7.ForeColor = System.Drawing.Color.White;
            this.D7.Location = new System.Drawing.Point(420, 213);
            this.D7.Name = "D7";
            this.D7.Size = new System.Drawing.Size(50, 50);
            this.D7.TabIndex = 68;
            this.D7.Text = "D7";
            this.D7.UseVisualStyleBackColor = false;
            this.D7.Click += new System.EventHandler(this.D7_Click);
            // 
            // D6
            // 
            this.D6.BackColor = System.Drawing.Color.SlateBlue;
            this.D6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D6.ForeColor = System.Drawing.Color.White;
            this.D6.Location = new System.Drawing.Point(364, 213);
            this.D6.Name = "D6";
            this.D6.Size = new System.Drawing.Size(50, 50);
            this.D6.TabIndex = 67;
            this.D6.Text = "D6";
            this.D6.UseVisualStyleBackColor = false;
            this.D6.Click += new System.EventHandler(this.D6_Click);
            // 
            // D5
            // 
            this.D5.BackColor = System.Drawing.Color.SlateBlue;
            this.D5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D5.ForeColor = System.Drawing.Color.White;
            this.D5.Location = new System.Drawing.Point(308, 213);
            this.D5.Name = "D5";
            this.D5.Size = new System.Drawing.Size(50, 50);
            this.D5.TabIndex = 66;
            this.D5.Text = "D5";
            this.D5.UseVisualStyleBackColor = false;
            this.D5.Click += new System.EventHandler(this.D5_Click);
            // 
            // D4
            // 
            this.D4.BackColor = System.Drawing.Color.SlateBlue;
            this.D4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D4.ForeColor = System.Drawing.Color.White;
            this.D4.Location = new System.Drawing.Point(252, 213);
            this.D4.Name = "D4";
            this.D4.Size = new System.Drawing.Size(50, 50);
            this.D4.TabIndex = 65;
            this.D4.Text = "D4";
            this.D4.UseVisualStyleBackColor = false;
            this.D4.Click += new System.EventHandler(this.D4_Click);
            // 
            // D3
            // 
            this.D3.BackColor = System.Drawing.Color.SlateBlue;
            this.D3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D3.ForeColor = System.Drawing.Color.White;
            this.D3.Location = new System.Drawing.Point(196, 213);
            this.D3.Name = "D3";
            this.D3.Size = new System.Drawing.Size(50, 50);
            this.D3.TabIndex = 64;
            this.D3.Text = "D3";
            this.D3.UseVisualStyleBackColor = false;
            this.D3.Click += new System.EventHandler(this.D3_Click);
            // 
            // D2
            // 
            this.D2.BackColor = System.Drawing.Color.SlateBlue;
            this.D2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D2.ForeColor = System.Drawing.Color.White;
            this.D2.Location = new System.Drawing.Point(140, 213);
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(50, 50);
            this.D2.TabIndex = 63;
            this.D2.Text = "D2";
            this.D2.UseVisualStyleBackColor = false;
            this.D2.Click += new System.EventHandler(this.D2_Click);
            // 
            // D1
            // 
            this.D1.BackColor = System.Drawing.Color.SlateBlue;
            this.D1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D1.ForeColor = System.Drawing.Color.White;
            this.D1.Location = new System.Drawing.Point(84, 213);
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(50, 50);
            this.D1.TabIndex = 62;
            this.D1.Text = "D1";
            this.D1.UseVisualStyleBackColor = false;
            this.D1.Click += new System.EventHandler(this.D1_Click);
            // 
            // E20
            // 
            this.E20.BackColor = System.Drawing.Color.SlateBlue;
            this.E20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E20.ForeColor = System.Drawing.Color.White;
            this.E20.Location = new System.Drawing.Point(1148, 269);
            this.E20.Name = "E20";
            this.E20.Size = new System.Drawing.Size(50, 50);
            this.E20.TabIndex = 101;
            this.E20.Text = "E20";
            this.E20.UseVisualStyleBackColor = false;
            this.E20.Click += new System.EventHandler(this.E20_Click);
            // 
            // E19
            // 
            this.E19.BackColor = System.Drawing.Color.SlateBlue;
            this.E19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E19.ForeColor = System.Drawing.Color.White;
            this.E19.Location = new System.Drawing.Point(1092, 269);
            this.E19.Name = "E19";
            this.E19.Size = new System.Drawing.Size(50, 50);
            this.E19.TabIndex = 100;
            this.E19.Text = "E19";
            this.E19.UseVisualStyleBackColor = false;
            this.E19.Click += new System.EventHandler(this.E19_Click);
            // 
            // E18
            // 
            this.E18.BackColor = System.Drawing.Color.SlateBlue;
            this.E18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E18.ForeColor = System.Drawing.Color.White;
            this.E18.Location = new System.Drawing.Point(1036, 269);
            this.E18.Name = "E18";
            this.E18.Size = new System.Drawing.Size(50, 50);
            this.E18.TabIndex = 99;
            this.E18.Text = "E18";
            this.E18.UseVisualStyleBackColor = false;
            this.E18.Click += new System.EventHandler(this.E18_Click);
            // 
            // E17
            // 
            this.E17.BackColor = System.Drawing.Color.SlateBlue;
            this.E17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E17.ForeColor = System.Drawing.Color.White;
            this.E17.Location = new System.Drawing.Point(980, 269);
            this.E17.Name = "E17";
            this.E17.Size = new System.Drawing.Size(50, 50);
            this.E17.TabIndex = 98;
            this.E17.Text = "E17";
            this.E17.UseVisualStyleBackColor = false;
            this.E17.Click += new System.EventHandler(this.E17_Click);
            // 
            // E16
            // 
            this.E16.BackColor = System.Drawing.Color.SlateBlue;
            this.E16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E16.ForeColor = System.Drawing.Color.White;
            this.E16.Location = new System.Drawing.Point(924, 269);
            this.E16.Name = "E16";
            this.E16.Size = new System.Drawing.Size(50, 50);
            this.E16.TabIndex = 97;
            this.E16.Text = "E16";
            this.E16.UseVisualStyleBackColor = false;
            this.E16.Click += new System.EventHandler(this.E16_Click);
            // 
            // E15
            // 
            this.E15.BackColor = System.Drawing.Color.SlateBlue;
            this.E15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E15.ForeColor = System.Drawing.Color.White;
            this.E15.Location = new System.Drawing.Point(868, 269);
            this.E15.Name = "E15";
            this.E15.Size = new System.Drawing.Size(50, 50);
            this.E15.TabIndex = 96;
            this.E15.Text = "E15";
            this.E15.UseVisualStyleBackColor = false;
            this.E15.Click += new System.EventHandler(this.E15_Click);
            // 
            // E14
            // 
            this.E14.BackColor = System.Drawing.Color.SlateBlue;
            this.E14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E14.ForeColor = System.Drawing.Color.White;
            this.E14.Location = new System.Drawing.Point(812, 269);
            this.E14.Name = "E14";
            this.E14.Size = new System.Drawing.Size(50, 50);
            this.E14.TabIndex = 95;
            this.E14.Text = "E14";
            this.E14.UseVisualStyleBackColor = false;
            this.E14.Click += new System.EventHandler(this.E14_Click);
            // 
            // E13
            // 
            this.E13.BackColor = System.Drawing.Color.SlateBlue;
            this.E13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E13.ForeColor = System.Drawing.Color.White;
            this.E13.Location = new System.Drawing.Point(756, 269);
            this.E13.Name = "E13";
            this.E13.Size = new System.Drawing.Size(50, 50);
            this.E13.TabIndex = 94;
            this.E13.Text = "E13";
            this.E13.UseVisualStyleBackColor = false;
            this.E13.Click += new System.EventHandler(this.E13_Click);
            // 
            // E12
            // 
            this.E12.BackColor = System.Drawing.Color.SlateBlue;
            this.E12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E12.ForeColor = System.Drawing.Color.White;
            this.E12.Location = new System.Drawing.Point(700, 269);
            this.E12.Name = "E12";
            this.E12.Size = new System.Drawing.Size(50, 50);
            this.E12.TabIndex = 93;
            this.E12.Text = "E12";
            this.E12.UseVisualStyleBackColor = false;
            this.E12.Click += new System.EventHandler(this.E12_Click);
            // 
            // E11
            // 
            this.E11.BackColor = System.Drawing.Color.SlateBlue;
            this.E11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E11.ForeColor = System.Drawing.Color.White;
            this.E11.Location = new System.Drawing.Point(644, 269);
            this.E11.Name = "E11";
            this.E11.Size = new System.Drawing.Size(50, 50);
            this.E11.TabIndex = 92;
            this.E11.Text = "E11";
            this.E11.UseVisualStyleBackColor = false;
            this.E11.Click += new System.EventHandler(this.E11_Click);
            // 
            // E10
            // 
            this.E10.BackColor = System.Drawing.Color.SlateBlue;
            this.E10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E10.ForeColor = System.Drawing.Color.White;
            this.E10.Location = new System.Drawing.Point(588, 269);
            this.E10.Name = "E10";
            this.E10.Size = new System.Drawing.Size(50, 50);
            this.E10.TabIndex = 91;
            this.E10.Text = "E10";
            this.E10.UseVisualStyleBackColor = false;
            this.E10.Click += new System.EventHandler(this.E10_Click);
            // 
            // E9
            // 
            this.E9.BackColor = System.Drawing.Color.SlateBlue;
            this.E9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E9.ForeColor = System.Drawing.Color.White;
            this.E9.Location = new System.Drawing.Point(532, 269);
            this.E9.Name = "E9";
            this.E9.Size = new System.Drawing.Size(50, 50);
            this.E9.TabIndex = 90;
            this.E9.Text = "E9";
            this.E9.UseVisualStyleBackColor = false;
            this.E9.Click += new System.EventHandler(this.E9_Click);
            // 
            // E8
            // 
            this.E8.BackColor = System.Drawing.Color.SlateBlue;
            this.E8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E8.ForeColor = System.Drawing.Color.White;
            this.E8.Location = new System.Drawing.Point(476, 269);
            this.E8.Name = "E8";
            this.E8.Size = new System.Drawing.Size(50, 50);
            this.E8.TabIndex = 89;
            this.E8.Text = "E8";
            this.E8.UseVisualStyleBackColor = false;
            this.E8.Click += new System.EventHandler(this.E8_Click);
            // 
            // E7
            // 
            this.E7.BackColor = System.Drawing.Color.SlateBlue;
            this.E7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E7.ForeColor = System.Drawing.Color.White;
            this.E7.Location = new System.Drawing.Point(420, 269);
            this.E7.Name = "E7";
            this.E7.Size = new System.Drawing.Size(50, 50);
            this.E7.TabIndex = 88;
            this.E7.Text = "E7";
            this.E7.UseVisualStyleBackColor = false;
            this.E7.Click += new System.EventHandler(this.E7_Click);
            // 
            // E6
            // 
            this.E6.BackColor = System.Drawing.Color.SlateBlue;
            this.E6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E6.ForeColor = System.Drawing.Color.White;
            this.E6.Location = new System.Drawing.Point(364, 269);
            this.E6.Name = "E6";
            this.E6.Size = new System.Drawing.Size(50, 50);
            this.E6.TabIndex = 87;
            this.E6.Text = "E6";
            this.E6.UseVisualStyleBackColor = false;
            this.E6.Click += new System.EventHandler(this.E6_Click);
            // 
            // E5
            // 
            this.E5.BackColor = System.Drawing.Color.SlateBlue;
            this.E5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E5.ForeColor = System.Drawing.Color.White;
            this.E5.Location = new System.Drawing.Point(308, 269);
            this.E5.Name = "E5";
            this.E5.Size = new System.Drawing.Size(50, 50);
            this.E5.TabIndex = 86;
            this.E5.Text = "E5";
            this.E5.UseVisualStyleBackColor = false;
            this.E5.Click += new System.EventHandler(this.E5_Click);
            // 
            // E4
            // 
            this.E4.BackColor = System.Drawing.Color.SlateBlue;
            this.E4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E4.ForeColor = System.Drawing.Color.White;
            this.E4.Location = new System.Drawing.Point(252, 269);
            this.E4.Name = "E4";
            this.E4.Size = new System.Drawing.Size(50, 50);
            this.E4.TabIndex = 85;
            this.E4.Text = "E4";
            this.E4.UseVisualStyleBackColor = false;
            this.E4.Click += new System.EventHandler(this.E4_Click);
            // 
            // E3
            // 
            this.E3.BackColor = System.Drawing.Color.SlateBlue;
            this.E3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E3.ForeColor = System.Drawing.Color.White;
            this.E3.Location = new System.Drawing.Point(196, 269);
            this.E3.Name = "E3";
            this.E3.Size = new System.Drawing.Size(50, 50);
            this.E3.TabIndex = 84;
            this.E3.Text = "E3";
            this.E3.UseVisualStyleBackColor = false;
            this.E3.Click += new System.EventHandler(this.E3_Click);
            // 
            // E2
            // 
            this.E2.BackColor = System.Drawing.Color.SlateBlue;
            this.E2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E2.ForeColor = System.Drawing.Color.White;
            this.E2.Location = new System.Drawing.Point(140, 269);
            this.E2.Name = "E2";
            this.E2.Size = new System.Drawing.Size(50, 50);
            this.E2.TabIndex = 83;
            this.E2.Text = "E2";
            this.E2.UseVisualStyleBackColor = false;
            this.E2.Click += new System.EventHandler(this.E2_Click);
            // 
            // E1
            // 
            this.E1.BackColor = System.Drawing.Color.SlateBlue;
            this.E1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.E1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E1.ForeColor = System.Drawing.Color.White;
            this.E1.Location = new System.Drawing.Point(84, 269);
            this.E1.Name = "E1";
            this.E1.Size = new System.Drawing.Size(50, 50);
            this.E1.TabIndex = 82;
            this.E1.Text = "E1";
            this.E1.UseVisualStyleBackColor = false;
            this.E1.Click += new System.EventHandler(this.E1_Click);
            // 
            // F20
            // 
            this.F20.BackColor = System.Drawing.Color.SlateBlue;
            this.F20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F20.ForeColor = System.Drawing.Color.White;
            this.F20.Location = new System.Drawing.Point(1148, 325);
            this.F20.Name = "F20";
            this.F20.Size = new System.Drawing.Size(50, 50);
            this.F20.TabIndex = 121;
            this.F20.Text = "F20";
            this.F20.UseVisualStyleBackColor = false;
            this.F20.Click += new System.EventHandler(this.F20_Click);
            // 
            // F19
            // 
            this.F19.BackColor = System.Drawing.Color.SlateBlue;
            this.F19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F19.ForeColor = System.Drawing.Color.White;
            this.F19.Location = new System.Drawing.Point(1092, 325);
            this.F19.Name = "F19";
            this.F19.Size = new System.Drawing.Size(50, 50);
            this.F19.TabIndex = 120;
            this.F19.Text = "F19";
            this.F19.UseVisualStyleBackColor = false;
            this.F19.Click += new System.EventHandler(this.F19_Click);
            // 
            // F18
            // 
            this.F18.BackColor = System.Drawing.Color.SlateBlue;
            this.F18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F18.ForeColor = System.Drawing.Color.White;
            this.F18.Location = new System.Drawing.Point(1036, 325);
            this.F18.Name = "F18";
            this.F18.Size = new System.Drawing.Size(50, 50);
            this.F18.TabIndex = 119;
            this.F18.Text = "F18";
            this.F18.UseVisualStyleBackColor = false;
            this.F18.Click += new System.EventHandler(this.F18_Click);
            // 
            // F17
            // 
            this.F17.BackColor = System.Drawing.Color.SlateBlue;
            this.F17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F17.ForeColor = System.Drawing.Color.White;
            this.F17.Location = new System.Drawing.Point(980, 325);
            this.F17.Name = "F17";
            this.F17.Size = new System.Drawing.Size(50, 50);
            this.F17.TabIndex = 118;
            this.F17.Text = "F17";
            this.F17.UseVisualStyleBackColor = false;
            this.F17.Click += new System.EventHandler(this.F17_Click);
            // 
            // F16
            // 
            this.F16.BackColor = System.Drawing.Color.SlateBlue;
            this.F16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F16.ForeColor = System.Drawing.Color.White;
            this.F16.Location = new System.Drawing.Point(924, 325);
            this.F16.Name = "F16";
            this.F16.Size = new System.Drawing.Size(50, 50);
            this.F16.TabIndex = 117;
            this.F16.Text = "F16";
            this.F16.UseVisualStyleBackColor = false;
            this.F16.Click += new System.EventHandler(this.F16_Click);
            // 
            // F5
            // 
            this.F5.BackColor = System.Drawing.Color.SlateBlue;
            this.F5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F5.ForeColor = System.Drawing.Color.White;
            this.F5.Location = new System.Drawing.Point(308, 325);
            this.F5.Name = "F5";
            this.F5.Size = new System.Drawing.Size(50, 50);
            this.F5.TabIndex = 106;
            this.F5.Text = "F5";
            this.F5.UseVisualStyleBackColor = false;
            this.F5.Click += new System.EventHandler(this.F5_Click);
            // 
            // F4
            // 
            this.F4.BackColor = System.Drawing.Color.SlateBlue;
            this.F4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F4.ForeColor = System.Drawing.Color.White;
            this.F4.Location = new System.Drawing.Point(252, 325);
            this.F4.Name = "F4";
            this.F4.Size = new System.Drawing.Size(50, 50);
            this.F4.TabIndex = 105;
            this.F4.Text = "F4";
            this.F4.UseVisualStyleBackColor = false;
            this.F4.Click += new System.EventHandler(this.F4_Click);
            // 
            // F3
            // 
            this.F3.BackColor = System.Drawing.Color.SlateBlue;
            this.F3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F3.ForeColor = System.Drawing.Color.White;
            this.F3.Location = new System.Drawing.Point(196, 325);
            this.F3.Name = "F3";
            this.F3.Size = new System.Drawing.Size(50, 50);
            this.F3.TabIndex = 104;
            this.F3.Text = "F3";
            this.F3.UseVisualStyleBackColor = false;
            this.F3.Click += new System.EventHandler(this.F3_Click);
            // 
            // F2
            // 
            this.F2.BackColor = System.Drawing.Color.SlateBlue;
            this.F2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F2.ForeColor = System.Drawing.Color.White;
            this.F2.Location = new System.Drawing.Point(140, 325);
            this.F2.Name = "F2";
            this.F2.Size = new System.Drawing.Size(50, 50);
            this.F2.TabIndex = 103;
            this.F2.Text = "F2";
            this.F2.UseVisualStyleBackColor = false;
            this.F2.Click += new System.EventHandler(this.F2_Click);
            // 
            // F1
            // 
            this.F1.BackColor = System.Drawing.Color.SlateBlue;
            this.F1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F1.ForeColor = System.Drawing.Color.White;
            this.F1.Location = new System.Drawing.Point(84, 325);
            this.F1.Name = "F1";
            this.F1.Size = new System.Drawing.Size(50, 50);
            this.F1.TabIndex = 102;
            this.F1.Text = "F1";
            this.F1.UseVisualStyleBackColor = false;
            this.F1.Click += new System.EventHandler(this.F1_Click);
            // 
            // G20
            // 
            this.G20.BackColor = System.Drawing.Color.SlateBlue;
            this.G20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G20.ForeColor = System.Drawing.Color.White;
            this.G20.Location = new System.Drawing.Point(1148, 381);
            this.G20.Name = "G20";
            this.G20.Size = new System.Drawing.Size(50, 50);
            this.G20.TabIndex = 141;
            this.G20.Text = "G20";
            this.G20.UseVisualStyleBackColor = false;
            this.G20.Click += new System.EventHandler(this.G20_Click);
            // 
            // G19
            // 
            this.G19.BackColor = System.Drawing.Color.SlateBlue;
            this.G19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G19.ForeColor = System.Drawing.Color.White;
            this.G19.Location = new System.Drawing.Point(1092, 381);
            this.G19.Name = "G19";
            this.G19.Size = new System.Drawing.Size(50, 50);
            this.G19.TabIndex = 140;
            this.G19.Text = "G19";
            this.G19.UseVisualStyleBackColor = false;
            this.G19.Click += new System.EventHandler(this.G19_Click);
            // 
            // G18
            // 
            this.G18.BackColor = System.Drawing.Color.SlateBlue;
            this.G18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G18.ForeColor = System.Drawing.Color.White;
            this.G18.Location = new System.Drawing.Point(1036, 381);
            this.G18.Name = "G18";
            this.G18.Size = new System.Drawing.Size(50, 50);
            this.G18.TabIndex = 139;
            this.G18.Text = "G18";
            this.G18.UseVisualStyleBackColor = false;
            this.G18.Click += new System.EventHandler(this.G18_Click);
            // 
            // G17
            // 
            this.G17.BackColor = System.Drawing.Color.SlateBlue;
            this.G17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G17.ForeColor = System.Drawing.Color.White;
            this.G17.Location = new System.Drawing.Point(980, 381);
            this.G17.Name = "G17";
            this.G17.Size = new System.Drawing.Size(50, 50);
            this.G17.TabIndex = 138;
            this.G17.Text = "G17";
            this.G17.UseVisualStyleBackColor = false;
            this.G17.Click += new System.EventHandler(this.G17_Click);
            // 
            // G16
            // 
            this.G16.BackColor = System.Drawing.Color.SlateBlue;
            this.G16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G16.ForeColor = System.Drawing.Color.White;
            this.G16.Location = new System.Drawing.Point(924, 381);
            this.G16.Name = "G16";
            this.G16.Size = new System.Drawing.Size(50, 50);
            this.G16.TabIndex = 137;
            this.G16.Text = "G16";
            this.G16.UseVisualStyleBackColor = false;
            this.G16.Click += new System.EventHandler(this.G16_Click);
            // 
            // G5
            // 
            this.G5.BackColor = System.Drawing.Color.SlateBlue;
            this.G5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G5.ForeColor = System.Drawing.Color.White;
            this.G5.Location = new System.Drawing.Point(308, 381);
            this.G5.Name = "G5";
            this.G5.Size = new System.Drawing.Size(50, 50);
            this.G5.TabIndex = 126;
            this.G5.Text = "G5";
            this.G5.UseVisualStyleBackColor = false;
            this.G5.Click += new System.EventHandler(this.G5_Click);
            // 
            // G4
            // 
            this.G4.BackColor = System.Drawing.Color.SlateBlue;
            this.G4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G4.ForeColor = System.Drawing.Color.White;
            this.G4.Location = new System.Drawing.Point(252, 381);
            this.G4.Name = "G4";
            this.G4.Size = new System.Drawing.Size(50, 50);
            this.G4.TabIndex = 125;
            this.G4.Text = "G4";
            this.G4.UseVisualStyleBackColor = false;
            this.G4.Click += new System.EventHandler(this.G4_Click);
            // 
            // G3
            // 
            this.G3.BackColor = System.Drawing.Color.SlateBlue;
            this.G3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G3.ForeColor = System.Drawing.Color.White;
            this.G3.Location = new System.Drawing.Point(196, 381);
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(50, 50);
            this.G3.TabIndex = 124;
            this.G3.Text = "G3";
            this.G3.UseVisualStyleBackColor = false;
            this.G3.Click += new System.EventHandler(this.G3_Click);
            // 
            // G2
            // 
            this.G2.BackColor = System.Drawing.Color.SlateBlue;
            this.G2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G2.ForeColor = System.Drawing.Color.White;
            this.G2.Location = new System.Drawing.Point(140, 381);
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(50, 50);
            this.G2.TabIndex = 123;
            this.G2.Text = "G2";
            this.G2.UseVisualStyleBackColor = false;
            this.G2.Click += new System.EventHandler(this.G2_Click);
            // 
            // G1
            // 
            this.G1.BackColor = System.Drawing.Color.SlateBlue;
            this.G1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G1.ForeColor = System.Drawing.Color.White;
            this.G1.Location = new System.Drawing.Point(84, 381);
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(50, 50);
            this.G1.TabIndex = 122;
            this.G1.Text = "G1";
            this.G1.UseVisualStyleBackColor = false;
            this.G1.Click += new System.EventHandler(this.G1_Click);
            // 
            // H20
            // 
            this.H20.BackColor = System.Drawing.Color.SlateBlue;
            this.H20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H20.ForeColor = System.Drawing.Color.White;
            this.H20.Location = new System.Drawing.Point(1148, 437);
            this.H20.Name = "H20";
            this.H20.Size = new System.Drawing.Size(50, 50);
            this.H20.TabIndex = 161;
            this.H20.Text = "H20";
            this.H20.UseVisualStyleBackColor = false;
            this.H20.Click += new System.EventHandler(this.H20_Click);
            // 
            // H19
            // 
            this.H19.BackColor = System.Drawing.Color.SlateBlue;
            this.H19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H19.ForeColor = System.Drawing.Color.White;
            this.H19.Location = new System.Drawing.Point(1092, 437);
            this.H19.Name = "H19";
            this.H19.Size = new System.Drawing.Size(50, 50);
            this.H19.TabIndex = 160;
            this.H19.Text = "H19";
            this.H19.UseVisualStyleBackColor = false;
            this.H19.Click += new System.EventHandler(this.H19_Click);
            // 
            // H18
            // 
            this.H18.BackColor = System.Drawing.Color.SlateBlue;
            this.H18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H18.ForeColor = System.Drawing.Color.White;
            this.H18.Location = new System.Drawing.Point(1036, 437);
            this.H18.Name = "H18";
            this.H18.Size = new System.Drawing.Size(50, 50);
            this.H18.TabIndex = 159;
            this.H18.Text = "H18";
            this.H18.UseVisualStyleBackColor = false;
            this.H18.Click += new System.EventHandler(this.H18_Click);
            // 
            // H17
            // 
            this.H17.BackColor = System.Drawing.Color.SlateBlue;
            this.H17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H17.ForeColor = System.Drawing.Color.White;
            this.H17.Location = new System.Drawing.Point(980, 437);
            this.H17.Name = "H17";
            this.H17.Size = new System.Drawing.Size(50, 50);
            this.H17.TabIndex = 158;
            this.H17.Text = "H17";
            this.H17.UseVisualStyleBackColor = false;
            this.H17.Click += new System.EventHandler(this.H17_Click);
            // 
            // H16
            // 
            this.H16.BackColor = System.Drawing.Color.SlateBlue;
            this.H16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H16.ForeColor = System.Drawing.Color.White;
            this.H16.Location = new System.Drawing.Point(924, 437);
            this.H16.Name = "H16";
            this.H16.Size = new System.Drawing.Size(50, 50);
            this.H16.TabIndex = 157;
            this.H16.Text = "H16";
            this.H16.UseVisualStyleBackColor = false;
            this.H16.Click += new System.EventHandler(this.H16_Click);
            // 
            // H5
            // 
            this.H5.BackColor = System.Drawing.Color.SlateBlue;
            this.H5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H5.ForeColor = System.Drawing.Color.White;
            this.H5.Location = new System.Drawing.Point(308, 437);
            this.H5.Name = "H5";
            this.H5.Size = new System.Drawing.Size(50, 50);
            this.H5.TabIndex = 146;
            this.H5.Text = "H5";
            this.H5.UseVisualStyleBackColor = false;
            this.H5.Click += new System.EventHandler(this.H5_Click);
            // 
            // H4
            // 
            this.H4.BackColor = System.Drawing.Color.SlateBlue;
            this.H4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H4.ForeColor = System.Drawing.Color.White;
            this.H4.Location = new System.Drawing.Point(252, 437);
            this.H4.Name = "H4";
            this.H4.Size = new System.Drawing.Size(50, 50);
            this.H4.TabIndex = 145;
            this.H4.Text = "H4";
            this.H4.UseVisualStyleBackColor = false;
            this.H4.Click += new System.EventHandler(this.H4_Click);
            // 
            // H3
            // 
            this.H3.BackColor = System.Drawing.Color.SlateBlue;
            this.H3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H3.ForeColor = System.Drawing.Color.White;
            this.H3.Location = new System.Drawing.Point(196, 437);
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(50, 50);
            this.H3.TabIndex = 144;
            this.H3.Text = "H3";
            this.H3.UseVisualStyleBackColor = false;
            this.H3.Click += new System.EventHandler(this.H3_Click);
            // 
            // H2
            // 
            this.H2.BackColor = System.Drawing.Color.SlateBlue;
            this.H2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H2.ForeColor = System.Drawing.Color.White;
            this.H2.Location = new System.Drawing.Point(140, 437);
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(50, 50);
            this.H2.TabIndex = 143;
            this.H2.Text = "H2";
            this.H2.UseVisualStyleBackColor = false;
            this.H2.Click += new System.EventHandler(this.H2_Click);
            // 
            // H1
            // 
            this.H1.BackColor = System.Drawing.Color.SlateBlue;
            this.H1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H1.ForeColor = System.Drawing.Color.White;
            this.H1.Location = new System.Drawing.Point(84, 437);
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(50, 50);
            this.H1.TabIndex = 142;
            this.H1.Text = "H1";
            this.H1.UseVisualStyleBackColor = false;
            this.H1.Click += new System.EventHandler(this.H1_Click);
            // 
            // I20
            // 
            this.I20.BackColor = System.Drawing.Color.SlateBlue;
            this.I20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I20.ForeColor = System.Drawing.Color.White;
            this.I20.Location = new System.Drawing.Point(1148, 493);
            this.I20.Name = "I20";
            this.I20.Size = new System.Drawing.Size(50, 50);
            this.I20.TabIndex = 181;
            this.I20.Text = "I20";
            this.I20.UseVisualStyleBackColor = false;
            this.I20.Click += new System.EventHandler(this.I20_Click);
            // 
            // I19
            // 
            this.I19.BackColor = System.Drawing.Color.SlateBlue;
            this.I19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I19.ForeColor = System.Drawing.Color.White;
            this.I19.Location = new System.Drawing.Point(1092, 493);
            this.I19.Name = "I19";
            this.I19.Size = new System.Drawing.Size(50, 50);
            this.I19.TabIndex = 180;
            this.I19.Text = "I19";
            this.I19.UseVisualStyleBackColor = false;
            this.I19.Click += new System.EventHandler(this.I19_Click);
            // 
            // I18
            // 
            this.I18.BackColor = System.Drawing.Color.SlateBlue;
            this.I18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I18.ForeColor = System.Drawing.Color.White;
            this.I18.Location = new System.Drawing.Point(1036, 493);
            this.I18.Name = "I18";
            this.I18.Size = new System.Drawing.Size(50, 50);
            this.I18.TabIndex = 179;
            this.I18.Text = "I18";
            this.I18.UseVisualStyleBackColor = false;
            this.I18.Click += new System.EventHandler(this.I18_Click);
            // 
            // I17
            // 
            this.I17.BackColor = System.Drawing.Color.SlateBlue;
            this.I17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I17.ForeColor = System.Drawing.Color.White;
            this.I17.Location = new System.Drawing.Point(980, 493);
            this.I17.Name = "I17";
            this.I17.Size = new System.Drawing.Size(50, 50);
            this.I17.TabIndex = 178;
            this.I17.Text = "I17";
            this.I17.UseVisualStyleBackColor = false;
            this.I17.Click += new System.EventHandler(this.I17_Click);
            // 
            // I16
            // 
            this.I16.BackColor = System.Drawing.Color.SlateBlue;
            this.I16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I16.ForeColor = System.Drawing.Color.White;
            this.I16.Location = new System.Drawing.Point(924, 493);
            this.I16.Name = "I16";
            this.I16.Size = new System.Drawing.Size(50, 50);
            this.I16.TabIndex = 177;
            this.I16.Text = "I16";
            this.I16.UseVisualStyleBackColor = false;
            this.I16.Click += new System.EventHandler(this.I16_Click);
            // 
            // I5
            // 
            this.I5.BackColor = System.Drawing.Color.SlateBlue;
            this.I5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I5.ForeColor = System.Drawing.Color.White;
            this.I5.Location = new System.Drawing.Point(308, 493);
            this.I5.Name = "I5";
            this.I5.Size = new System.Drawing.Size(50, 50);
            this.I5.TabIndex = 166;
            this.I5.Text = "I5";
            this.I5.UseVisualStyleBackColor = false;
            this.I5.Click += new System.EventHandler(this.I5_Click);
            // 
            // I4
            // 
            this.I4.BackColor = System.Drawing.Color.SlateBlue;
            this.I4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I4.ForeColor = System.Drawing.Color.White;
            this.I4.Location = new System.Drawing.Point(252, 493);
            this.I4.Name = "I4";
            this.I4.Size = new System.Drawing.Size(50, 50);
            this.I4.TabIndex = 165;
            this.I4.Text = "I4";
            this.I4.UseVisualStyleBackColor = false;
            this.I4.Click += new System.EventHandler(this.I4_Click);
            // 
            // I3
            // 
            this.I3.BackColor = System.Drawing.Color.SlateBlue;
            this.I3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I3.ForeColor = System.Drawing.Color.White;
            this.I3.Location = new System.Drawing.Point(196, 493);
            this.I3.Name = "I3";
            this.I3.Size = new System.Drawing.Size(50, 50);
            this.I3.TabIndex = 164;
            this.I3.Text = "I3";
            this.I3.UseVisualStyleBackColor = false;
            this.I3.Click += new System.EventHandler(this.I3_Click);
            // 
            // I2
            // 
            this.I2.BackColor = System.Drawing.Color.SlateBlue;
            this.I2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I2.ForeColor = System.Drawing.Color.White;
            this.I2.Location = new System.Drawing.Point(140, 493);
            this.I2.Name = "I2";
            this.I2.Size = new System.Drawing.Size(50, 50);
            this.I2.TabIndex = 163;
            this.I2.Text = "I2";
            this.I2.UseVisualStyleBackColor = false;
            this.I2.Click += new System.EventHandler(this.I2_Click);
            // 
            // I1
            // 
            this.I1.BackColor = System.Drawing.Color.SlateBlue;
            this.I1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I1.ForeColor = System.Drawing.Color.White;
            this.I1.Location = new System.Drawing.Point(84, 493);
            this.I1.Name = "I1";
            this.I1.Size = new System.Drawing.Size(50, 50);
            this.I1.TabIndex = 162;
            this.I1.Text = "I1";
            this.I1.UseVisualStyleBackColor = false;
            this.I1.Click += new System.EventHandler(this.I1_Click);
            // 
            // J20
            // 
            this.J20.BackColor = System.Drawing.Color.SlateBlue;
            this.J20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J20.ForeColor = System.Drawing.Color.White;
            this.J20.Location = new System.Drawing.Point(1148, 549);
            this.J20.Name = "J20";
            this.J20.Size = new System.Drawing.Size(50, 50);
            this.J20.TabIndex = 201;
            this.J20.Text = "J20";
            this.J20.UseVisualStyleBackColor = false;
            this.J20.Click += new System.EventHandler(this.J20_Click);
            // 
            // J19
            // 
            this.J19.BackColor = System.Drawing.Color.SlateBlue;
            this.J19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J19.ForeColor = System.Drawing.Color.White;
            this.J19.Location = new System.Drawing.Point(1092, 549);
            this.J19.Name = "J19";
            this.J19.Size = new System.Drawing.Size(50, 50);
            this.J19.TabIndex = 200;
            this.J19.Text = "J19";
            this.J19.UseVisualStyleBackColor = false;
            this.J19.Click += new System.EventHandler(this.J19_Click);
            // 
            // J18
            // 
            this.J18.BackColor = System.Drawing.Color.SlateBlue;
            this.J18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J18.ForeColor = System.Drawing.Color.White;
            this.J18.Location = new System.Drawing.Point(1036, 549);
            this.J18.Name = "J18";
            this.J18.Size = new System.Drawing.Size(50, 50);
            this.J18.TabIndex = 199;
            this.J18.Text = "J18";
            this.J18.UseVisualStyleBackColor = false;
            this.J18.Click += new System.EventHandler(this.J18_Click);
            // 
            // J17
            // 
            this.J17.BackColor = System.Drawing.Color.SlateBlue;
            this.J17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J17.ForeColor = System.Drawing.Color.White;
            this.J17.Location = new System.Drawing.Point(980, 549);
            this.J17.Name = "J17";
            this.J17.Size = new System.Drawing.Size(50, 50);
            this.J17.TabIndex = 198;
            this.J17.Text = "J17";
            this.J17.UseVisualStyleBackColor = false;
            this.J17.Click += new System.EventHandler(this.J17_Click);
            // 
            // J16
            // 
            this.J16.BackColor = System.Drawing.Color.SlateBlue;
            this.J16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J16.ForeColor = System.Drawing.Color.White;
            this.J16.Location = new System.Drawing.Point(924, 549);
            this.J16.Name = "J16";
            this.J16.Size = new System.Drawing.Size(50, 50);
            this.J16.TabIndex = 197;
            this.J16.Text = "J16";
            this.J16.UseVisualStyleBackColor = false;
            this.J16.Click += new System.EventHandler(this.J16_Click);
            // 
            // J15
            // 
            this.J15.BackColor = System.Drawing.Color.SlateBlue;
            this.J15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J15.ForeColor = System.Drawing.Color.White;
            this.J15.Location = new System.Drawing.Point(868, 549);
            this.J15.Name = "J15";
            this.J15.Size = new System.Drawing.Size(50, 50);
            this.J15.TabIndex = 196;
            this.J15.Text = "J15";
            this.J15.UseVisualStyleBackColor = false;
            this.J15.Click += new System.EventHandler(this.J15_Click);
            // 
            // J14
            // 
            this.J14.BackColor = System.Drawing.Color.SlateBlue;
            this.J14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J14.ForeColor = System.Drawing.Color.White;
            this.J14.Location = new System.Drawing.Point(812, 549);
            this.J14.Name = "J14";
            this.J14.Size = new System.Drawing.Size(50, 50);
            this.J14.TabIndex = 195;
            this.J14.Text = "J14";
            this.J14.UseVisualStyleBackColor = false;
            this.J14.Click += new System.EventHandler(this.J14_Click);
            // 
            // J13
            // 
            this.J13.BackColor = System.Drawing.Color.SlateBlue;
            this.J13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J13.ForeColor = System.Drawing.Color.White;
            this.J13.Location = new System.Drawing.Point(756, 549);
            this.J13.Name = "J13";
            this.J13.Size = new System.Drawing.Size(50, 50);
            this.J13.TabIndex = 194;
            this.J13.Text = "J13";
            this.J13.UseVisualStyleBackColor = false;
            this.J13.Click += new System.EventHandler(this.J13_Click);
            // 
            // J12
            // 
            this.J12.BackColor = System.Drawing.Color.SlateBlue;
            this.J12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J12.ForeColor = System.Drawing.Color.White;
            this.J12.Location = new System.Drawing.Point(700, 549);
            this.J12.Name = "J12";
            this.J12.Size = new System.Drawing.Size(50, 50);
            this.J12.TabIndex = 193;
            this.J12.Text = "J12";
            this.J12.UseVisualStyleBackColor = false;
            this.J12.Click += new System.EventHandler(this.J12_Click);
            // 
            // J11
            // 
            this.J11.BackColor = System.Drawing.Color.SlateBlue;
            this.J11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J11.ForeColor = System.Drawing.Color.White;
            this.J11.Location = new System.Drawing.Point(644, 549);
            this.J11.Name = "J11";
            this.J11.Size = new System.Drawing.Size(50, 50);
            this.J11.TabIndex = 192;
            this.J11.Text = "J11";
            this.J11.UseVisualStyleBackColor = false;
            this.J11.Click += new System.EventHandler(this.J11_Click);
            // 
            // J10
            // 
            this.J10.BackColor = System.Drawing.Color.SlateBlue;
            this.J10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J10.ForeColor = System.Drawing.Color.White;
            this.J10.Location = new System.Drawing.Point(588, 549);
            this.J10.Name = "J10";
            this.J10.Size = new System.Drawing.Size(50, 50);
            this.J10.TabIndex = 191;
            this.J10.Text = "J10";
            this.J10.UseVisualStyleBackColor = false;
            this.J10.Click += new System.EventHandler(this.J10_Click);
            // 
            // J9
            // 
            this.J9.BackColor = System.Drawing.Color.SlateBlue;
            this.J9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J9.ForeColor = System.Drawing.Color.White;
            this.J9.Location = new System.Drawing.Point(532, 549);
            this.J9.Name = "J9";
            this.J9.Size = new System.Drawing.Size(50, 50);
            this.J9.TabIndex = 190;
            this.J9.Text = "J9";
            this.J9.UseVisualStyleBackColor = false;
            this.J9.Click += new System.EventHandler(this.J9_Click);
            // 
            // J8
            // 
            this.J8.BackColor = System.Drawing.Color.SlateBlue;
            this.J8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J8.ForeColor = System.Drawing.Color.White;
            this.J8.Location = new System.Drawing.Point(476, 549);
            this.J8.Name = "J8";
            this.J8.Size = new System.Drawing.Size(50, 50);
            this.J8.TabIndex = 189;
            this.J8.Text = "J8";
            this.J8.UseVisualStyleBackColor = false;
            this.J8.Click += new System.EventHandler(this.J8_Click);
            // 
            // J7
            // 
            this.J7.BackColor = System.Drawing.Color.SlateBlue;
            this.J7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J7.ForeColor = System.Drawing.Color.White;
            this.J7.Location = new System.Drawing.Point(420, 549);
            this.J7.Name = "J7";
            this.J7.Size = new System.Drawing.Size(50, 50);
            this.J7.TabIndex = 188;
            this.J7.Text = "J7";
            this.J7.UseVisualStyleBackColor = false;
            this.J7.Click += new System.EventHandler(this.J7_Click);
            // 
            // J6
            // 
            this.J6.BackColor = System.Drawing.Color.SlateBlue;
            this.J6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J6.ForeColor = System.Drawing.Color.White;
            this.J6.Location = new System.Drawing.Point(364, 549);
            this.J6.Name = "J6";
            this.J6.Size = new System.Drawing.Size(50, 50);
            this.J6.TabIndex = 187;
            this.J6.Text = "J6";
            this.J6.UseVisualStyleBackColor = false;
            this.J6.Click += new System.EventHandler(this.J6_Click);
            // 
            // J5
            // 
            this.J5.BackColor = System.Drawing.Color.SlateBlue;
            this.J5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J5.ForeColor = System.Drawing.Color.White;
            this.J5.Location = new System.Drawing.Point(308, 549);
            this.J5.Name = "J5";
            this.J5.Size = new System.Drawing.Size(50, 50);
            this.J5.TabIndex = 186;
            this.J5.Text = "J5";
            this.J5.UseVisualStyleBackColor = false;
            this.J5.Click += new System.EventHandler(this.J5_Click);
            // 
            // J4
            // 
            this.J4.BackColor = System.Drawing.Color.SlateBlue;
            this.J4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J4.ForeColor = System.Drawing.Color.White;
            this.J4.Location = new System.Drawing.Point(252, 549);
            this.J4.Name = "J4";
            this.J4.Size = new System.Drawing.Size(50, 50);
            this.J4.TabIndex = 185;
            this.J4.Text = "J4";
            this.J4.UseVisualStyleBackColor = false;
            this.J4.Click += new System.EventHandler(this.J4_Click);
            // 
            // J3
            // 
            this.J3.BackColor = System.Drawing.Color.SlateBlue;
            this.J3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J3.ForeColor = System.Drawing.Color.White;
            this.J3.Location = new System.Drawing.Point(196, 549);
            this.J3.Name = "J3";
            this.J3.Size = new System.Drawing.Size(50, 50);
            this.J3.TabIndex = 184;
            this.J3.Text = "J3";
            this.J3.UseVisualStyleBackColor = false;
            this.J3.Click += new System.EventHandler(this.J3_Click);
            // 
            // J2
            // 
            this.J2.BackColor = System.Drawing.Color.SlateBlue;
            this.J2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J2.ForeColor = System.Drawing.Color.White;
            this.J2.Location = new System.Drawing.Point(140, 549);
            this.J2.Name = "J2";
            this.J2.Size = new System.Drawing.Size(50, 50);
            this.J2.TabIndex = 183;
            this.J2.Text = "J2";
            this.J2.UseVisualStyleBackColor = false;
            this.J2.Click += new System.EventHandler(this.J2_Click);
            // 
            // J1
            // 
            this.J1.BackColor = System.Drawing.Color.SlateBlue;
            this.J1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.J1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.J1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J1.ForeColor = System.Drawing.Color.White;
            this.J1.Location = new System.Drawing.Point(84, 549);
            this.J1.Name = "J1";
            this.J1.Size = new System.Drawing.Size(50, 50);
            this.J1.TabIndex = 182;
            this.J1.Text = "J1";
            this.J1.UseVisualStyleBackColor = false;
            this.J1.Click += new System.EventHandler(this.J1_Click);
            // 
            // K20
            // 
            this.K20.BackColor = System.Drawing.Color.SlateBlue;
            this.K20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K20.ForeColor = System.Drawing.Color.White;
            this.K20.Location = new System.Drawing.Point(1148, 605);
            this.K20.Name = "K20";
            this.K20.Size = new System.Drawing.Size(50, 50);
            this.K20.TabIndex = 221;
            this.K20.Text = "K20";
            this.K20.UseVisualStyleBackColor = false;
            this.K20.Click += new System.EventHandler(this.K20_Click);
            // 
            // K19
            // 
            this.K19.BackColor = System.Drawing.Color.SlateBlue;
            this.K19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K19.ForeColor = System.Drawing.Color.White;
            this.K19.Location = new System.Drawing.Point(1092, 605);
            this.K19.Name = "K19";
            this.K19.Size = new System.Drawing.Size(50, 50);
            this.K19.TabIndex = 220;
            this.K19.Text = "K19";
            this.K19.UseVisualStyleBackColor = false;
            this.K19.Click += new System.EventHandler(this.K19_Click);
            // 
            // K18
            // 
            this.K18.BackColor = System.Drawing.Color.SlateBlue;
            this.K18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K18.ForeColor = System.Drawing.Color.White;
            this.K18.Location = new System.Drawing.Point(1036, 605);
            this.K18.Name = "K18";
            this.K18.Size = new System.Drawing.Size(50, 50);
            this.K18.TabIndex = 219;
            this.K18.Text = "K18";
            this.K18.UseVisualStyleBackColor = false;
            this.K18.Click += new System.EventHandler(this.K18_Click);
            // 
            // K17
            // 
            this.K17.BackColor = System.Drawing.Color.SlateBlue;
            this.K17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K17.ForeColor = System.Drawing.Color.White;
            this.K17.Location = new System.Drawing.Point(980, 605);
            this.K17.Name = "K17";
            this.K17.Size = new System.Drawing.Size(50, 50);
            this.K17.TabIndex = 218;
            this.K17.Text = "K17";
            this.K17.UseVisualStyleBackColor = false;
            this.K17.Click += new System.EventHandler(this.K17_Click);
            // 
            // K16
            // 
            this.K16.BackColor = System.Drawing.Color.SlateBlue;
            this.K16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K16.ForeColor = System.Drawing.Color.White;
            this.K16.Location = new System.Drawing.Point(924, 605);
            this.K16.Name = "K16";
            this.K16.Size = new System.Drawing.Size(50, 50);
            this.K16.TabIndex = 217;
            this.K16.Text = "K16";
            this.K16.UseVisualStyleBackColor = false;
            this.K16.Click += new System.EventHandler(this.K16_Click);
            // 
            // K15
            // 
            this.K15.BackColor = System.Drawing.Color.SlateBlue;
            this.K15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K15.ForeColor = System.Drawing.Color.White;
            this.K15.Location = new System.Drawing.Point(868, 605);
            this.K15.Name = "K15";
            this.K15.Size = new System.Drawing.Size(50, 50);
            this.K15.TabIndex = 216;
            this.K15.Text = "K15";
            this.K15.UseVisualStyleBackColor = false;
            this.K15.Click += new System.EventHandler(this.K15_Click);
            // 
            // K14
            // 
            this.K14.BackColor = System.Drawing.Color.SlateBlue;
            this.K14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K14.ForeColor = System.Drawing.Color.White;
            this.K14.Location = new System.Drawing.Point(812, 605);
            this.K14.Name = "K14";
            this.K14.Size = new System.Drawing.Size(50, 50);
            this.K14.TabIndex = 215;
            this.K14.Text = "K14";
            this.K14.UseVisualStyleBackColor = false;
            this.K14.Click += new System.EventHandler(this.K14_Click);
            // 
            // K13
            // 
            this.K13.BackColor = System.Drawing.Color.SlateBlue;
            this.K13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K13.ForeColor = System.Drawing.Color.White;
            this.K13.Location = new System.Drawing.Point(756, 605);
            this.K13.Name = "K13";
            this.K13.Size = new System.Drawing.Size(50, 50);
            this.K13.TabIndex = 214;
            this.K13.Text = "K13";
            this.K13.UseVisualStyleBackColor = false;
            this.K13.Click += new System.EventHandler(this.K13_Click);
            // 
            // K12
            // 
            this.K12.BackColor = System.Drawing.Color.SlateBlue;
            this.K12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K12.ForeColor = System.Drawing.Color.White;
            this.K12.Location = new System.Drawing.Point(700, 605);
            this.K12.Name = "K12";
            this.K12.Size = new System.Drawing.Size(50, 50);
            this.K12.TabIndex = 213;
            this.K12.Text = "K12";
            this.K12.UseVisualStyleBackColor = false;
            this.K12.Click += new System.EventHandler(this.K12_Click);
            // 
            // K11
            // 
            this.K11.BackColor = System.Drawing.Color.SlateBlue;
            this.K11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K11.ForeColor = System.Drawing.Color.White;
            this.K11.Location = new System.Drawing.Point(644, 605);
            this.K11.Name = "K11";
            this.K11.Size = new System.Drawing.Size(50, 50);
            this.K11.TabIndex = 212;
            this.K11.Text = "K11";
            this.K11.UseVisualStyleBackColor = false;
            this.K11.Click += new System.EventHandler(this.K11_Click);
            // 
            // K10
            // 
            this.K10.BackColor = System.Drawing.Color.SlateBlue;
            this.K10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K10.ForeColor = System.Drawing.Color.White;
            this.K10.Location = new System.Drawing.Point(588, 605);
            this.K10.Name = "K10";
            this.K10.Size = new System.Drawing.Size(50, 50);
            this.K10.TabIndex = 211;
            this.K10.Text = "K10";
            this.K10.UseVisualStyleBackColor = false;
            this.K10.Click += new System.EventHandler(this.K10_Click);
            // 
            // K9
            // 
            this.K9.BackColor = System.Drawing.Color.SlateBlue;
            this.K9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K9.ForeColor = System.Drawing.Color.White;
            this.K9.Location = new System.Drawing.Point(532, 605);
            this.K9.Name = "K9";
            this.K9.Size = new System.Drawing.Size(50, 50);
            this.K9.TabIndex = 210;
            this.K9.Text = "K9";
            this.K9.UseVisualStyleBackColor = false;
            this.K9.Click += new System.EventHandler(this.K9_Click);
            // 
            // K8
            // 
            this.K8.BackColor = System.Drawing.Color.SlateBlue;
            this.K8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K8.ForeColor = System.Drawing.Color.White;
            this.K8.Location = new System.Drawing.Point(476, 605);
            this.K8.Name = "K8";
            this.K8.Size = new System.Drawing.Size(50, 50);
            this.K8.TabIndex = 209;
            this.K8.Text = "K8";
            this.K8.UseVisualStyleBackColor = false;
            this.K8.Click += new System.EventHandler(this.K8_Click);
            // 
            // K7
            // 
            this.K7.BackColor = System.Drawing.Color.SlateBlue;
            this.K7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K7.ForeColor = System.Drawing.Color.White;
            this.K7.Location = new System.Drawing.Point(420, 605);
            this.K7.Name = "K7";
            this.K7.Size = new System.Drawing.Size(50, 50);
            this.K7.TabIndex = 208;
            this.K7.Text = "K7";
            this.K7.UseVisualStyleBackColor = false;
            this.K7.Click += new System.EventHandler(this.K7_Click);
            // 
            // K6
            // 
            this.K6.BackColor = System.Drawing.Color.SlateBlue;
            this.K6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K6.ForeColor = System.Drawing.Color.White;
            this.K6.Location = new System.Drawing.Point(364, 605);
            this.K6.Name = "K6";
            this.K6.Size = new System.Drawing.Size(50, 50);
            this.K6.TabIndex = 207;
            this.K6.Text = "K6";
            this.K6.UseVisualStyleBackColor = false;
            this.K6.Click += new System.EventHandler(this.K6_Click);
            // 
            // K5
            // 
            this.K5.BackColor = System.Drawing.Color.SlateBlue;
            this.K5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K5.ForeColor = System.Drawing.Color.White;
            this.K5.Location = new System.Drawing.Point(308, 605);
            this.K5.Name = "K5";
            this.K5.Size = new System.Drawing.Size(50, 50);
            this.K5.TabIndex = 206;
            this.K5.Text = "K5";
            this.K5.UseVisualStyleBackColor = false;
            this.K5.Click += new System.EventHandler(this.K5_Click);
            // 
            // K4
            // 
            this.K4.BackColor = System.Drawing.Color.SlateBlue;
            this.K4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K4.ForeColor = System.Drawing.Color.White;
            this.K4.Location = new System.Drawing.Point(252, 605);
            this.K4.Name = "K4";
            this.K4.Size = new System.Drawing.Size(50, 50);
            this.K4.TabIndex = 205;
            this.K4.Text = "K4";
            this.K4.UseVisualStyleBackColor = false;
            this.K4.Click += new System.EventHandler(this.K4_Click);
            // 
            // K3
            // 
            this.K3.BackColor = System.Drawing.Color.SlateBlue;
            this.K3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K3.ForeColor = System.Drawing.Color.White;
            this.K3.Location = new System.Drawing.Point(196, 605);
            this.K3.Name = "K3";
            this.K3.Size = new System.Drawing.Size(50, 50);
            this.K3.TabIndex = 204;
            this.K3.Text = "K3";
            this.K3.UseVisualStyleBackColor = false;
            this.K3.Click += new System.EventHandler(this.K3_Click);
            // 
            // K2
            // 
            this.K2.BackColor = System.Drawing.Color.SlateBlue;
            this.K2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K2.ForeColor = System.Drawing.Color.White;
            this.K2.Location = new System.Drawing.Point(140, 605);
            this.K2.Name = "K2";
            this.K2.Size = new System.Drawing.Size(50, 50);
            this.K2.TabIndex = 203;
            this.K2.Text = "K2";
            this.K2.UseVisualStyleBackColor = false;
            this.K2.Click += new System.EventHandler(this.K2_Click);
            // 
            // K1
            // 
            this.K1.BackColor = System.Drawing.Color.SlateBlue;
            this.K1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.K1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.K1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K1.ForeColor = System.Drawing.Color.White;
            this.K1.Location = new System.Drawing.Point(84, 605);
            this.K1.Name = "K1";
            this.K1.Size = new System.Drawing.Size(50, 50);
            this.K1.TabIndex = 202;
            this.K1.Text = "K1";
            this.K1.UseVisualStyleBackColor = false;
            this.K1.Click += new System.EventHandler(this.K1_Click);
            // 
            // L20
            // 
            this.L20.BackColor = System.Drawing.Color.SlateBlue;
            this.L20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L20.ForeColor = System.Drawing.Color.White;
            this.L20.Location = new System.Drawing.Point(1148, 661);
            this.L20.Name = "L20";
            this.L20.Size = new System.Drawing.Size(50, 50);
            this.L20.TabIndex = 241;
            this.L20.Text = "L20";
            this.L20.UseVisualStyleBackColor = false;
            this.L20.Click += new System.EventHandler(this.L20_Click);
            // 
            // L19
            // 
            this.L19.BackColor = System.Drawing.Color.SlateBlue;
            this.L19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L19.ForeColor = System.Drawing.Color.White;
            this.L19.Location = new System.Drawing.Point(1092, 661);
            this.L19.Name = "L19";
            this.L19.Size = new System.Drawing.Size(50, 50);
            this.L19.TabIndex = 240;
            this.L19.Text = "L19";
            this.L19.UseVisualStyleBackColor = false;
            this.L19.Click += new System.EventHandler(this.L19_Click);
            // 
            // L18
            // 
            this.L18.BackColor = System.Drawing.Color.SlateBlue;
            this.L18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L18.ForeColor = System.Drawing.Color.White;
            this.L18.Location = new System.Drawing.Point(1036, 661);
            this.L18.Name = "L18";
            this.L18.Size = new System.Drawing.Size(50, 50);
            this.L18.TabIndex = 239;
            this.L18.Text = "L18";
            this.L18.UseVisualStyleBackColor = false;
            this.L18.Click += new System.EventHandler(this.L18_Click);
            // 
            // L17
            // 
            this.L17.BackColor = System.Drawing.Color.SlateBlue;
            this.L17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L17.ForeColor = System.Drawing.Color.White;
            this.L17.Location = new System.Drawing.Point(980, 661);
            this.L17.Name = "L17";
            this.L17.Size = new System.Drawing.Size(50, 50);
            this.L17.TabIndex = 238;
            this.L17.Text = "L17";
            this.L17.UseVisualStyleBackColor = false;
            this.L17.Click += new System.EventHandler(this.L17_Click);
            // 
            // L16
            // 
            this.L16.BackColor = System.Drawing.Color.SlateBlue;
            this.L16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L16.ForeColor = System.Drawing.Color.White;
            this.L16.Location = new System.Drawing.Point(924, 661);
            this.L16.Name = "L16";
            this.L16.Size = new System.Drawing.Size(50, 50);
            this.L16.TabIndex = 237;
            this.L16.Text = "L16";
            this.L16.UseVisualStyleBackColor = false;
            this.L16.Click += new System.EventHandler(this.L16_Click);
            // 
            // L15
            // 
            this.L15.BackColor = System.Drawing.Color.SlateBlue;
            this.L15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L15.ForeColor = System.Drawing.Color.White;
            this.L15.Location = new System.Drawing.Point(868, 661);
            this.L15.Name = "L15";
            this.L15.Size = new System.Drawing.Size(50, 50);
            this.L15.TabIndex = 236;
            this.L15.Text = "L15";
            this.L15.UseVisualStyleBackColor = false;
            this.L15.Click += new System.EventHandler(this.L15_Click);
            // 
            // L14
            // 
            this.L14.BackColor = System.Drawing.Color.SlateBlue;
            this.L14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L14.ForeColor = System.Drawing.Color.White;
            this.L14.Location = new System.Drawing.Point(812, 661);
            this.L14.Name = "L14";
            this.L14.Size = new System.Drawing.Size(50, 50);
            this.L14.TabIndex = 235;
            this.L14.Text = "L14";
            this.L14.UseVisualStyleBackColor = false;
            this.L14.Click += new System.EventHandler(this.L14_Click);
            // 
            // L13
            // 
            this.L13.BackColor = System.Drawing.Color.SlateBlue;
            this.L13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L13.ForeColor = System.Drawing.Color.White;
            this.L13.Location = new System.Drawing.Point(756, 661);
            this.L13.Name = "L13";
            this.L13.Size = new System.Drawing.Size(50, 50);
            this.L13.TabIndex = 234;
            this.L13.Text = "L13";
            this.L13.UseVisualStyleBackColor = false;
            this.L13.Click += new System.EventHandler(this.L13_Click);
            // 
            // L12
            // 
            this.L12.BackColor = System.Drawing.Color.SlateBlue;
            this.L12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L12.ForeColor = System.Drawing.Color.White;
            this.L12.Location = new System.Drawing.Point(700, 661);
            this.L12.Name = "L12";
            this.L12.Size = new System.Drawing.Size(50, 50);
            this.L12.TabIndex = 233;
            this.L12.Text = "L12";
            this.L12.UseVisualStyleBackColor = false;
            this.L12.Click += new System.EventHandler(this.L12_Click);
            // 
            // L11
            // 
            this.L11.BackColor = System.Drawing.Color.SlateBlue;
            this.L11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L11.ForeColor = System.Drawing.Color.White;
            this.L11.Location = new System.Drawing.Point(644, 661);
            this.L11.Name = "L11";
            this.L11.Size = new System.Drawing.Size(50, 50);
            this.L11.TabIndex = 232;
            this.L11.Text = "L11";
            this.L11.UseVisualStyleBackColor = false;
            this.L11.Click += new System.EventHandler(this.L11_Click);
            // 
            // L10
            // 
            this.L10.BackColor = System.Drawing.Color.SlateBlue;
            this.L10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L10.ForeColor = System.Drawing.Color.White;
            this.L10.Location = new System.Drawing.Point(588, 661);
            this.L10.Name = "L10";
            this.L10.Size = new System.Drawing.Size(50, 50);
            this.L10.TabIndex = 231;
            this.L10.Text = "L10";
            this.L10.UseVisualStyleBackColor = false;
            this.L10.Click += new System.EventHandler(this.L10_Click);
            // 
            // L9
            // 
            this.L9.BackColor = System.Drawing.Color.SlateBlue;
            this.L9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L9.ForeColor = System.Drawing.Color.White;
            this.L9.Location = new System.Drawing.Point(532, 661);
            this.L9.Name = "L9";
            this.L9.Size = new System.Drawing.Size(50, 50);
            this.L9.TabIndex = 230;
            this.L9.Text = "L9";
            this.L9.UseVisualStyleBackColor = false;
            this.L9.Click += new System.EventHandler(this.L9_Click);
            // 
            // L8
            // 
            this.L8.BackColor = System.Drawing.Color.SlateBlue;
            this.L8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L8.ForeColor = System.Drawing.Color.White;
            this.L8.Location = new System.Drawing.Point(476, 661);
            this.L8.Name = "L8";
            this.L8.Size = new System.Drawing.Size(50, 50);
            this.L8.TabIndex = 229;
            this.L8.Text = "L8";
            this.L8.UseVisualStyleBackColor = false;
            this.L8.Click += new System.EventHandler(this.L8_Click);
            // 
            // L7
            // 
            this.L7.BackColor = System.Drawing.Color.SlateBlue;
            this.L7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L7.ForeColor = System.Drawing.Color.White;
            this.L7.Location = new System.Drawing.Point(420, 661);
            this.L7.Name = "L7";
            this.L7.Size = new System.Drawing.Size(50, 50);
            this.L7.TabIndex = 228;
            this.L7.Text = "L7";
            this.L7.UseVisualStyleBackColor = false;
            this.L7.Click += new System.EventHandler(this.L7_Click);
            // 
            // L6
            // 
            this.L6.BackColor = System.Drawing.Color.SlateBlue;
            this.L6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L6.ForeColor = System.Drawing.Color.White;
            this.L6.Location = new System.Drawing.Point(364, 661);
            this.L6.Name = "L6";
            this.L6.Size = new System.Drawing.Size(50, 50);
            this.L6.TabIndex = 227;
            this.L6.Text = "L6";
            this.L6.UseVisualStyleBackColor = false;
            this.L6.Click += new System.EventHandler(this.L6_Click);
            // 
            // L5
            // 
            this.L5.BackColor = System.Drawing.Color.SlateBlue;
            this.L5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L5.ForeColor = System.Drawing.Color.White;
            this.L5.Location = new System.Drawing.Point(308, 661);
            this.L5.Name = "L5";
            this.L5.Size = new System.Drawing.Size(50, 50);
            this.L5.TabIndex = 226;
            this.L5.Text = "L5";
            this.L5.UseVisualStyleBackColor = false;
            this.L5.Click += new System.EventHandler(this.L5_Click);
            // 
            // L4
            // 
            this.L4.BackColor = System.Drawing.Color.SlateBlue;
            this.L4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L4.ForeColor = System.Drawing.Color.White;
            this.L4.Location = new System.Drawing.Point(252, 661);
            this.L4.Name = "L4";
            this.L4.Size = new System.Drawing.Size(50, 50);
            this.L4.TabIndex = 225;
            this.L4.Text = "L4";
            this.L4.UseVisualStyleBackColor = false;
            this.L4.Click += new System.EventHandler(this.L4_Click);
            // 
            // L3
            // 
            this.L3.BackColor = System.Drawing.Color.SlateBlue;
            this.L3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L3.ForeColor = System.Drawing.Color.White;
            this.L3.Location = new System.Drawing.Point(196, 661);
            this.L3.Name = "L3";
            this.L3.Size = new System.Drawing.Size(50, 50);
            this.L3.TabIndex = 224;
            this.L3.Text = "L3";
            this.L3.UseVisualStyleBackColor = false;
            this.L3.Click += new System.EventHandler(this.L3_Click);
            // 
            // L2
            // 
            this.L2.BackColor = System.Drawing.Color.SlateBlue;
            this.L2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L2.ForeColor = System.Drawing.Color.White;
            this.L2.Location = new System.Drawing.Point(140, 661);
            this.L2.Name = "L2";
            this.L2.Size = new System.Drawing.Size(50, 50);
            this.L2.TabIndex = 223;
            this.L2.Text = "L2";
            this.L2.UseVisualStyleBackColor = false;
            this.L2.Click += new System.EventHandler(this.L2_Click);
            // 
            // L1
            // 
            this.L1.BackColor = System.Drawing.Color.SlateBlue;
            this.L1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.L1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.L1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L1.ForeColor = System.Drawing.Color.White;
            this.L1.Location = new System.Drawing.Point(84, 661);
            this.L1.Name = "L1";
            this.L1.Size = new System.Drawing.Size(50, 50);
            this.L1.TabIndex = 222;
            this.L1.Text = "L1";
            this.L1.UseVisualStyleBackColor = false;
            this.L1.Click += new System.EventHandler(this.L1_Click);
            // 
            // M20
            // 
            this.M20.BackColor = System.Drawing.Color.SlateBlue;
            this.M20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M20.ForeColor = System.Drawing.Color.White;
            this.M20.Location = new System.Drawing.Point(1148, 717);
            this.M20.Name = "M20";
            this.M20.Size = new System.Drawing.Size(50, 50);
            this.M20.TabIndex = 261;
            this.M20.Text = "M20";
            this.M20.UseVisualStyleBackColor = false;
            this.M20.Click += new System.EventHandler(this.M20_Click);
            // 
            // M19
            // 
            this.M19.BackColor = System.Drawing.Color.SlateBlue;
            this.M19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M19.ForeColor = System.Drawing.Color.White;
            this.M19.Location = new System.Drawing.Point(1092, 717);
            this.M19.Name = "M19";
            this.M19.Size = new System.Drawing.Size(50, 50);
            this.M19.TabIndex = 260;
            this.M19.Text = "M19";
            this.M19.UseVisualStyleBackColor = false;
            this.M19.Click += new System.EventHandler(this.M19_Click);
            // 
            // M18
            // 
            this.M18.BackColor = System.Drawing.Color.SlateBlue;
            this.M18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M18.ForeColor = System.Drawing.Color.White;
            this.M18.Location = new System.Drawing.Point(1036, 717);
            this.M18.Name = "M18";
            this.M18.Size = new System.Drawing.Size(50, 50);
            this.M18.TabIndex = 259;
            this.M18.Text = "M18";
            this.M18.UseVisualStyleBackColor = false;
            this.M18.Click += new System.EventHandler(this.M18_Click);
            // 
            // M17
            // 
            this.M17.BackColor = System.Drawing.Color.SlateBlue;
            this.M17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M17.ForeColor = System.Drawing.Color.White;
            this.M17.Location = new System.Drawing.Point(980, 717);
            this.M17.Name = "M17";
            this.M17.Size = new System.Drawing.Size(50, 50);
            this.M17.TabIndex = 258;
            this.M17.Text = "M17";
            this.M17.UseVisualStyleBackColor = false;
            this.M17.Click += new System.EventHandler(this.M17_Click);
            // 
            // M16
            // 
            this.M16.BackColor = System.Drawing.Color.SlateBlue;
            this.M16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M16.ForeColor = System.Drawing.Color.White;
            this.M16.Location = new System.Drawing.Point(924, 717);
            this.M16.Name = "M16";
            this.M16.Size = new System.Drawing.Size(50, 50);
            this.M16.TabIndex = 257;
            this.M16.Text = "M16";
            this.M16.UseVisualStyleBackColor = false;
            this.M16.Click += new System.EventHandler(this.M16_Click);
            // 
            // M15
            // 
            this.M15.BackColor = System.Drawing.Color.SlateBlue;
            this.M15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M15.ForeColor = System.Drawing.Color.White;
            this.M15.Location = new System.Drawing.Point(868, 717);
            this.M15.Name = "M15";
            this.M15.Size = new System.Drawing.Size(50, 50);
            this.M15.TabIndex = 256;
            this.M15.Text = "M15";
            this.M15.UseVisualStyleBackColor = false;
            this.M15.Click += new System.EventHandler(this.M15_Click);
            // 
            // M14
            // 
            this.M14.BackColor = System.Drawing.Color.SlateBlue;
            this.M14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M14.ForeColor = System.Drawing.Color.White;
            this.M14.Location = new System.Drawing.Point(812, 717);
            this.M14.Name = "M14";
            this.M14.Size = new System.Drawing.Size(50, 50);
            this.M14.TabIndex = 255;
            this.M14.Text = "M14";
            this.M14.UseVisualStyleBackColor = false;
            this.M14.Click += new System.EventHandler(this.M14_Click);
            // 
            // M13
            // 
            this.M13.BackColor = System.Drawing.Color.SlateBlue;
            this.M13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M13.ForeColor = System.Drawing.Color.White;
            this.M13.Location = new System.Drawing.Point(756, 717);
            this.M13.Name = "M13";
            this.M13.Size = new System.Drawing.Size(50, 50);
            this.M13.TabIndex = 254;
            this.M13.Text = "M13";
            this.M13.UseVisualStyleBackColor = false;
            this.M13.Click += new System.EventHandler(this.M13_Click);
            // 
            // M12
            // 
            this.M12.BackColor = System.Drawing.Color.SlateBlue;
            this.M12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M12.ForeColor = System.Drawing.Color.White;
            this.M12.Location = new System.Drawing.Point(700, 717);
            this.M12.Name = "M12";
            this.M12.Size = new System.Drawing.Size(50, 50);
            this.M12.TabIndex = 253;
            this.M12.Text = "M12";
            this.M12.UseVisualStyleBackColor = false;
            this.M12.Click += new System.EventHandler(this.M12_Click);
            // 
            // M11
            // 
            this.M11.BackColor = System.Drawing.Color.SlateBlue;
            this.M11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M11.ForeColor = System.Drawing.Color.White;
            this.M11.Location = new System.Drawing.Point(644, 717);
            this.M11.Name = "M11";
            this.M11.Size = new System.Drawing.Size(50, 50);
            this.M11.TabIndex = 252;
            this.M11.Text = "M11";
            this.M11.UseVisualStyleBackColor = false;
            this.M11.Click += new System.EventHandler(this.M11_Click);
            // 
            // M10
            // 
            this.M10.BackColor = System.Drawing.Color.SlateBlue;
            this.M10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M10.ForeColor = System.Drawing.Color.White;
            this.M10.Location = new System.Drawing.Point(588, 717);
            this.M10.Name = "M10";
            this.M10.Size = new System.Drawing.Size(50, 50);
            this.M10.TabIndex = 251;
            this.M10.Text = "M10";
            this.M10.UseVisualStyleBackColor = false;
            this.M10.Click += new System.EventHandler(this.M10_Click);
            // 
            // M9
            // 
            this.M9.BackColor = System.Drawing.Color.SlateBlue;
            this.M9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M9.ForeColor = System.Drawing.Color.White;
            this.M9.Location = new System.Drawing.Point(532, 717);
            this.M9.Name = "M9";
            this.M9.Size = new System.Drawing.Size(50, 50);
            this.M9.TabIndex = 250;
            this.M9.Text = "M9";
            this.M9.UseVisualStyleBackColor = false;
            this.M9.Click += new System.EventHandler(this.M9_Click);
            // 
            // M8
            // 
            this.M8.BackColor = System.Drawing.Color.SlateBlue;
            this.M8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M8.ForeColor = System.Drawing.Color.White;
            this.M8.Location = new System.Drawing.Point(476, 717);
            this.M8.Name = "M8";
            this.M8.Size = new System.Drawing.Size(50, 50);
            this.M8.TabIndex = 249;
            this.M8.Text = "M8";
            this.M8.UseVisualStyleBackColor = false;
            this.M8.Click += new System.EventHandler(this.M8_Click);
            // 
            // M7
            // 
            this.M7.BackColor = System.Drawing.Color.SlateBlue;
            this.M7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M7.ForeColor = System.Drawing.Color.White;
            this.M7.Location = new System.Drawing.Point(420, 717);
            this.M7.Name = "M7";
            this.M7.Size = new System.Drawing.Size(50, 50);
            this.M7.TabIndex = 248;
            this.M7.Text = "M7";
            this.M7.UseVisualStyleBackColor = false;
            this.M7.Click += new System.EventHandler(this.M7_Click);
            // 
            // M6
            // 
            this.M6.BackColor = System.Drawing.Color.SlateBlue;
            this.M6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M6.ForeColor = System.Drawing.Color.White;
            this.M6.Location = new System.Drawing.Point(364, 717);
            this.M6.Name = "M6";
            this.M6.Size = new System.Drawing.Size(50, 50);
            this.M6.TabIndex = 247;
            this.M6.Text = "M6";
            this.M6.UseVisualStyleBackColor = false;
            this.M6.Click += new System.EventHandler(this.M6_Click);
            // 
            // M5
            // 
            this.M5.BackColor = System.Drawing.Color.SlateBlue;
            this.M5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M5.ForeColor = System.Drawing.Color.White;
            this.M5.Location = new System.Drawing.Point(308, 717);
            this.M5.Name = "M5";
            this.M5.Size = new System.Drawing.Size(50, 50);
            this.M5.TabIndex = 246;
            this.M5.Text = "M5";
            this.M5.UseVisualStyleBackColor = false;
            this.M5.Click += new System.EventHandler(this.M5_Click);
            // 
            // M4
            // 
            this.M4.BackColor = System.Drawing.Color.SlateBlue;
            this.M4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M4.ForeColor = System.Drawing.Color.White;
            this.M4.Location = new System.Drawing.Point(252, 717);
            this.M4.Name = "M4";
            this.M4.Size = new System.Drawing.Size(50, 50);
            this.M4.TabIndex = 245;
            this.M4.Text = "M4";
            this.M4.UseVisualStyleBackColor = false;
            this.M4.Click += new System.EventHandler(this.M4_Click);
            // 
            // M3
            // 
            this.M3.BackColor = System.Drawing.Color.SlateBlue;
            this.M3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M3.ForeColor = System.Drawing.Color.White;
            this.M3.Location = new System.Drawing.Point(196, 717);
            this.M3.Name = "M3";
            this.M3.Size = new System.Drawing.Size(50, 50);
            this.M3.TabIndex = 244;
            this.M3.Text = "M3";
            this.M3.UseVisualStyleBackColor = false;
            this.M3.Click += new System.EventHandler(this.M3_Click);
            // 
            // M2
            // 
            this.M2.BackColor = System.Drawing.Color.SlateBlue;
            this.M2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M2.ForeColor = System.Drawing.Color.White;
            this.M2.Location = new System.Drawing.Point(140, 717);
            this.M2.Name = "M2";
            this.M2.Size = new System.Drawing.Size(50, 50);
            this.M2.TabIndex = 243;
            this.M2.Text = "M2";
            this.M2.UseVisualStyleBackColor = false;
            this.M2.Click += new System.EventHandler(this.M2_Click);
            // 
            // M1
            // 
            this.M1.BackColor = System.Drawing.Color.SlateBlue;
            this.M1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.M1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.M1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M1.ForeColor = System.Drawing.Color.White;
            this.M1.Location = new System.Drawing.Point(84, 717);
            this.M1.Name = "M1";
            this.M1.Size = new System.Drawing.Size(50, 50);
            this.M1.TabIndex = 242;
            this.M1.Text = "M1";
            this.M1.UseVisualStyleBackColor = false;
            this.M1.Click += new System.EventHandler(this.M1_Click);
            // 
            // N20
            // 
            this.N20.BackColor = System.Drawing.Color.SlateBlue;
            this.N20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N20.ForeColor = System.Drawing.Color.White;
            this.N20.Location = new System.Drawing.Point(1148, 773);
            this.N20.Name = "N20";
            this.N20.Size = new System.Drawing.Size(50, 50);
            this.N20.TabIndex = 281;
            this.N20.Text = "N20";
            this.N20.UseVisualStyleBackColor = false;
            this.N20.Click += new System.EventHandler(this.N20_Click);
            // 
            // N19
            // 
            this.N19.BackColor = System.Drawing.Color.SlateBlue;
            this.N19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N19.ForeColor = System.Drawing.Color.White;
            this.N19.Location = new System.Drawing.Point(1092, 773);
            this.N19.Name = "N19";
            this.N19.Size = new System.Drawing.Size(50, 50);
            this.N19.TabIndex = 280;
            this.N19.Text = "N19";
            this.N19.UseVisualStyleBackColor = false;
            this.N19.Click += new System.EventHandler(this.N19_Click);
            // 
            // N18
            // 
            this.N18.BackColor = System.Drawing.Color.SlateBlue;
            this.N18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N18.ForeColor = System.Drawing.Color.White;
            this.N18.Location = new System.Drawing.Point(1036, 773);
            this.N18.Name = "N18";
            this.N18.Size = new System.Drawing.Size(50, 50);
            this.N18.TabIndex = 279;
            this.N18.Text = "N18";
            this.N18.UseVisualStyleBackColor = false;
            this.N18.Click += new System.EventHandler(this.N18_Click);
            // 
            // N17
            // 
            this.N17.BackColor = System.Drawing.Color.SlateBlue;
            this.N17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N17.ForeColor = System.Drawing.Color.White;
            this.N17.Location = new System.Drawing.Point(980, 773);
            this.N17.Name = "N17";
            this.N17.Size = new System.Drawing.Size(50, 50);
            this.N17.TabIndex = 278;
            this.N17.Text = "N17";
            this.N17.UseVisualStyleBackColor = false;
            this.N17.Click += new System.EventHandler(this.N17_Click);
            // 
            // N16
            // 
            this.N16.BackColor = System.Drawing.Color.SlateBlue;
            this.N16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N16.ForeColor = System.Drawing.Color.White;
            this.N16.Location = new System.Drawing.Point(924, 773);
            this.N16.Name = "N16";
            this.N16.Size = new System.Drawing.Size(50, 50);
            this.N16.TabIndex = 277;
            this.N16.Text = "N16";
            this.N16.UseVisualStyleBackColor = false;
            this.N16.Click += new System.EventHandler(this.N16_Click);
            // 
            // N15
            // 
            this.N15.BackColor = System.Drawing.Color.SlateBlue;
            this.N15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N15.ForeColor = System.Drawing.Color.White;
            this.N15.Location = new System.Drawing.Point(868, 773);
            this.N15.Name = "N15";
            this.N15.Size = new System.Drawing.Size(50, 50);
            this.N15.TabIndex = 276;
            this.N15.Text = "N15";
            this.N15.UseVisualStyleBackColor = false;
            this.N15.Click += new System.EventHandler(this.N15_Click);
            // 
            // N14
            // 
            this.N14.BackColor = System.Drawing.Color.SlateBlue;
            this.N14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N14.ForeColor = System.Drawing.Color.White;
            this.N14.Location = new System.Drawing.Point(812, 773);
            this.N14.Name = "N14";
            this.N14.Size = new System.Drawing.Size(50, 50);
            this.N14.TabIndex = 275;
            this.N14.Text = "N14";
            this.N14.UseVisualStyleBackColor = false;
            this.N14.Click += new System.EventHandler(this.N14_Click);
            // 
            // N13
            // 
            this.N13.BackColor = System.Drawing.Color.SlateBlue;
            this.N13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N13.ForeColor = System.Drawing.Color.White;
            this.N13.Location = new System.Drawing.Point(756, 773);
            this.N13.Name = "N13";
            this.N13.Size = new System.Drawing.Size(50, 50);
            this.N13.TabIndex = 274;
            this.N13.Text = "N13";
            this.N13.UseVisualStyleBackColor = false;
            this.N13.Click += new System.EventHandler(this.N13_Click);
            // 
            // N12
            // 
            this.N12.BackColor = System.Drawing.Color.SlateBlue;
            this.N12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N12.ForeColor = System.Drawing.Color.White;
            this.N12.Location = new System.Drawing.Point(700, 773);
            this.N12.Name = "N12";
            this.N12.Size = new System.Drawing.Size(50, 50);
            this.N12.TabIndex = 273;
            this.N12.Text = "N12";
            this.N12.UseVisualStyleBackColor = false;
            this.N12.Click += new System.EventHandler(this.N12_Click);
            // 
            // N11
            // 
            this.N11.BackColor = System.Drawing.Color.SlateBlue;
            this.N11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N11.ForeColor = System.Drawing.Color.White;
            this.N11.Location = new System.Drawing.Point(644, 773);
            this.N11.Name = "N11";
            this.N11.Size = new System.Drawing.Size(50, 50);
            this.N11.TabIndex = 272;
            this.N11.Text = "N11";
            this.N11.UseVisualStyleBackColor = false;
            this.N11.Click += new System.EventHandler(this.N11_Click);
            // 
            // N10
            // 
            this.N10.BackColor = System.Drawing.Color.SlateBlue;
            this.N10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N10.ForeColor = System.Drawing.Color.White;
            this.N10.Location = new System.Drawing.Point(588, 773);
            this.N10.Name = "N10";
            this.N10.Size = new System.Drawing.Size(50, 50);
            this.N10.TabIndex = 271;
            this.N10.Text = "N10";
            this.N10.UseVisualStyleBackColor = false;
            this.N10.Click += new System.EventHandler(this.N10_Click);
            // 
            // N9
            // 
            this.N9.BackColor = System.Drawing.Color.SlateBlue;
            this.N9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N9.ForeColor = System.Drawing.Color.White;
            this.N9.Location = new System.Drawing.Point(532, 773);
            this.N9.Name = "N9";
            this.N9.Size = new System.Drawing.Size(50, 50);
            this.N9.TabIndex = 270;
            this.N9.Text = "N9";
            this.N9.UseVisualStyleBackColor = false;
            this.N9.Click += new System.EventHandler(this.N9_Click);
            // 
            // N8
            // 
            this.N8.BackColor = System.Drawing.Color.SlateBlue;
            this.N8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N8.ForeColor = System.Drawing.Color.White;
            this.N8.Location = new System.Drawing.Point(476, 773);
            this.N8.Name = "N8";
            this.N8.Size = new System.Drawing.Size(50, 50);
            this.N8.TabIndex = 269;
            this.N8.Text = "N8";
            this.N8.UseVisualStyleBackColor = false;
            this.N8.Click += new System.EventHandler(this.N8_Click);
            // 
            // N7
            // 
            this.N7.BackColor = System.Drawing.Color.SlateBlue;
            this.N7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N7.ForeColor = System.Drawing.Color.White;
            this.N7.Location = new System.Drawing.Point(420, 773);
            this.N7.Name = "N7";
            this.N7.Size = new System.Drawing.Size(50, 50);
            this.N7.TabIndex = 268;
            this.N7.Text = "N7";
            this.N7.UseVisualStyleBackColor = false;
            this.N7.Click += new System.EventHandler(this.N7_Click);
            // 
            // N6
            // 
            this.N6.BackColor = System.Drawing.Color.SlateBlue;
            this.N6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N6.ForeColor = System.Drawing.Color.White;
            this.N6.Location = new System.Drawing.Point(364, 773);
            this.N6.Name = "N6";
            this.N6.Size = new System.Drawing.Size(50, 50);
            this.N6.TabIndex = 267;
            this.N6.Text = "N6";
            this.N6.UseVisualStyleBackColor = false;
            this.N6.Click += new System.EventHandler(this.N6_Click);
            // 
            // N5
            // 
            this.N5.BackColor = System.Drawing.Color.SlateBlue;
            this.N5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N5.ForeColor = System.Drawing.Color.White;
            this.N5.Location = new System.Drawing.Point(308, 773);
            this.N5.Name = "N5";
            this.N5.Size = new System.Drawing.Size(50, 50);
            this.N5.TabIndex = 266;
            this.N5.Text = "N5";
            this.N5.UseVisualStyleBackColor = false;
            this.N5.Click += new System.EventHandler(this.N5_Click);
            // 
            // N4
            // 
            this.N4.BackColor = System.Drawing.Color.SlateBlue;
            this.N4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N4.ForeColor = System.Drawing.Color.White;
            this.N4.Location = new System.Drawing.Point(252, 773);
            this.N4.Name = "N4";
            this.N4.Size = new System.Drawing.Size(50, 50);
            this.N4.TabIndex = 265;
            this.N4.Text = "N4";
            this.N4.UseVisualStyleBackColor = false;
            this.N4.Click += new System.EventHandler(this.N4_Click);
            // 
            // N3
            // 
            this.N3.BackColor = System.Drawing.Color.SlateBlue;
            this.N3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N3.ForeColor = System.Drawing.Color.White;
            this.N3.Location = new System.Drawing.Point(196, 773);
            this.N3.Name = "N3";
            this.N3.Size = new System.Drawing.Size(50, 50);
            this.N3.TabIndex = 264;
            this.N3.Text = "N3";
            this.N3.UseVisualStyleBackColor = false;
            this.N3.Click += new System.EventHandler(this.N3_Click);
            // 
            // N2
            // 
            this.N2.BackColor = System.Drawing.Color.SlateBlue;
            this.N2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N2.ForeColor = System.Drawing.Color.White;
            this.N2.Location = new System.Drawing.Point(140, 773);
            this.N2.Name = "N2";
            this.N2.Size = new System.Drawing.Size(50, 50);
            this.N2.TabIndex = 263;
            this.N2.Text = "N2";
            this.N2.UseVisualStyleBackColor = false;
            this.N2.Click += new System.EventHandler(this.N2_Click);
            // 
            // N1
            // 
            this.N1.BackColor = System.Drawing.Color.SlateBlue;
            this.N1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.N1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.N1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N1.ForeColor = System.Drawing.Color.White;
            this.N1.Location = new System.Drawing.Point(84, 773);
            this.N1.Name = "N1";
            this.N1.Size = new System.Drawing.Size(50, 50);
            this.N1.TabIndex = 262;
            this.N1.Text = "N1";
            this.N1.UseVisualStyleBackColor = false;
            this.N1.Click += new System.EventHandler(this.N1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.button284);
            this.panel2.Controls.Add(this.button283);
            this.panel2.Controls.Add(this.button282);
            this.panel2.Controls.Add(this.button281);
            this.panel2.Location = new System.Drawing.Point(84, 829);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(498, 160);
            this.panel2.TabIndex = 282;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(296, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 24);
            this.label5.TabIndex = 270;
            this.label5.Text = "Vùng trung tâm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(68, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 24);
            this.label4.TabIndex = 269;
            this.label4.Text = "Ghế thường";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(296, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 24);
            this.label3.TabIndex = 268;
            this.label3.Text = "Ghế bạn chọn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(68, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 24);
            this.label2.TabIndex = 267;
            this.label2.Text = "Đã đặt";
            // 
            // button284
            // 
            this.button284.BackColor = System.Drawing.Color.DimGray;
            this.button284.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button284.Enabled = false;
            this.button284.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button284.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button284.ForeColor = System.Drawing.Color.White;
            this.button284.Location = new System.Drawing.Point(240, 97);
            this.button284.Name = "button284";
            this.button284.Size = new System.Drawing.Size(50, 50);
            this.button284.TabIndex = 266;
            this.button284.UseVisualStyleBackColor = false;
            // 
            // button283
            // 
            this.button283.BackColor = System.Drawing.Color.SlateBlue;
            this.button283.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button283.Enabled = false;
            this.button283.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button283.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button283.ForeColor = System.Drawing.Color.White;
            this.button283.Location = new System.Drawing.Point(12, 97);
            this.button283.Name = "button283";
            this.button283.Size = new System.Drawing.Size(50, 50);
            this.button283.TabIndex = 265;
            this.button283.UseVisualStyleBackColor = false;
            // 
            // button282
            // 
            this.button282.BackColor = System.Drawing.Color.DeepPink;
            this.button282.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button282.Enabled = false;
            this.button282.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button282.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button282.ForeColor = System.Drawing.Color.White;
            this.button282.Location = new System.Drawing.Point(240, 12);
            this.button282.Name = "button282";
            this.button282.Size = new System.Drawing.Size(50, 50);
            this.button282.TabIndex = 264;
            this.button282.UseVisualStyleBackColor = false;
            // 
            // button281
            // 
            this.button281.BackColor = System.Drawing.Color.Black;
            this.button281.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button281.Enabled = false;
            this.button281.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button281.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button281.ForeColor = System.Drawing.Color.White;
            this.button281.Location = new System.Drawing.Point(12, 12);
            this.button281.Name = "button281";
            this.button281.Size = new System.Drawing.Size(50, 50);
            this.button281.TabIndex = 263;
            this.button281.UseVisualStyleBackColor = false;
            // 
            // labelName
            // 
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.Black;
            this.labelName.Location = new System.Drawing.Point(8, 10);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(586, 24);
            this.labelName.TabIndex = 271;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gray;
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.buttonPayment);
            this.panel4.Controls.Add(this.labelGiaGhe);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.labelSeat);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.labelTime);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.labelName);
            this.panel4.Location = new System.Drawing.Point(589, 829);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(609, 160);
            this.panel4.TabIndex = 284;
            // 
            // buttonPayment
            // 
            this.buttonPayment.BackColor = System.Drawing.Color.DeepPink;
            this.buttonPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPayment.ForeColor = System.Drawing.Color.White;
            this.buttonPayment.Location = new System.Drawing.Point(469, 116);
            this.buttonPayment.Name = "buttonPayment";
            this.buttonPayment.Size = new System.Drawing.Size(137, 38);
            this.buttonPayment.TabIndex = 280;
            this.buttonPayment.Text = "Mua vé";
            this.buttonPayment.UseVisualStyleBackColor = false;
            this.buttonPayment.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelGiaGhe
            // 
            this.labelGiaGhe.Enabled = false;
            this.labelGiaGhe.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGiaGhe.ForeColor = System.Drawing.Color.White;
            this.labelGiaGhe.Location = new System.Drawing.Point(107, 123);
            this.labelGiaGhe.Name = "labelGiaGhe";
            this.labelGiaGhe.Size = new System.Drawing.Size(222, 24);
            this.labelGiaGhe.TabIndex = 279;
            this.labelGiaGhe.Text = "0đ";
            this.labelGiaGhe.Click += new System.EventHandler(this.labelMoney_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Enabled = false;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(8, 123);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 24);
            this.label10.TabIndex = 278;
            this.label10.Text = "Tạm tính:";
            // 
            // labelSeat
            // 
            this.labelSeat.Enabled = false;
            this.labelSeat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeat.ForeColor = System.Drawing.Color.White;
            this.labelSeat.Location = new System.Drawing.Point(107, 62);
            this.labelSeat.Name = "labelSeat";
            this.labelSeat.Size = new System.Drawing.Size(487, 54);
            this.labelSeat.TabIndex = 277;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Enabled = false;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(8, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 24);
            this.label6.TabIndex = 276;
            this.label6.Text = "Chỗ ngồi:";
            // 
            // labelTime
            // 
            this.labelTime.Enabled = false;
            this.labelTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.ForeColor = System.Drawing.Color.White;
            this.labelTime.Location = new System.Drawing.Point(107, 38);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(65, 24);
            this.labelTime.TabIndex = 273;
            // 
            // label7
            // 
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(8, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 24);
            this.label7.TabIndex = 272;
            this.label7.Text = "Suất chiếu:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.BackgroundImage = global::Cinema.Properties.Resources.vientrang;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Controls.Add(this.F6);
            this.panel3.Controls.Add(this.F7);
            this.panel3.Controls.Add(this.I15);
            this.panel3.Controls.Add(this.I14);
            this.panel3.Controls.Add(this.F8);
            this.panel3.Controls.Add(this.I13);
            this.panel3.Controls.Add(this.I12);
            this.panel3.Controls.Add(this.F9);
            this.panel3.Controls.Add(this.I11);
            this.panel3.Controls.Add(this.I10);
            this.panel3.Controls.Add(this.F10);
            this.panel3.Controls.Add(this.I9);
            this.panel3.Controls.Add(this.I8);
            this.panel3.Controls.Add(this.F11);
            this.panel3.Controls.Add(this.I7);
            this.panel3.Controls.Add(this.I6);
            this.panel3.Controls.Add(this.F12);
            this.panel3.Controls.Add(this.H15);
            this.panel3.Controls.Add(this.H14);
            this.panel3.Controls.Add(this.F13);
            this.panel3.Controls.Add(this.H13);
            this.panel3.Controls.Add(this.H12);
            this.panel3.Controls.Add(this.F14);
            this.panel3.Controls.Add(this.H11);
            this.panel3.Controls.Add(this.H10);
            this.panel3.Controls.Add(this.F15);
            this.panel3.Controls.Add(this.H9);
            this.panel3.Controls.Add(this.H8);
            this.panel3.Controls.Add(this.G6);
            this.panel3.Controls.Add(this.H7);
            this.panel3.Controls.Add(this.H6);
            this.panel3.Controls.Add(this.G7);
            this.panel3.Controls.Add(this.G15);
            this.panel3.Controls.Add(this.G14);
            this.panel3.Controls.Add(this.G8);
            this.panel3.Controls.Add(this.G13);
            this.panel3.Controls.Add(this.G12);
            this.panel3.Controls.Add(this.G9);
            this.panel3.Controls.Add(this.G11);
            this.panel3.Controls.Add(this.G10);
            this.panel3.Location = new System.Drawing.Point(360, 321);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(562, 226);
            this.panel3.TabIndex = 283;
            // 
            // F6
            // 
            this.F6.BackColor = System.Drawing.Color.SlateBlue;
            this.F6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F6.ForeColor = System.Drawing.Color.White;
            this.F6.Location = new System.Drawing.Point(4, 4);
            this.F6.Name = "F6";
            this.F6.Size = new System.Drawing.Size(50, 50);
            this.F6.TabIndex = 107;
            this.F6.Text = "F6";
            this.F6.UseVisualStyleBackColor = false;
            this.F6.Click += new System.EventHandler(this.F6_Click);
            // 
            // F7
            // 
            this.F7.BackColor = System.Drawing.Color.SlateBlue;
            this.F7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F7.ForeColor = System.Drawing.Color.White;
            this.F7.Location = new System.Drawing.Point(60, 4);
            this.F7.Name = "F7";
            this.F7.Size = new System.Drawing.Size(50, 50);
            this.F7.TabIndex = 108;
            this.F7.Text = "F7";
            this.F7.UseVisualStyleBackColor = false;
            this.F7.Click += new System.EventHandler(this.F7_Click);
            // 
            // I15
            // 
            this.I15.BackColor = System.Drawing.Color.SlateBlue;
            this.I15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I15.ForeColor = System.Drawing.Color.White;
            this.I15.Location = new System.Drawing.Point(508, 172);
            this.I15.Name = "I15";
            this.I15.Size = new System.Drawing.Size(50, 50);
            this.I15.TabIndex = 176;
            this.I15.Text = "I15";
            this.I15.UseVisualStyleBackColor = false;
            this.I15.Click += new System.EventHandler(this.I15_Click);
            // 
            // I14
            // 
            this.I14.BackColor = System.Drawing.Color.SlateBlue;
            this.I14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I14.ForeColor = System.Drawing.Color.White;
            this.I14.Location = new System.Drawing.Point(452, 172);
            this.I14.Name = "I14";
            this.I14.Size = new System.Drawing.Size(50, 50);
            this.I14.TabIndex = 175;
            this.I14.Text = "I14";
            this.I14.UseVisualStyleBackColor = false;
            this.I14.Click += new System.EventHandler(this.I14_Click);
            // 
            // F8
            // 
            this.F8.BackColor = System.Drawing.Color.SlateBlue;
            this.F8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F8.ForeColor = System.Drawing.Color.White;
            this.F8.Location = new System.Drawing.Point(116, 4);
            this.F8.Name = "F8";
            this.F8.Size = new System.Drawing.Size(50, 50);
            this.F8.TabIndex = 109;
            this.F8.Text = "F8";
            this.F8.UseVisualStyleBackColor = false;
            this.F8.Click += new System.EventHandler(this.F8_Click);
            // 
            // I13
            // 
            this.I13.BackColor = System.Drawing.Color.SlateBlue;
            this.I13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I13.ForeColor = System.Drawing.Color.White;
            this.I13.Location = new System.Drawing.Point(396, 172);
            this.I13.Name = "I13";
            this.I13.Size = new System.Drawing.Size(50, 50);
            this.I13.TabIndex = 174;
            this.I13.Text = "I13";
            this.I13.UseVisualStyleBackColor = false;
            this.I13.Click += new System.EventHandler(this.I13_Click);
            // 
            // I12
            // 
            this.I12.BackColor = System.Drawing.Color.SlateBlue;
            this.I12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I12.ForeColor = System.Drawing.Color.White;
            this.I12.Location = new System.Drawing.Point(340, 172);
            this.I12.Name = "I12";
            this.I12.Size = new System.Drawing.Size(50, 50);
            this.I12.TabIndex = 173;
            this.I12.Text = "I12";
            this.I12.UseVisualStyleBackColor = false;
            this.I12.Click += new System.EventHandler(this.I12_Click);
            // 
            // F9
            // 
            this.F9.BackColor = System.Drawing.Color.SlateBlue;
            this.F9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F9.ForeColor = System.Drawing.Color.White;
            this.F9.Location = new System.Drawing.Point(172, 4);
            this.F9.Name = "F9";
            this.F9.Size = new System.Drawing.Size(50, 50);
            this.F9.TabIndex = 110;
            this.F9.Text = "F9";
            this.F9.UseVisualStyleBackColor = false;
            this.F9.Click += new System.EventHandler(this.F9_Click);
            // 
            // I11
            // 
            this.I11.BackColor = System.Drawing.Color.SlateBlue;
            this.I11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I11.ForeColor = System.Drawing.Color.White;
            this.I11.Location = new System.Drawing.Point(284, 172);
            this.I11.Name = "I11";
            this.I11.Size = new System.Drawing.Size(50, 50);
            this.I11.TabIndex = 172;
            this.I11.Text = "I11";
            this.I11.UseVisualStyleBackColor = false;
            this.I11.Click += new System.EventHandler(this.I11_Click);
            // 
            // I10
            // 
            this.I10.BackColor = System.Drawing.Color.SlateBlue;
            this.I10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I10.ForeColor = System.Drawing.Color.White;
            this.I10.Location = new System.Drawing.Point(228, 172);
            this.I10.Name = "I10";
            this.I10.Size = new System.Drawing.Size(50, 50);
            this.I10.TabIndex = 171;
            this.I10.Text = "I10";
            this.I10.UseVisualStyleBackColor = false;
            this.I10.Click += new System.EventHandler(this.I10_Click);
            // 
            // F10
            // 
            this.F10.BackColor = System.Drawing.Color.SlateBlue;
            this.F10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F10.ForeColor = System.Drawing.Color.White;
            this.F10.Location = new System.Drawing.Point(228, 4);
            this.F10.Name = "F10";
            this.F10.Size = new System.Drawing.Size(50, 50);
            this.F10.TabIndex = 111;
            this.F10.Text = "F10";
            this.F10.UseVisualStyleBackColor = false;
            this.F10.Click += new System.EventHandler(this.F10_Click);
            // 
            // I9
            // 
            this.I9.BackColor = System.Drawing.Color.SlateBlue;
            this.I9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I9.ForeColor = System.Drawing.Color.White;
            this.I9.Location = new System.Drawing.Point(172, 172);
            this.I9.Name = "I9";
            this.I9.Size = new System.Drawing.Size(50, 50);
            this.I9.TabIndex = 170;
            this.I9.Text = "I9";
            this.I9.UseVisualStyleBackColor = false;
            this.I9.Click += new System.EventHandler(this.I9_Click);
            // 
            // I8
            // 
            this.I8.BackColor = System.Drawing.Color.SlateBlue;
            this.I8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I8.ForeColor = System.Drawing.Color.White;
            this.I8.Location = new System.Drawing.Point(116, 172);
            this.I8.Name = "I8";
            this.I8.Size = new System.Drawing.Size(50, 50);
            this.I8.TabIndex = 169;
            this.I8.Text = "I8";
            this.I8.UseVisualStyleBackColor = false;
            this.I8.Click += new System.EventHandler(this.I8_Click);
            // 
            // F11
            // 
            this.F11.BackColor = System.Drawing.Color.SlateBlue;
            this.F11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F11.ForeColor = System.Drawing.Color.White;
            this.F11.Location = new System.Drawing.Point(284, 4);
            this.F11.Name = "F11";
            this.F11.Size = new System.Drawing.Size(50, 50);
            this.F11.TabIndex = 112;
            this.F11.Text = "F11";
            this.F11.UseVisualStyleBackColor = false;
            this.F11.Click += new System.EventHandler(this.F11_Click);
            // 
            // I7
            // 
            this.I7.BackColor = System.Drawing.Color.SlateBlue;
            this.I7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I7.ForeColor = System.Drawing.Color.White;
            this.I7.Location = new System.Drawing.Point(60, 172);
            this.I7.Name = "I7";
            this.I7.Size = new System.Drawing.Size(50, 50);
            this.I7.TabIndex = 168;
            this.I7.Text = "I7";
            this.I7.UseVisualStyleBackColor = false;
            this.I7.Click += new System.EventHandler(this.I7_Click);
            // 
            // I6
            // 
            this.I6.BackColor = System.Drawing.Color.SlateBlue;
            this.I6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.I6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.I6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I6.ForeColor = System.Drawing.Color.White;
            this.I6.Location = new System.Drawing.Point(4, 172);
            this.I6.Name = "I6";
            this.I6.Size = new System.Drawing.Size(50, 50);
            this.I6.TabIndex = 167;
            this.I6.Text = "I6";
            this.I6.UseVisualStyleBackColor = false;
            this.I6.Click += new System.EventHandler(this.I6_Click);
            // 
            // F12
            // 
            this.F12.BackColor = System.Drawing.Color.SlateBlue;
            this.F12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F12.ForeColor = System.Drawing.Color.White;
            this.F12.Location = new System.Drawing.Point(340, 4);
            this.F12.Name = "F12";
            this.F12.Size = new System.Drawing.Size(50, 50);
            this.F12.TabIndex = 113;
            this.F12.Text = "F12";
            this.F12.UseVisualStyleBackColor = false;
            this.F12.Click += new System.EventHandler(this.F12_Click);
            // 
            // H15
            // 
            this.H15.BackColor = System.Drawing.Color.SlateBlue;
            this.H15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H15.ForeColor = System.Drawing.Color.White;
            this.H15.Location = new System.Drawing.Point(508, 116);
            this.H15.Name = "H15";
            this.H15.Size = new System.Drawing.Size(50, 50);
            this.H15.TabIndex = 156;
            this.H15.Text = "H15";
            this.H15.UseVisualStyleBackColor = false;
            this.H15.Click += new System.EventHandler(this.H15_Click);
            // 
            // H14
            // 
            this.H14.BackColor = System.Drawing.Color.SlateBlue;
            this.H14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H14.ForeColor = System.Drawing.Color.White;
            this.H14.Location = new System.Drawing.Point(452, 116);
            this.H14.Name = "H14";
            this.H14.Size = new System.Drawing.Size(50, 50);
            this.H14.TabIndex = 155;
            this.H14.Text = "H14";
            this.H14.UseVisualStyleBackColor = false;
            this.H14.Click += new System.EventHandler(this.H14_Click);
            // 
            // F13
            // 
            this.F13.BackColor = System.Drawing.Color.SlateBlue;
            this.F13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F13.ForeColor = System.Drawing.Color.White;
            this.F13.Location = new System.Drawing.Point(396, 4);
            this.F13.Name = "F13";
            this.F13.Size = new System.Drawing.Size(50, 50);
            this.F13.TabIndex = 114;
            this.F13.Text = "F13";
            this.F13.UseVisualStyleBackColor = false;
            this.F13.Click += new System.EventHandler(this.F13_Click);
            // 
            // H13
            // 
            this.H13.BackColor = System.Drawing.Color.SlateBlue;
            this.H13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H13.ForeColor = System.Drawing.Color.White;
            this.H13.Location = new System.Drawing.Point(396, 116);
            this.H13.Name = "H13";
            this.H13.Size = new System.Drawing.Size(50, 50);
            this.H13.TabIndex = 154;
            this.H13.Text = "H13";
            this.H13.UseVisualStyleBackColor = false;
            this.H13.Click += new System.EventHandler(this.H13_Click);
            // 
            // H12
            // 
            this.H12.BackColor = System.Drawing.Color.SlateBlue;
            this.H12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H12.ForeColor = System.Drawing.Color.White;
            this.H12.Location = new System.Drawing.Point(340, 116);
            this.H12.Name = "H12";
            this.H12.Size = new System.Drawing.Size(50, 50);
            this.H12.TabIndex = 153;
            this.H12.Text = "H12";
            this.H12.UseVisualStyleBackColor = false;
            this.H12.Click += new System.EventHandler(this.H12_Click);
            // 
            // F14
            // 
            this.F14.BackColor = System.Drawing.Color.SlateBlue;
            this.F14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F14.ForeColor = System.Drawing.Color.White;
            this.F14.Location = new System.Drawing.Point(452, 4);
            this.F14.Name = "F14";
            this.F14.Size = new System.Drawing.Size(50, 50);
            this.F14.TabIndex = 115;
            this.F14.Text = "F14";
            this.F14.UseVisualStyleBackColor = false;
            this.F14.Click += new System.EventHandler(this.F14_Click);
            // 
            // H11
            // 
            this.H11.BackColor = System.Drawing.Color.SlateBlue;
            this.H11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H11.ForeColor = System.Drawing.Color.White;
            this.H11.Location = new System.Drawing.Point(284, 116);
            this.H11.Name = "H11";
            this.H11.Size = new System.Drawing.Size(50, 50);
            this.H11.TabIndex = 152;
            this.H11.Text = "H11";
            this.H11.UseVisualStyleBackColor = false;
            this.H11.Click += new System.EventHandler(this.H11_Click);
            // 
            // H10
            // 
            this.H10.BackColor = System.Drawing.Color.SlateBlue;
            this.H10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H10.ForeColor = System.Drawing.Color.White;
            this.H10.Location = new System.Drawing.Point(228, 116);
            this.H10.Name = "H10";
            this.H10.Size = new System.Drawing.Size(50, 50);
            this.H10.TabIndex = 151;
            this.H10.Text = "H10";
            this.H10.UseVisualStyleBackColor = false;
            this.H10.Click += new System.EventHandler(this.H10_Click);
            // 
            // F15
            // 
            this.F15.BackColor = System.Drawing.Color.SlateBlue;
            this.F15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.F15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F15.ForeColor = System.Drawing.Color.White;
            this.F15.Location = new System.Drawing.Point(508, 4);
            this.F15.Name = "F15";
            this.F15.Size = new System.Drawing.Size(50, 50);
            this.F15.TabIndex = 116;
            this.F15.Text = "F15";
            this.F15.UseVisualStyleBackColor = false;
            this.F15.Click += new System.EventHandler(this.F15_Click);
            // 
            // H9
            // 
            this.H9.BackColor = System.Drawing.Color.SlateBlue;
            this.H9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H9.ForeColor = System.Drawing.Color.White;
            this.H9.Location = new System.Drawing.Point(172, 116);
            this.H9.Name = "H9";
            this.H9.Size = new System.Drawing.Size(50, 50);
            this.H9.TabIndex = 150;
            this.H9.Text = "H9";
            this.H9.UseVisualStyleBackColor = false;
            this.H9.Click += new System.EventHandler(this.H9_Click);
            // 
            // H8
            // 
            this.H8.BackColor = System.Drawing.Color.SlateBlue;
            this.H8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H8.ForeColor = System.Drawing.Color.White;
            this.H8.Location = new System.Drawing.Point(116, 116);
            this.H8.Name = "H8";
            this.H8.Size = new System.Drawing.Size(50, 50);
            this.H8.TabIndex = 149;
            this.H8.Text = "H8";
            this.H8.UseVisualStyleBackColor = false;
            this.H8.Click += new System.EventHandler(this.H8_Click);
            // 
            // G6
            // 
            this.G6.BackColor = System.Drawing.Color.SlateBlue;
            this.G6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G6.ForeColor = System.Drawing.Color.White;
            this.G6.Location = new System.Drawing.Point(4, 60);
            this.G6.Name = "G6";
            this.G6.Size = new System.Drawing.Size(50, 50);
            this.G6.TabIndex = 127;
            this.G6.Text = "G6";
            this.G6.UseVisualStyleBackColor = false;
            this.G6.Click += new System.EventHandler(this.G6_Click);
            // 
            // H7
            // 
            this.H7.BackColor = System.Drawing.Color.SlateBlue;
            this.H7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H7.ForeColor = System.Drawing.Color.White;
            this.H7.Location = new System.Drawing.Point(60, 116);
            this.H7.Name = "H7";
            this.H7.Size = new System.Drawing.Size(50, 50);
            this.H7.TabIndex = 148;
            this.H7.Text = "H7";
            this.H7.UseVisualStyleBackColor = false;
            this.H7.Click += new System.EventHandler(this.H7_Click);
            // 
            // H6
            // 
            this.H6.BackColor = System.Drawing.Color.SlateBlue;
            this.H6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.H6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H6.ForeColor = System.Drawing.Color.White;
            this.H6.Location = new System.Drawing.Point(4, 116);
            this.H6.Name = "H6";
            this.H6.Size = new System.Drawing.Size(50, 50);
            this.H6.TabIndex = 147;
            this.H6.Text = "H6";
            this.H6.UseVisualStyleBackColor = false;
            this.H6.Click += new System.EventHandler(this.H6_Click);
            // 
            // G7
            // 
            this.G7.BackColor = System.Drawing.Color.SlateBlue;
            this.G7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G7.ForeColor = System.Drawing.Color.White;
            this.G7.Location = new System.Drawing.Point(60, 60);
            this.G7.Name = "G7";
            this.G7.Size = new System.Drawing.Size(50, 50);
            this.G7.TabIndex = 128;
            this.G7.Text = "G7";
            this.G7.UseVisualStyleBackColor = false;
            this.G7.Click += new System.EventHandler(this.G7_Click);
            // 
            // G15
            // 
            this.G15.BackColor = System.Drawing.Color.SlateBlue;
            this.G15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G15.ForeColor = System.Drawing.Color.White;
            this.G15.Location = new System.Drawing.Point(508, 60);
            this.G15.Name = "G15";
            this.G15.Size = new System.Drawing.Size(50, 50);
            this.G15.TabIndex = 136;
            this.G15.Text = "G15";
            this.G15.UseVisualStyleBackColor = false;
            this.G15.Click += new System.EventHandler(this.G15_Click);
            // 
            // G14
            // 
            this.G14.BackColor = System.Drawing.Color.SlateBlue;
            this.G14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G14.ForeColor = System.Drawing.Color.White;
            this.G14.Location = new System.Drawing.Point(452, 60);
            this.G14.Name = "G14";
            this.G14.Size = new System.Drawing.Size(50, 50);
            this.G14.TabIndex = 135;
            this.G14.Text = "G14";
            this.G14.UseVisualStyleBackColor = false;
            this.G14.Click += new System.EventHandler(this.G14_Click);
            // 
            // G8
            // 
            this.G8.BackColor = System.Drawing.Color.SlateBlue;
            this.G8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G8.ForeColor = System.Drawing.Color.White;
            this.G8.Location = new System.Drawing.Point(116, 60);
            this.G8.Name = "G8";
            this.G8.Size = new System.Drawing.Size(50, 50);
            this.G8.TabIndex = 129;
            this.G8.Text = "G8";
            this.G8.UseVisualStyleBackColor = false;
            this.G8.Click += new System.EventHandler(this.G8_Click);
            // 
            // G13
            // 
            this.G13.BackColor = System.Drawing.Color.SlateBlue;
            this.G13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G13.ForeColor = System.Drawing.Color.White;
            this.G13.Location = new System.Drawing.Point(396, 60);
            this.G13.Name = "G13";
            this.G13.Size = new System.Drawing.Size(50, 50);
            this.G13.TabIndex = 134;
            this.G13.Text = "G13";
            this.G13.UseVisualStyleBackColor = false;
            this.G13.Click += new System.EventHandler(this.G13_Click);
            // 
            // G12
            // 
            this.G12.BackColor = System.Drawing.Color.SlateBlue;
            this.G12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G12.ForeColor = System.Drawing.Color.White;
            this.G12.Location = new System.Drawing.Point(340, 60);
            this.G12.Name = "G12";
            this.G12.Size = new System.Drawing.Size(50, 50);
            this.G12.TabIndex = 133;
            this.G12.Text = "G12";
            this.G12.UseVisualStyleBackColor = false;
            this.G12.Click += new System.EventHandler(this.G12_Click);
            // 
            // G9
            // 
            this.G9.BackColor = System.Drawing.Color.SlateBlue;
            this.G9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G9.ForeColor = System.Drawing.Color.White;
            this.G9.Location = new System.Drawing.Point(172, 60);
            this.G9.Name = "G9";
            this.G9.Size = new System.Drawing.Size(50, 50);
            this.G9.TabIndex = 130;
            this.G9.Text = "G9";
            this.G9.UseVisualStyleBackColor = false;
            this.G9.Click += new System.EventHandler(this.G9_Click);
            // 
            // G11
            // 
            this.G11.BackColor = System.Drawing.Color.SlateBlue;
            this.G11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G11.ForeColor = System.Drawing.Color.White;
            this.G11.Location = new System.Drawing.Point(284, 60);
            this.G11.Name = "G11";
            this.G11.Size = new System.Drawing.Size(50, 50);
            this.G11.TabIndex = 132;
            this.G11.Text = "G11";
            this.G11.UseVisualStyleBackColor = false;
            this.G11.Click += new System.EventHandler(this.G11_Click);
            // 
            // G10
            // 
            this.G10.BackColor = System.Drawing.Color.SlateBlue;
            this.G10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.G10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G10.ForeColor = System.Drawing.Color.White;
            this.G10.Location = new System.Drawing.Point(228, 60);
            this.G10.Name = "G10";
            this.G10.Size = new System.Drawing.Size(50, 50);
            this.G10.TabIndex = 131;
            this.G10.Text = "G10";
            this.G10.UseVisualStyleBackColor = false;
            this.G10.Click += new System.EventHandler(this.G10_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(391, 62);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 281;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // ChooseSeat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1284, 994);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.N20);
            this.Controls.Add(this.N19);
            this.Controls.Add(this.N18);
            this.Controls.Add(this.N17);
            this.Controls.Add(this.N16);
            this.Controls.Add(this.N15);
            this.Controls.Add(this.N14);
            this.Controls.Add(this.N13);
            this.Controls.Add(this.N12);
            this.Controls.Add(this.N11);
            this.Controls.Add(this.N10);
            this.Controls.Add(this.N9);
            this.Controls.Add(this.N8);
            this.Controls.Add(this.N7);
            this.Controls.Add(this.N6);
            this.Controls.Add(this.N5);
            this.Controls.Add(this.N4);
            this.Controls.Add(this.N3);
            this.Controls.Add(this.N2);
            this.Controls.Add(this.N1);
            this.Controls.Add(this.M20);
            this.Controls.Add(this.M19);
            this.Controls.Add(this.M18);
            this.Controls.Add(this.M17);
            this.Controls.Add(this.M16);
            this.Controls.Add(this.M15);
            this.Controls.Add(this.M14);
            this.Controls.Add(this.M13);
            this.Controls.Add(this.M12);
            this.Controls.Add(this.M11);
            this.Controls.Add(this.M10);
            this.Controls.Add(this.M9);
            this.Controls.Add(this.M8);
            this.Controls.Add(this.M7);
            this.Controls.Add(this.M6);
            this.Controls.Add(this.M5);
            this.Controls.Add(this.M4);
            this.Controls.Add(this.M3);
            this.Controls.Add(this.M2);
            this.Controls.Add(this.M1);
            this.Controls.Add(this.L20);
            this.Controls.Add(this.L19);
            this.Controls.Add(this.L18);
            this.Controls.Add(this.L17);
            this.Controls.Add(this.L16);
            this.Controls.Add(this.L15);
            this.Controls.Add(this.L14);
            this.Controls.Add(this.L13);
            this.Controls.Add(this.L12);
            this.Controls.Add(this.L11);
            this.Controls.Add(this.L10);
            this.Controls.Add(this.L9);
            this.Controls.Add(this.L8);
            this.Controls.Add(this.L7);
            this.Controls.Add(this.L6);
            this.Controls.Add(this.L5);
            this.Controls.Add(this.L4);
            this.Controls.Add(this.L3);
            this.Controls.Add(this.L2);
            this.Controls.Add(this.L1);
            this.Controls.Add(this.K20);
            this.Controls.Add(this.K19);
            this.Controls.Add(this.K18);
            this.Controls.Add(this.K17);
            this.Controls.Add(this.K16);
            this.Controls.Add(this.K15);
            this.Controls.Add(this.K14);
            this.Controls.Add(this.K13);
            this.Controls.Add(this.K12);
            this.Controls.Add(this.K11);
            this.Controls.Add(this.K10);
            this.Controls.Add(this.K9);
            this.Controls.Add(this.K8);
            this.Controls.Add(this.K7);
            this.Controls.Add(this.K6);
            this.Controls.Add(this.K5);
            this.Controls.Add(this.K4);
            this.Controls.Add(this.K3);
            this.Controls.Add(this.K2);
            this.Controls.Add(this.K1);
            this.Controls.Add(this.J20);
            this.Controls.Add(this.J19);
            this.Controls.Add(this.J18);
            this.Controls.Add(this.J17);
            this.Controls.Add(this.J16);
            this.Controls.Add(this.J15);
            this.Controls.Add(this.J14);
            this.Controls.Add(this.J13);
            this.Controls.Add(this.J12);
            this.Controls.Add(this.J11);
            this.Controls.Add(this.J10);
            this.Controls.Add(this.J9);
            this.Controls.Add(this.J8);
            this.Controls.Add(this.J7);
            this.Controls.Add(this.J6);
            this.Controls.Add(this.J5);
            this.Controls.Add(this.J4);
            this.Controls.Add(this.J3);
            this.Controls.Add(this.J2);
            this.Controls.Add(this.J1);
            this.Controls.Add(this.I20);
            this.Controls.Add(this.I19);
            this.Controls.Add(this.I18);
            this.Controls.Add(this.I17);
            this.Controls.Add(this.I16);
            this.Controls.Add(this.I5);
            this.Controls.Add(this.I4);
            this.Controls.Add(this.I3);
            this.Controls.Add(this.I2);
            this.Controls.Add(this.I1);
            this.Controls.Add(this.H20);
            this.Controls.Add(this.H19);
            this.Controls.Add(this.H18);
            this.Controls.Add(this.H17);
            this.Controls.Add(this.H16);
            this.Controls.Add(this.H5);
            this.Controls.Add(this.H4);
            this.Controls.Add(this.H3);
            this.Controls.Add(this.H2);
            this.Controls.Add(this.H1);
            this.Controls.Add(this.G20);
            this.Controls.Add(this.G19);
            this.Controls.Add(this.G18);
            this.Controls.Add(this.G17);
            this.Controls.Add(this.G16);
            this.Controls.Add(this.G5);
            this.Controls.Add(this.G4);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.G2);
            this.Controls.Add(this.G1);
            this.Controls.Add(this.F20);
            this.Controls.Add(this.F19);
            this.Controls.Add(this.F18);
            this.Controls.Add(this.F17);
            this.Controls.Add(this.F16);
            this.Controls.Add(this.F5);
            this.Controls.Add(this.F4);
            this.Controls.Add(this.F3);
            this.Controls.Add(this.F2);
            this.Controls.Add(this.F1);
            this.Controls.Add(this.E20);
            this.Controls.Add(this.E19);
            this.Controls.Add(this.E18);
            this.Controls.Add(this.E17);
            this.Controls.Add(this.E16);
            this.Controls.Add(this.E15);
            this.Controls.Add(this.E14);
            this.Controls.Add(this.E13);
            this.Controls.Add(this.E12);
            this.Controls.Add(this.E11);
            this.Controls.Add(this.E10);
            this.Controls.Add(this.E9);
            this.Controls.Add(this.E8);
            this.Controls.Add(this.E7);
            this.Controls.Add(this.E6);
            this.Controls.Add(this.E5);
            this.Controls.Add(this.E4);
            this.Controls.Add(this.E3);
            this.Controls.Add(this.E2);
            this.Controls.Add(this.E1);
            this.Controls.Add(this.D20);
            this.Controls.Add(this.D19);
            this.Controls.Add(this.D18);
            this.Controls.Add(this.D17);
            this.Controls.Add(this.D16);
            this.Controls.Add(this.D15);
            this.Controls.Add(this.D14);
            this.Controls.Add(this.D13);
            this.Controls.Add(this.D12);
            this.Controls.Add(this.D11);
            this.Controls.Add(this.D10);
            this.Controls.Add(this.D9);
            this.Controls.Add(this.D8);
            this.Controls.Add(this.D7);
            this.Controls.Add(this.D6);
            this.Controls.Add(this.D5);
            this.Controls.Add(this.D4);
            this.Controls.Add(this.D3);
            this.Controls.Add(this.D2);
            this.Controls.Add(this.D1);
            this.Controls.Add(this.C20);
            this.Controls.Add(this.C19);
            this.Controls.Add(this.C18);
            this.Controls.Add(this.C17);
            this.Controls.Add(this.C16);
            this.Controls.Add(this.C15);
            this.Controls.Add(this.C14);
            this.Controls.Add(this.C13);
            this.Controls.Add(this.C12);
            this.Controls.Add(this.C11);
            this.Controls.Add(this.C10);
            this.Controls.Add(this.C9);
            this.Controls.Add(this.C8);
            this.Controls.Add(this.C7);
            this.Controls.Add(this.C6);
            this.Controls.Add(this.C5);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.B20);
            this.Controls.Add(this.B19);
            this.Controls.Add(this.B18);
            this.Controls.Add(this.B17);
            this.Controls.Add(this.B16);
            this.Controls.Add(this.B15);
            this.Controls.Add(this.B14);
            this.Controls.Add(this.B13);
            this.Controls.Add(this.B12);
            this.Controls.Add(this.B11);
            this.Controls.Add(this.B10);
            this.Controls.Add(this.B9);
            this.Controls.Add(this.B8);
            this.Controls.Add(this.B7);
            this.Controls.Add(this.B6);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.A20);
            this.Controls.Add(this.A19);
            this.Controls.Add(this.A18);
            this.Controls.Add(this.A17);
            this.Controls.Add(this.A16);
            this.Controls.Add(this.A15);
            this.Controls.Add(this.A14);
            this.Controls.Add(this.A13);
            this.Controls.Add(this.A12);
            this.Controls.Add(this.A11);
            this.Controls.Add(this.A10);
            this.Controls.Add(this.A9);
            this.Controls.Add(this.A8);
            this.Controls.Add(this.A7);
            this.Controls.Add(this.A6);
            this.Controls.Add(this.A5);
            this.Controls.Add(this.A4);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ChooseSeat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chọn chỗ ngồi";
            this.Load += new System.EventHandler(this.ChooseSeat_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button A4;
        private System.Windows.Forms.Button A5;
        private System.Windows.Forms.Button A6;
        private System.Windows.Forms.Button A7;
        private System.Windows.Forms.Button A8;
        private System.Windows.Forms.Button A9;
        private System.Windows.Forms.Button A10;
        private System.Windows.Forms.Button A20;
        private System.Windows.Forms.Button A19;
        private System.Windows.Forms.Button A18;
        private System.Windows.Forms.Button A17;
        private System.Windows.Forms.Button A16;
        private System.Windows.Forms.Button A15;
        private System.Windows.Forms.Button A14;
        private System.Windows.Forms.Button A13;
        private System.Windows.Forms.Button A12;
        private System.Windows.Forms.Button A11;
        private System.Windows.Forms.Button B20;
        private System.Windows.Forms.Button B19;
        private System.Windows.Forms.Button B18;
        private System.Windows.Forms.Button B17;
        private System.Windows.Forms.Button B16;
        private System.Windows.Forms.Button B15;
        private System.Windows.Forms.Button B14;
        private System.Windows.Forms.Button B13;
        private System.Windows.Forms.Button B12;
        private System.Windows.Forms.Button B11;
        private System.Windows.Forms.Button B10;
        private System.Windows.Forms.Button B9;
        private System.Windows.Forms.Button B8;
        private System.Windows.Forms.Button B7;
        private System.Windows.Forms.Button B6;
        private System.Windows.Forms.Button B5;
        private System.Windows.Forms.Button B4;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button C20;
        private System.Windows.Forms.Button C19;
        private System.Windows.Forms.Button C18;
        private System.Windows.Forms.Button C17;
        private System.Windows.Forms.Button C16;
        private System.Windows.Forms.Button C15;
        private System.Windows.Forms.Button C14;
        private System.Windows.Forms.Button C13;
        private System.Windows.Forms.Button C12;
        private System.Windows.Forms.Button C11;
        private System.Windows.Forms.Button C10;
        private System.Windows.Forms.Button C9;
        private System.Windows.Forms.Button C8;
        private System.Windows.Forms.Button C7;
        private System.Windows.Forms.Button C6;
        private System.Windows.Forms.Button C5;
        private System.Windows.Forms.Button C4;
        private System.Windows.Forms.Button C3;
        private System.Windows.Forms.Button C2;
        private System.Windows.Forms.Button C1;
        private System.Windows.Forms.Button D20;
        private System.Windows.Forms.Button D19;
        private System.Windows.Forms.Button D18;
        private System.Windows.Forms.Button D17;
        private System.Windows.Forms.Button D16;
        private System.Windows.Forms.Button D15;
        private System.Windows.Forms.Button D14;
        private System.Windows.Forms.Button D13;
        private System.Windows.Forms.Button D12;
        private System.Windows.Forms.Button D11;
        private System.Windows.Forms.Button D10;
        private System.Windows.Forms.Button D9;
        private System.Windows.Forms.Button D8;
        private System.Windows.Forms.Button D7;
        private System.Windows.Forms.Button D6;
        private System.Windows.Forms.Button D5;
        private System.Windows.Forms.Button D4;
        private System.Windows.Forms.Button D3;
        private System.Windows.Forms.Button D2;
        private System.Windows.Forms.Button D1;
        private System.Windows.Forms.Button E20;
        private System.Windows.Forms.Button E19;
        private System.Windows.Forms.Button E18;
        private System.Windows.Forms.Button E17;
        private System.Windows.Forms.Button E16;
        private System.Windows.Forms.Button E15;
        private System.Windows.Forms.Button E14;
        private System.Windows.Forms.Button E13;
        private System.Windows.Forms.Button E12;
        private System.Windows.Forms.Button E11;
        private System.Windows.Forms.Button E10;
        private System.Windows.Forms.Button E9;
        private System.Windows.Forms.Button E8;
        private System.Windows.Forms.Button E7;
        private System.Windows.Forms.Button E6;
        private System.Windows.Forms.Button E5;
        private System.Windows.Forms.Button E4;
        private System.Windows.Forms.Button E3;
        private System.Windows.Forms.Button E2;
        private System.Windows.Forms.Button E1;
        private System.Windows.Forms.Button F20;
        private System.Windows.Forms.Button F19;
        private System.Windows.Forms.Button F18;
        private System.Windows.Forms.Button F17;
        private System.Windows.Forms.Button F16;
        private System.Windows.Forms.Button F15;
        private System.Windows.Forms.Button F14;
        private System.Windows.Forms.Button F13;
        private System.Windows.Forms.Button F12;
        private System.Windows.Forms.Button F11;
        private System.Windows.Forms.Button F10;
        private System.Windows.Forms.Button F9;
        private System.Windows.Forms.Button F8;
        private System.Windows.Forms.Button F7;
        private System.Windows.Forms.Button F6;
        private System.Windows.Forms.Button F5;
        private System.Windows.Forms.Button F4;
        private System.Windows.Forms.Button F3;
        private System.Windows.Forms.Button F2;
        private System.Windows.Forms.Button F1;
        private System.Windows.Forms.Button G20;
        private System.Windows.Forms.Button G19;
        private System.Windows.Forms.Button G18;
        private System.Windows.Forms.Button G17;
        private System.Windows.Forms.Button G16;
        private System.Windows.Forms.Button G15;
        private System.Windows.Forms.Button G14;
        private System.Windows.Forms.Button G13;
        private System.Windows.Forms.Button G12;
        private System.Windows.Forms.Button G11;
        private System.Windows.Forms.Button G10;
        private System.Windows.Forms.Button G9;
        private System.Windows.Forms.Button G8;
        private System.Windows.Forms.Button G7;
        private System.Windows.Forms.Button G6;
        private System.Windows.Forms.Button G5;
        private System.Windows.Forms.Button G4;
        private System.Windows.Forms.Button G3;
        private System.Windows.Forms.Button G2;
        private System.Windows.Forms.Button G1;
        private System.Windows.Forms.Button H20;
        private System.Windows.Forms.Button H19;
        private System.Windows.Forms.Button H18;
        private System.Windows.Forms.Button H17;
        private System.Windows.Forms.Button H16;
        private System.Windows.Forms.Button H15;
        private System.Windows.Forms.Button H14;
        private System.Windows.Forms.Button H13;
        private System.Windows.Forms.Button H12;
        private System.Windows.Forms.Button H11;
        private System.Windows.Forms.Button H10;
        private System.Windows.Forms.Button H9;
        private System.Windows.Forms.Button H8;
        private System.Windows.Forms.Button H7;
        private System.Windows.Forms.Button H6;
        private System.Windows.Forms.Button H5;
        private System.Windows.Forms.Button H4;
        private System.Windows.Forms.Button H3;
        private System.Windows.Forms.Button H2;
        private System.Windows.Forms.Button H1;
        private System.Windows.Forms.Button I20;
        private System.Windows.Forms.Button I19;
        private System.Windows.Forms.Button I18;
        private System.Windows.Forms.Button I17;
        private System.Windows.Forms.Button I16;
        private System.Windows.Forms.Button I15;
        private System.Windows.Forms.Button I14;
        private System.Windows.Forms.Button I13;
        private System.Windows.Forms.Button I12;
        private System.Windows.Forms.Button I11;
        private System.Windows.Forms.Button I10;
        private System.Windows.Forms.Button I9;
        private System.Windows.Forms.Button I8;
        private System.Windows.Forms.Button I7;
        private System.Windows.Forms.Button I6;
        private System.Windows.Forms.Button I5;
        private System.Windows.Forms.Button I4;
        private System.Windows.Forms.Button I3;
        private System.Windows.Forms.Button I2;
        private System.Windows.Forms.Button I1;
        private System.Windows.Forms.Button J20;
        private System.Windows.Forms.Button J19;
        private System.Windows.Forms.Button J18;
        private System.Windows.Forms.Button J17;
        private System.Windows.Forms.Button J16;
        private System.Windows.Forms.Button J15;
        private System.Windows.Forms.Button J14;
        private System.Windows.Forms.Button J13;
        private System.Windows.Forms.Button J12;
        private System.Windows.Forms.Button J11;
        private System.Windows.Forms.Button J10;
        private System.Windows.Forms.Button J9;
        private System.Windows.Forms.Button J8;
        private System.Windows.Forms.Button J7;
        private System.Windows.Forms.Button J6;
        private System.Windows.Forms.Button J5;
        private System.Windows.Forms.Button J4;
        private System.Windows.Forms.Button J3;
        private System.Windows.Forms.Button J2;
        private System.Windows.Forms.Button J1;
        private System.Windows.Forms.Button K20;
        private System.Windows.Forms.Button K19;
        private System.Windows.Forms.Button K18;
        private System.Windows.Forms.Button K17;
        private System.Windows.Forms.Button K16;
        private System.Windows.Forms.Button K15;
        private System.Windows.Forms.Button K14;
        private System.Windows.Forms.Button K13;
        private System.Windows.Forms.Button K12;
        private System.Windows.Forms.Button K11;
        private System.Windows.Forms.Button K10;
        private System.Windows.Forms.Button K9;
        private System.Windows.Forms.Button K8;
        private System.Windows.Forms.Button K7;
        private System.Windows.Forms.Button K6;
        private System.Windows.Forms.Button K5;
        private System.Windows.Forms.Button K4;
        private System.Windows.Forms.Button K3;
        private System.Windows.Forms.Button K2;
        private System.Windows.Forms.Button K1;
        private System.Windows.Forms.Button L20;
        private System.Windows.Forms.Button L19;
        private System.Windows.Forms.Button L18;
        private System.Windows.Forms.Button L17;
        private System.Windows.Forms.Button L16;
        private System.Windows.Forms.Button L15;
        private System.Windows.Forms.Button L14;
        private System.Windows.Forms.Button L13;
        private System.Windows.Forms.Button L12;
        private System.Windows.Forms.Button L11;
        private System.Windows.Forms.Button L10;
        private System.Windows.Forms.Button L9;
        private System.Windows.Forms.Button L8;
        private System.Windows.Forms.Button L7;
        private System.Windows.Forms.Button L6;
        private System.Windows.Forms.Button L5;
        private System.Windows.Forms.Button L4;
        private System.Windows.Forms.Button L3;
        private System.Windows.Forms.Button L2;
        private System.Windows.Forms.Button L1;
        private System.Windows.Forms.Button M20;
        private System.Windows.Forms.Button M19;
        private System.Windows.Forms.Button M18;
        private System.Windows.Forms.Button M17;
        private System.Windows.Forms.Button M16;
        private System.Windows.Forms.Button M15;
        private System.Windows.Forms.Button M14;
        private System.Windows.Forms.Button M13;
        private System.Windows.Forms.Button M12;
        private System.Windows.Forms.Button M11;
        private System.Windows.Forms.Button M10;
        private System.Windows.Forms.Button M9;
        private System.Windows.Forms.Button M8;
        private System.Windows.Forms.Button M7;
        private System.Windows.Forms.Button M6;
        private System.Windows.Forms.Button M5;
        private System.Windows.Forms.Button M4;
        private System.Windows.Forms.Button M3;
        private System.Windows.Forms.Button M2;
        private System.Windows.Forms.Button M1;
        private System.Windows.Forms.Button N20;
        private System.Windows.Forms.Button N19;
        private System.Windows.Forms.Button N18;
        private System.Windows.Forms.Button N17;
        private System.Windows.Forms.Button N16;
        private System.Windows.Forms.Button N15;
        private System.Windows.Forms.Button N14;
        private System.Windows.Forms.Button N13;
        private System.Windows.Forms.Button N12;
        private System.Windows.Forms.Button N11;
        private System.Windows.Forms.Button N10;
        private System.Windows.Forms.Button N9;
        private System.Windows.Forms.Button N8;
        private System.Windows.Forms.Button N7;
        private System.Windows.Forms.Button N6;
        private System.Windows.Forms.Button N5;
        private System.Windows.Forms.Button N4;
        private System.Windows.Forms.Button N3;
        private System.Windows.Forms.Button N2;
        private System.Windows.Forms.Button N1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button284;
        private System.Windows.Forms.Button button283;
        private System.Windows.Forms.Button button282;
        private System.Windows.Forms.Button button281;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label labelSeat;
        private System.Windows.Forms.Label labelGiaGhe;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonPayment;
        private System.Windows.Forms.Button button1;
    }
}