﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{
    public partial class BuyTicket : Form
    {
        string user1;
        string dayOfWeek1;
        string cinemaPlace1;
        string pic1;
        string name1;
        string category1;
        string content1;
        string actor1;
        string director1;
        string producer1;
        string studio1;
        string date1;
        string time1;
        string age1;
        string showtime1;
        string timestart1;
        public BuyTicket(string timestart, string user, string pic, string name, string category, string content, string actor, string director, string producer, string studio, string date, string time, string age)
        {
            timestart1 = timestart;
            user1 = user;
            pic1 = pic;
            name1 = name;
            category1 = category;
            content1 = content;
            actor1 = actor;
            director1 = director;
            producer1 = producer;
            studio1 = studio;
            date1 = date;
            time1 = time;
            age1 = age;
            InitializeComponent();
        }

        public void button4_Click(object sender, EventArgs e)
        {
            buttonInformation.BackColor = Color.Salmon;
            buttonBuyTicket.BackColor = Color.White;
            buttonCalendar.BackColor = Color.White;
            buttonEvaluate.BackColor = Color.White;
            buttonNews.BackColor = Color.White;
            Information infor = new Information(timestart1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
            this.Close();
            infor.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Calendar buyticket = new Calendar(timestart1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
            this.Close();
            buyticket.ShowDialog();
            this.Show();
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            buttonEvaluate.BackColor = Color.Salmon;
            buttonBuyTicket.BackColor = Color.White;
            buttonCalendar.BackColor = Color.White;
            buttonInformation.BackColor = Color.White;
            buttonNews.BackColor = Color.White;
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            buttonNews.BackColor = Color.Salmon;
            buttonBuyTicket.BackColor = Color.White;
            buttonCalendar.BackColor = Color.White;
            buttonEvaluate.BackColor = Color.White;
            buttonInformation.BackColor = Color.White;
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            buttonBuyTicket.BackColor = Color.Salmon;
            buttonInformation.BackColor = Color.White;
            buttonCalendar.BackColor = Color.White;
            buttonEvaluate.BackColor = Color.White;
            buttonNews.BackColor = Color.White;
            if (buttonInformation.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = false;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonCalendar.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = false;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonEvaluate.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = false;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonNews.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = false;
                buttonBuyTicket.Enabled = true;
            }
            else if (buttonBuyTicket.BackColor == Color.Salmon)
            {
                buttonInformation.Enabled = true;
                buttonCalendar.Enabled = true;
                buttonEvaluate.Enabled = true;
                buttonNews.Enabled = true;
                buttonBuyTicket.Enabled = false;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            dayOfWeek1 = buttonNgay1.Text;
            buttonNgay1.ForeColor = Color.Black;
            buttonNgay2.ForeColor = Color.DimGray;
            buttonNgay3.ForeColor = Color.DimGray;
            buttonNgay4.ForeColor = Color.DimGray;
            buttonNgay5.ForeColor = Color.DimGray;
            buttonNgay6.ForeColor = Color.DimGray;
            buttonNgay7.ForeColor = Color.DimGray;
            buttonNgay1.BackColor = Color.LightSteelBlue;
            buttonNgay2.BackColor = Color.Gainsboro;
            buttonNgay3.BackColor = Color.Gainsboro;
            buttonNgay4.BackColor = Color.Gainsboro;
            buttonNgay5.BackColor = Color.Gainsboro;
            buttonNgay6.BackColor = Color.Gainsboro;
            buttonNgay7.BackColor = Color.Gainsboro;

            button1.BackColor = Color.WhiteSmoke;
            button2.BackColor = Color.WhiteSmoke;
            button3.BackColor = Color.WhiteSmoke;
            button4.BackColor = Color.WhiteSmoke;
            button5.BackColor = Color.WhiteSmoke;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            dayOfWeek1 = buttonNgay2.Text;
            buttonNgay1.ForeColor = Color.DimGray;
            buttonNgay2.ForeColor = Color.Black;
            buttonNgay3.ForeColor = Color.DimGray;
            buttonNgay4.ForeColor = Color.DimGray;
            buttonNgay5.ForeColor = Color.DimGray;
            buttonNgay6.ForeColor = Color.DimGray;
            buttonNgay7.ForeColor = Color.DimGray;
            buttonNgay1.BackColor = Color.Gainsboro;
            buttonNgay2.BackColor = Color.LightSteelBlue;
            buttonNgay3.BackColor = Color.Gainsboro;
            buttonNgay4.BackColor = Color.Gainsboro;
            buttonNgay5.BackColor = Color.Gainsboro;
            buttonNgay6.BackColor = Color.Gainsboro;
            buttonNgay7.BackColor = Color.Gainsboro;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dayOfWeek1 = buttonNgay3.Text;
            buttonNgay1.ForeColor = Color.DimGray;
            buttonNgay2.ForeColor = Color.DimGray;
            buttonNgay3.ForeColor = Color.Black;
            buttonNgay4.ForeColor = Color.DimGray;
            buttonNgay5.ForeColor = Color.DimGray;
            buttonNgay6.ForeColor = Color.DimGray;
            buttonNgay7.ForeColor = Color.DimGray;
            buttonNgay1.BackColor = Color.Gainsboro;
            buttonNgay2.BackColor = Color.Gainsboro;
            buttonNgay3.BackColor = Color.LightSteelBlue;
            buttonNgay4.BackColor = Color.Gainsboro;
            buttonNgay5.BackColor = Color.Gainsboro;
            buttonNgay6.BackColor = Color.Gainsboro;
            buttonNgay7.BackColor = Color.Gainsboro;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dayOfWeek1 = buttonNgay4.Text;
            buttonNgay1.ForeColor = Color.DimGray;
            buttonNgay2.ForeColor = Color.DimGray;
            buttonNgay3.ForeColor = Color.DimGray;
            buttonNgay4.ForeColor = Color.Black;
            buttonNgay5.ForeColor = Color.DimGray;
            buttonNgay6.ForeColor = Color.DimGray;
            buttonNgay7.ForeColor = Color.DimGray;
            buttonNgay1.BackColor = Color.Gainsboro;
            buttonNgay2.BackColor = Color.Gainsboro;
            buttonNgay3.BackColor = Color.Gainsboro;
            buttonNgay4.BackColor = Color.LightSteelBlue;
            buttonNgay5.BackColor = Color.Gainsboro;
            buttonNgay6.BackColor = Color.Gainsboro;
            buttonNgay7.BackColor = Color.Gainsboro;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dayOfWeek1 = buttonNgay5.Text;
            buttonNgay1.ForeColor = Color.DimGray;
            buttonNgay2.ForeColor = Color.DimGray;
            buttonNgay3.ForeColor = Color.DimGray;
            buttonNgay4.ForeColor = Color.DimGray;
            buttonNgay5.ForeColor = Color.Black;
            buttonNgay6.ForeColor = Color.DimGray;
            buttonNgay7.ForeColor = Color.DimGray;
            buttonNgay1.BackColor = Color.Gainsboro;
            buttonNgay2.BackColor = Color.Gainsboro;
            buttonNgay3.BackColor = Color.Gainsboro;
            buttonNgay4.BackColor = Color.Gainsboro;
            buttonNgay5.BackColor = Color.LightSteelBlue;
            buttonNgay6.BackColor = Color.Gainsboro;
            buttonNgay7.BackColor = Color.Gainsboro;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            dayOfWeek1 = buttonNgay6.Text;
            buttonNgay1.ForeColor = Color.DimGray;
            buttonNgay2.ForeColor = Color.DimGray;
            buttonNgay3.ForeColor = Color.DimGray;
            buttonNgay4.ForeColor = Color.DimGray;
            buttonNgay5.ForeColor = Color.DimGray;
            buttonNgay6.ForeColor = Color.Black;
            buttonNgay7.ForeColor = Color.DimGray;
            buttonNgay1.BackColor = Color.Gainsboro;
            buttonNgay2.BackColor = Color.Gainsboro;
            buttonNgay3.BackColor = Color.Gainsboro;
            buttonNgay4.BackColor = Color.Gainsboro;
            buttonNgay5.BackColor = Color.Gainsboro;
            buttonNgay6.BackColor = Color.LightSteelBlue;
            buttonNgay7.BackColor = Color.Gainsboro;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            dayOfWeek1 = buttonNgay7.Text;
            buttonNgay1.ForeColor = Color.DimGray;
            buttonNgay2.ForeColor = Color.DimGray;
            buttonNgay3.ForeColor = Color.DimGray;
            buttonNgay4.ForeColor = Color.DimGray;
            buttonNgay5.ForeColor = Color.DimGray;
            buttonNgay6.ForeColor = Color.DimGray;
            buttonNgay7.ForeColor = Color.Black;
            buttonNgay1.BackColor = Color.Gainsboro;
            buttonNgay2.BackColor = Color.Gainsboro;
            buttonNgay3.BackColor = Color.Gainsboro;
            buttonNgay4.BackColor = Color.Gainsboro;
            buttonNgay5.BackColor = Color.Gainsboro;
            buttonNgay6.BackColor = Color.Gainsboro;
            buttonNgay7.BackColor = Color.LightSteelBlue;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                pictureBoxcgv1.Visible = true;
                pictureBoxcgv2.Visible = true;
                buttoncgv.Visible = true;
                button1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button5.Visible = true;

                button1.BackColor = Color.WhiteSmoke;
                button2.BackColor = Color.WhiteSmoke;
                button3.BackColor = Color.WhiteSmoke;
                button4.BackColor = Color.WhiteSmoke;
                button5.BackColor = Color.WhiteSmoke;

                buttonTime1.Visible = false;
                buttonTime2.Visible = false;
                buttonTime3.Visible = false;
                buttonTime4.Visible = false;
                buttonTime5.Visible = false;
                buttonTime6.Visible = false;
                buttonTime12.Visible = false;
                buttonTime11.Visible = false;
                buttonTime10.Visible = false;
                buttonTime9.Visible = false;
                buttonTime8.Visible = false;
                buttonTime7.Visible = false;
                buttonTime18.Visible = false;
                buttonTime17.Visible = false;
                buttonTime16.Visible = false;
                buttonTime15.Visible = false;
                buttonTime14.Visible = false;
                buttonTime13.Visible = false;
                buttonTime24.Visible = false;
                buttonTime23.Visible = false;
                buttonTime22.Visible = false;
                buttonTime21.Visible = false;
                buttonTime20.Visible = false;
                buttonTime19.Visible = false;
                buttonTime30.Visible = false;
                buttonTime29.Visible = false;
                buttonTime28.Visible = false;
                buttonTime27.Visible = false;
                buttonTime26.Visible = false;
                buttonTime25.Visible = false;
            }
            else
            {
                buttoncgv.Visible = false;
                pictureBoxcgv1.Visible = false;
                pictureBoxcgv2.Visible = false;
                button1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
                button5.Visible = false;

                buttonTime1.Visible = false;
                buttonTime2.Visible = false;
                buttonTime3.Visible = false;
                buttonTime4.Visible = false;
                buttonTime5.Visible = false;
                buttonTime6.Visible = false;
                buttonTime12.Visible = false;
                buttonTime11.Visible = false;
                buttonTime10.Visible = false;
                buttonTime9.Visible = false;
                buttonTime8.Visible = false;
                buttonTime7.Visible = false;
                buttonTime18.Visible = false;
                buttonTime17.Visible = false;
                buttonTime16.Visible = false;
                buttonTime15.Visible = false;
                buttonTime14.Visible = false;
                buttonTime13.Visible = false;
                buttonTime24.Visible = false;
                buttonTime23.Visible = false;
                buttonTime22.Visible = false;
                buttonTime21.Visible = false;
                buttonTime20.Visible = false;
                buttonTime19.Visible = false;
                buttonTime30.Visible = false;
                buttonTime29.Visible = false;
                buttonTime28.Visible = false;
                buttonTime27.Visible = false;
                buttonTime26.Visible = false;
                buttonTime25.Visible = false;
            }
        }

        private void BuyTicket_Load(object sender, EventArgs e)
        {
            int num = Int32.Parse(GetNumberPlace().Rows[0][0].ToString());
            for (int j = 0; j < num; j++)
            {
                comboBox1.Items.Add(GetPlace().Rows[j][0].ToString());
            }
            if (buttonNgay1.BackColor == Color.LightSteelBlue)
            {
                dayOfWeek1 = buttonNgay1.Text;
            }
            DateTime d1 = DateTime.Now;
            buttonNgay1.Text = ((d1.AddDays(0)).Day).ToString() + "/" + ((d1.AddDays(0)).Month).ToString();
            buttonNgay2.Text = ((d1.AddDays(1)).Day).ToString() + "/" + ((d1.AddDays(1)).Month).ToString();
            buttonNgay3.Text = ((d1.AddDays(2)).Day).ToString() + "/" + ((d1.AddDays(2)).Month).ToString();
            buttonNgay4.Text = ((d1.AddDays(3)).Day).ToString() + "/" + ((d1.AddDays(3)).Month).ToString();
            buttonNgay5.Text = ((d1.AddDays(4)).Day).ToString() + "/" + ((d1.AddDays(4)).Month).ToString();
            buttonNgay6.Text = ((d1.AddDays(5)).Day).ToString() + "/" + ((d1.AddDays(5)).Month).ToString();
            buttonNgay7.Text = ((d1.AddDays(6)).Day).ToString() + "/" + ((d1.AddDays(6)).Month).ToString();
            int numCinema = Int32.Parse(GetNumberCinema().Rows[0][0].ToString());
            if (numCinema <= 0)
            {
                MessageBox.Show("Hôm nay không có rạp phim nào !");
            }
            if (numCinema > 0)
            {
                if (buttonNgay1.BackColor == Color.LightSteelBlue)
                {
                    for (int j = 0; j < numCinema; j++)
                    {
                        if (j == 0 && j < numCinema)
                        {
                            button1.Text = GetCinema().Rows[j][0].ToString();
                        }
                        if (j == 1 && j < numCinema)
                        {
                            button2.Text = GetCinema().Rows[j][0].ToString();
                        }
                        if (j == 2 && j < numCinema)
                        {
                            button3.Text = GetCinema().Rows[j][0].ToString();
                        }
                        if (j == 3 && j < numCinema)
                        {
                            button4.Text = GetCinema().Rows[j][0].ToString();
                        }
                        if (j == 4 && j < numCinema)
                        {
                            button5.Text = GetCinema().Rows[j][0].ToString();
                        }
                    }
                }
            }
        }

        private void pictureBoxcgv2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Hà Nội")
            {
                if(button1.Visible == false)
                {
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    button5.Visible = true;

                    button1.BackColor = Color.WhiteSmoke;
                    button2.BackColor = Color.WhiteSmoke;
                    button3.BackColor = Color.WhiteSmoke;
                    button4.BackColor = Color.WhiteSmoke;
                    button5.BackColor = Color.WhiteSmoke;

                    buttonTime1.Visible = false;
                    buttonTime2.Visible = false;
                    buttonTime3.Visible = false;
                    buttonTime4.Visible = false;
                    buttonTime5.Visible = false;
                    buttonTime6.Visible = false;
                    buttonTime12.Visible = false;
                    buttonTime11.Visible = false;
                    buttonTime10.Visible = false;
                    buttonTime9.Visible = false;
                    buttonTime8.Visible = false;
                    buttonTime7.Visible = false;
                    buttonTime18.Visible = false;
                    buttonTime17.Visible = false;
                    buttonTime16.Visible = false;
                    buttonTime15.Visible = false;
                    buttonTime14.Visible = false;
                    buttonTime13.Visible = false;
                    buttonTime24.Visible = false;
                    buttonTime23.Visible = false;
                    buttonTime22.Visible = false;
                    buttonTime21.Visible = false;
                    buttonTime20.Visible = false;
                    buttonTime19.Visible = false;
                    buttonTime30.Visible = false;
                    buttonTime29.Visible = false;
                    buttonTime28.Visible = false;
                    buttonTime27.Visible = false;
                    buttonTime26.Visible = false;
                    buttonTime25.Visible = false;
                }
                else if (button1.Visible == true)
                {
                    button1.Visible = false;
                    button2.Visible = false;
                    button3.Visible = false;
                    button4.Visible = false;
                    button5.Visible = false;

                    button1.BackColor = Color.WhiteSmoke;
                    button2.BackColor = Color.WhiteSmoke;
                    button3.BackColor = Color.WhiteSmoke;
                    button4.BackColor = Color.WhiteSmoke;
                    button5.BackColor = Color.WhiteSmoke;

                    buttonTime1.Visible = false;
                    buttonTime2.Visible = false;
                    buttonTime3.Visible = false;
                    buttonTime4.Visible = false;
                    buttonTime5.Visible = false;
                    buttonTime6.Visible = false;
                    buttonTime12.Visible = false;
                    buttonTime11.Visible = false;
                    buttonTime10.Visible = false;
                    buttonTime9.Visible = false;
                    buttonTime8.Visible = false;
                    buttonTime7.Visible = false;
                    buttonTime18.Visible = false;
                    buttonTime17.Visible = false;
                    buttonTime16.Visible = false;
                    buttonTime15.Visible = false;
                    buttonTime14.Visible = false;
                    buttonTime13.Visible = false;
                    buttonTime24.Visible = false;
                    buttonTime23.Visible = false;
                    buttonTime22.Visible = false;
                    buttonTime21.Visible = false;
                    buttonTime20.Visible = false;
                    buttonTime19.Visible = false;
                    buttonTime30.Visible = false;
                    buttonTime29.Visible = false;
                    buttonTime28.Visible = false;
                    buttonTime27.Visible = false;
                    buttonTime26.Visible = false;
                    buttonTime25.Visible = false;
                }

            }
            else
            {
                buttoncgv.Visible = false;
                pictureBoxcgv1.Visible = false;
                pictureBoxcgv2.Visible = false;
                button1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
                button5.Visible = false;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightSteelBlue;
            button2.BackColor = Color.WhiteSmoke;
            button3.BackColor = Color.WhiteSmoke;
            button4.BackColor = Color.WhiteSmoke;
            button5.BackColor = Color.WhiteSmoke;

            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            buttonTime1.Visible = true;
            buttonTime2.Visible = true;
            buttonTime3.Visible = true;
            buttonTime4.Visible = true;
            buttonTime5.Visible = true;
            buttonTime6.Visible = true;
            buttonTime12.Visible = true;
            buttonTime11.Visible = true;
            buttonTime10.Visible = true;
            buttonTime9.Visible = true;
            buttonTime8.Visible = true;
            buttonTime7.Visible = true;
            buttonTime18.Visible = true;
            buttonTime17.Visible = true;
            buttonTime16.Visible = true;
            buttonTime15.Visible = true;
            buttonTime14.Visible = true;
            buttonTime13.Visible = true;
            buttonTime24.Visible = true;
            buttonTime23.Visible = true;
            buttonTime22.Visible = true;
            buttonTime21.Visible = true;
            buttonTime20.Visible = true;
            buttonTime19.Visible = true;
            buttonTime30.Visible = false;
            buttonTime29.Visible = false;
            buttonTime28.Visible = true;
            buttonTime27.Visible = true;
            buttonTime26.Visible = true;
            buttonTime25.Visible = true;

            cinemaPlace1 = button1.Text;
            int numTime = Int32.Parse(GetNumberTime().Rows[0][0].ToString());
            for(int j=0; j<numTime; j++)
            {
                if (j == 0 && j < numTime)
                {
                    buttonTime1.Text = GetTime().Rows[j][0].ToString().Substring(0,5);
                }
                if (j == 1 && j < numTime)
                {
                    buttonTime2.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 2 && j < numTime)
                {
                    buttonTime3.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 3 && j < numTime)
                {
                    buttonTime4.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 4 && j < numTime)
                {
                    buttonTime5.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 5 && j < numTime)
                {
                    buttonTime6.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 6 && j < numTime)
                {
                    buttonTime7.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 7 && j < numTime)
                {
                    buttonTime8.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 8 && j < numTime)
                {
                    buttonTime9.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 9 && j < numTime)
                {
                    buttonTime10.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 10 && j < numTime)
                {
                    buttonTime11.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 11 && j < numTime)
                {
                    buttonTime12.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 12 && j < numTime)
                {
                    buttonTime13.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 13 && j < numTime)
                {
                    buttonTime14.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 14 && j < numTime)
                {
                    buttonTime15.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 15 && j < numTime)
                {
                    buttonTime16.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 16 && j < numTime)
                {
                    buttonTime17.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 17 && j < numTime)
                {
                    buttonTime18.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 18 && j < numTime)
                {
                    buttonTime19.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 19 && j < numTime)
                {
                    buttonTime20.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 20 && j < numTime)
                {
                    buttonTime21.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 21 && j < numTime)
                {
                    buttonTime22.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 22 && j < numTime)
                {
                    buttonTime23.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 23 && j < numTime)
                {
                    buttonTime24.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 24 && j < numTime)
                {
                    buttonTime25.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 25 && j < numTime)
                {
                    buttonTime26.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 26 && j < numTime)
                {
                    buttonTime27.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 27 && j < numTime)
                {
                    buttonTime28.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 28 && j < numTime)
                {
                    buttonTime29.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 29 && j < numTime)
                {
                    buttonTime30.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightSteelBlue;
            button1.BackColor = Color.WhiteSmoke;
            button3.BackColor = Color.WhiteSmoke;
            button4.BackColor = Color.WhiteSmoke;
            button5.BackColor = Color.WhiteSmoke;

            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            buttonTime1.Visible = true;
            buttonTime2.Visible = true;
            buttonTime3.Visible = true;
            buttonTime4.Visible = true;
            buttonTime5.Visible = true;
            buttonTime6.Visible = true;
            buttonTime12.Visible = true;
            buttonTime11.Visible = true;
            buttonTime10.Visible = true;
            buttonTime9.Visible = true;
            buttonTime8.Visible = true;
            buttonTime7.Visible = true;
            buttonTime18.Visible = true;
            buttonTime17.Visible = true;
            buttonTime16.Visible = true;
            buttonTime15.Visible = true;
            buttonTime14.Visible = true;
            buttonTime13.Visible = true;
            buttonTime24.Visible = false;
            buttonTime23.Visible = false;
            buttonTime22.Visible = false;
            buttonTime21.Visible = false;
            buttonTime20.Visible = false;
            buttonTime19.Visible = false;
            buttonTime30.Visible = false;
            buttonTime29.Visible = false;
            buttonTime28.Visible = false;
            buttonTime27.Visible = false;
            buttonTime26.Visible = false;
            buttonTime25.Visible = false;

            cinemaPlace1 = button2.Text;
            int numTime = Int32.Parse(GetNumberTime().Rows[0][0].ToString());
            for (int j = 0; j < numTime; j++)
            {
                if (j == 0 && j < numTime)
                {
                    buttonTime1.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 1 && j < numTime)
                {
                    buttonTime2.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 2 && j < numTime)
                {
                    buttonTime3.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 3 && j < numTime)
                {
                    buttonTime4.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 4 && j < numTime)
                {
                    buttonTime5.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 5 && j < numTime)
                {
                    buttonTime6.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 6 && j < numTime)
                {
                    buttonTime7.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 7 && j < numTime)
                {
                    buttonTime8.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 8 && j < numTime)
                {
                    buttonTime9.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 9 && j < numTime)
                {
                    buttonTime10.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 10 && j < numTime)
                {
                    buttonTime11.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 11 && j < numTime)
                {
                    buttonTime12.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 12 && j < numTime)
                {
                    buttonTime13.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 13 && j < numTime)
                {
                    buttonTime14.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 14 && j < numTime)
                {
                    buttonTime15.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 15 && j < numTime)
                {
                    buttonTime16.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 16 && j < numTime)
                {
                    buttonTime17.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 17 && j < numTime)
                {
                    buttonTime18.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 18 && j < numTime)
                {
                    buttonTime19.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 19 && j < numTime)
                {
                    buttonTime20.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 20 && j < numTime)
                {
                    buttonTime21.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 21 && j < numTime)
                {
                    buttonTime22.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 22 && j < numTime)
                {
                    buttonTime23.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 23 && j < numTime)
                {
                    buttonTime24.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 24 && j < numTime)
                {
                    buttonTime25.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 25 && j < numTime)
                {
                    buttonTime26.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 26 && j < numTime)
                {
                    buttonTime27.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 27 && j < numTime)
                {
                    buttonTime28.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 28 && j < numTime)
                {
                    buttonTime29.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 29 && j < numTime)
                {
                    buttonTime30.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            button3.BackColor = Color.LightSteelBlue;
            button2.BackColor = Color.WhiteSmoke;
            button1.BackColor = Color.WhiteSmoke;
            button4.BackColor = Color.WhiteSmoke;
            button5.BackColor = Color.WhiteSmoke;

            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            buttonTime1.Visible = true;
            buttonTime2.Visible = true;
            buttonTime3.Visible = true;
            buttonTime4.Visible = true;
            buttonTime5.Visible = true;
            buttonTime6.Visible = true;
            buttonTime12.Visible = true;
            buttonTime11.Visible = true;
            buttonTime10.Visible = true;
            buttonTime9.Visible = true;
            buttonTime8.Visible = true;
            buttonTime7.Visible = true;
            buttonTime18.Visible = true;
            buttonTime17.Visible = true;
            buttonTime16.Visible = true;
            buttonTime15.Visible = true;
            buttonTime14.Visible = true;
            buttonTime13.Visible = true;
            buttonTime24.Visible = false;
            buttonTime23.Visible = false;
            buttonTime22.Visible = true;
            buttonTime21.Visible = true;
            buttonTime20.Visible = true;
            buttonTime19.Visible = true;
            buttonTime30.Visible = false;
            buttonTime29.Visible = false;
            buttonTime28.Visible = false;
            buttonTime27.Visible = false;
            buttonTime26.Visible = false;
            buttonTime25.Visible = false;
            cinemaPlace1 = button3.Text;
            int numTime = Int32.Parse(GetNumberTime().Rows[0][0].ToString());
            for (int j = 0; j < numTime; j++)
            {
                if (j == 0 && j < numTime)
                {
                    buttonTime1.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 1 && j < numTime)
                {
                    buttonTime2.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 2 && j < numTime)
                {
                    buttonTime3.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 3 && j < numTime)
                {
                    buttonTime4.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 4 && j < numTime)
                {
                    buttonTime5.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 5 && j < numTime)
                {
                    buttonTime6.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 6 && j < numTime)
                {
                    buttonTime7.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 7 && j < numTime)
                {
                    buttonTime8.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 8 && j < numTime)
                {
                    buttonTime9.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 9 && j < numTime)
                {
                    buttonTime10.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 10 && j < numTime)
                {
                    buttonTime11.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 11 && j < numTime)
                {
                    buttonTime12.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 12 && j < numTime)
                {
                    buttonTime13.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 13 && j < numTime)
                {
                    buttonTime14.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 14 && j < numTime)
                {
                    buttonTime15.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 15 && j < numTime)
                {
                    buttonTime16.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 16 && j < numTime)
                {
                    buttonTime17.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 17 && j < numTime)
                {
                    buttonTime18.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 18 && j < numTime)
                {
                    buttonTime19.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 19 && j < numTime)
                {
                    buttonTime20.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 20 && j < numTime)
                {
                    buttonTime21.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 21 && j < numTime)
                {
                    buttonTime22.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 22 && j < numTime)
                {
                    buttonTime23.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 23 && j < numTime)
                {
                    buttonTime24.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 24 && j < numTime)
                {
                    buttonTime25.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 25 && j < numTime)
                {
                    buttonTime26.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 26 && j < numTime)
                {
                    buttonTime27.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 27 && j < numTime)
                {
                    buttonTime28.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 28 && j < numTime)
                {
                    buttonTime29.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 29 && j < numTime)
                {
                    buttonTime30.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            button4.BackColor = Color.LightSteelBlue;
            button2.BackColor = Color.WhiteSmoke;
            button3.BackColor = Color.WhiteSmoke;
            button1.BackColor = Color.WhiteSmoke;
            button5.BackColor = Color.WhiteSmoke;

            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            buttonTime1.Visible = true;
            buttonTime2.Visible = true;
            buttonTime3.Visible = true;
            buttonTime4.Visible = true;
            buttonTime5.Visible = true;
            buttonTime6.Visible = true;
            buttonTime12.Visible = true;
            buttonTime11.Visible = true;
            buttonTime10.Visible = true;
            buttonTime9.Visible = true;
            buttonTime8.Visible = true;
            buttonTime7.Visible = true;
            buttonTime18.Visible = false;
            buttonTime17.Visible = false;
            buttonTime16.Visible = false;
            buttonTime15.Visible = false;
            buttonTime14.Visible = false;
            buttonTime13.Visible = false;
            buttonTime24.Visible = false;
            buttonTime23.Visible = false;
            buttonTime22.Visible = false;
            buttonTime21.Visible = false;
            buttonTime20.Visible = false;
            buttonTime19.Visible = false;
            buttonTime30.Visible = false;
            buttonTime29.Visible = false;
            buttonTime28.Visible = false;
            buttonTime27.Visible = false;
            buttonTime26.Visible = false;
            buttonTime25.Visible = false;
            cinemaPlace1 = button4.Text;
            int numTime = Int32.Parse(GetNumberTime().Rows[0][0].ToString());
            for (int j = 0; j < numTime; j++)
            {
                if (j == 0 && j < numTime)
                {
                    buttonTime1.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 1 && j < numTime)
                {
                    buttonTime2.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 2 && j < numTime)
                {
                    buttonTime3.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 3 && j < numTime)
                {
                    buttonTime4.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 4 && j < numTime)
                {
                    buttonTime5.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 5 && j < numTime)
                {
                    buttonTime6.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 6 && j < numTime)
                {
                    buttonTime7.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 7 && j < numTime)
                {
                    buttonTime8.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 8 && j < numTime)
                {
                    buttonTime9.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 9 && j < numTime)
                {
                    buttonTime10.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 10 && j < numTime)
                {
                    buttonTime11.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 11 && j < numTime)
                {
                    buttonTime12.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 12 && j < numTime)
                {
                    buttonTime13.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 13 && j < numTime)
                {
                    buttonTime14.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 14 && j < numTime)
                {
                    buttonTime15.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 15 && j < numTime)
                {
                    buttonTime16.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 16 && j < numTime)
                {
                    buttonTime17.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 17 && j < numTime)
                {
                    buttonTime18.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 18 && j < numTime)
                {
                    buttonTime19.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 19 && j < numTime)
                {
                    buttonTime20.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 20 && j < numTime)
                {
                    buttonTime21.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 21 && j < numTime)
                {
                    buttonTime22.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 22 && j < numTime)
                {
                    buttonTime23.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 23 && j < numTime)
                {
                    buttonTime24.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 24 && j < numTime)
                {
                    buttonTime25.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 25 && j < numTime)
                {
                    buttonTime26.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 26 && j < numTime)
                {
                    buttonTime27.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 27 && j < numTime)
                {
                    buttonTime28.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 28 && j < numTime)
                {
                    buttonTime29.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 29 && j < numTime)
                {
                    buttonTime30.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            button5.BackColor = Color.LightSteelBlue;
            button2.BackColor = Color.WhiteSmoke;
            button3.BackColor = Color.WhiteSmoke;
            button4.BackColor = Color.WhiteSmoke;
            button1.BackColor = Color.WhiteSmoke;

            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            buttonTime1.Visible = true;
            buttonTime2.Visible = true;
            buttonTime3.Visible = true;
            buttonTime4.Visible = true;
            buttonTime5.Visible = true;
            buttonTime6.Visible = true;
            buttonTime12.Visible = true;
            buttonTime11.Visible = true;
            buttonTime10.Visible = true;
            buttonTime9.Visible = true;
            buttonTime8.Visible = true;
            buttonTime7.Visible = true;
            buttonTime18.Visible = true;
            buttonTime17.Visible = true;
            buttonTime16.Visible = true;
            buttonTime15.Visible = true;
            buttonTime14.Visible = true;
            buttonTime13.Visible = true;
            buttonTime24.Visible = true;
            buttonTime23.Visible = true;
            buttonTime22.Visible = true;
            buttonTime21.Visible = true;
            buttonTime20.Visible = true;
            buttonTime19.Visible = true;
            buttonTime30.Visible = false;
            buttonTime29.Visible = false;
            buttonTime28.Visible = false;
            buttonTime27.Visible = true;
            buttonTime26.Visible = true;
            buttonTime25.Visible = true;
            cinemaPlace1 = button5.Text;
            int numTime = Int32.Parse(GetNumberTime().Rows[0][0].ToString());
            for (int j = 0; j < numTime; j++)
            {
                if (j == 0 && j < numTime)
                {
                    buttonTime1.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 1 && j < numTime)
                {
                    buttonTime2.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 2 && j < numTime)
                {
                    buttonTime3.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 3 && j < numTime)
                {
                    buttonTime4.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 4 && j < numTime)
                {
                    buttonTime5.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 5 && j < numTime)
                {
                    buttonTime6.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 6 && j < numTime)
                {
                    buttonTime7.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 7 && j < numTime)
                {
                    buttonTime8.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 8 && j < numTime)
                {
                    buttonTime9.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 9 && j < numTime)
                {
                    buttonTime10.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 10 && j < numTime)
                {
                    buttonTime11.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 11 && j < numTime)
                {
                    buttonTime12.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 12 && j < numTime)
                {
                    buttonTime13.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 13 && j < numTime)
                {
                    buttonTime14.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 14 && j < numTime)
                {
                    buttonTime15.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 15 && j < numTime)
                {
                    buttonTime16.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 16 && j < numTime)
                {
                    buttonTime17.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 17 && j < numTime)
                {
                    buttonTime18.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 18 && j < numTime)
                {
                    buttonTime19.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 19 && j < numTime)
                {
                    buttonTime20.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 20 && j < numTime)
                {
                    buttonTime21.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 21 && j < numTime)
                {
                    buttonTime22.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 22 && j < numTime)
                {
                    buttonTime23.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 23 && j < numTime)
                {
                    buttonTime24.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 24 && j < numTime)
                {
                    buttonTime25.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 25 && j < numTime)
                {
                    buttonTime26.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 26 && j < numTime)
                {
                    buttonTime27.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 27 && j < numTime)
                {
                    buttonTime28.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 28 && j < numTime)
                {
                    buttonTime29.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
                if (j == 29 && j < numTime)
                {
                    buttonTime30.Text = GetTime().Rows[j][0].ToString().Substring(0, 5);
                }
            }
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            showtime1 = buttonTime1.Text;
            buttonTime1.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            showtime1 = buttonTime2.Text;
            buttonTime2.BackColor = Color.LightSteelBlue;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button11_Click_1(object sender, EventArgs e)
        {
            showtime1 = buttonTime3.Text;
            buttonTime3.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            showtime1 = buttonTime4.Text;
            buttonTime4.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime5.Text;
            buttonTime5.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime6.Text;
            buttonTime6.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;

            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime7.Text;
            buttonTime7.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime8.Text;
            buttonTime8.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime9.Text;
            buttonTime9.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime10.Text;
            buttonTime10.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime11.Text;
            buttonTime11.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime12.Text;
            buttonTime12.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime18.Text;
            buttonTime18.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime17.Text;
            buttonTime17.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime16.Text;
            buttonTime16.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime15.Text;
            buttonTime15.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime14.Text;
            buttonTime14.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime13.Text;
            buttonTime13.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime24.Text;
            buttonTime24.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime23.Text;
            buttonTime23.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime22.Text;
            buttonTime22.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime21.Text;
            buttonTime21.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button31_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime20.Text;
            buttonTime20.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button32_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime19.Text;
            buttonTime19.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button33_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime30.Text;
            buttonTime30.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button34_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime29.Text;
            buttonTime29.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button35_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime28.Text;
            buttonTime28.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button36_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime27.Text;
            buttonTime27.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button37_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime26.Text;
            buttonTime26.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            buttonTime25.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void button38_Click(object sender, EventArgs e)
        {
            showtime1 = buttonTime25.Text;
            buttonTime25.BackColor = Color.LightSteelBlue;
            buttonTime2.BackColor = Color.WhiteSmoke;
            buttonTime3.BackColor = Color.WhiteSmoke;
            buttonTime4.BackColor = Color.WhiteSmoke;
            buttonTime5.BackColor = Color.WhiteSmoke;
            buttonTime6.BackColor = Color.WhiteSmoke;
            buttonTime12.BackColor = Color.WhiteSmoke;
            buttonTime11.BackColor = Color.WhiteSmoke;
            buttonTime10.BackColor = Color.WhiteSmoke;
            buttonTime9.BackColor = Color.WhiteSmoke;
            buttonTime8.BackColor = Color.WhiteSmoke;
            buttonTime7.BackColor = Color.WhiteSmoke;
            buttonTime18.BackColor = Color.WhiteSmoke;
            buttonTime17.BackColor = Color.WhiteSmoke;
            buttonTime16.BackColor = Color.WhiteSmoke;
            buttonTime15.BackColor = Color.WhiteSmoke;
            buttonTime14.BackColor = Color.WhiteSmoke;
            buttonTime13.BackColor = Color.WhiteSmoke;
            buttonTime24.BackColor = Color.WhiteSmoke;
            buttonTime23.BackColor = Color.WhiteSmoke;
            buttonTime22.BackColor = Color.WhiteSmoke;
            buttonTime21.BackColor = Color.WhiteSmoke;
            buttonTime20.BackColor = Color.WhiteSmoke;
            buttonTime19.BackColor = Color.WhiteSmoke;
            buttonTime30.BackColor = Color.WhiteSmoke;
            buttonTime29.BackColor = Color.WhiteSmoke;
            buttonTime28.BackColor = Color.WhiteSmoke;
            buttonTime27.BackColor = Color.WhiteSmoke;
            buttonTime26.BackColor = Color.WhiteSmoke;
            buttonTime1.BackColor = Color.WhiteSmoke;
            if (user1 == "")
            {
                MessageBox.Show("Vui lòng đăng nhập để có thể mua vé !");
                Login login = new Login();
                this.Close();
                login.ShowDialog();
                this.Show();
            }
            else
            {
                ChooseSeat chossseat = new ChooseSeat(dayOfWeek1, cinemaPlace1, showtime1, user1, pic1, name1, category1, content1, actor1, director1, producer1, studio1, date1, time1, age1);
                this.Close();
                chossseat.ShowDialog();
                this.Show();
            }
        }

        private void buttoncgv_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        DataTable GetIdPlace()
        {
            DataTable data = new DataTable();
            string query = "SELECT * FROM PLACE WHERE NAME_PLACE='" + comboBox1.SelectedItem + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetIdDate()
        {
            DateTime d1 = DateTime.Now;
            string day = d1.AddDays(1).Day.ToString();
            string month = d1.AddDays(1).Month.ToString();
            string dateNew = month + "/" + day;
            DataTable data = new DataTable();
            string query = "SELECT ID_DATE1 FROM DATE1 WHERE NAME_DATE1='2022/6/3'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }


        DataTable GetCinema()
        {
            int numCinema = Int32.Parse(GetNumberCinema().Rows[0][0].ToString());
            DataTable data = new DataTable();
            string query = "SELECT NAME_CINEMA FROM CINEMA WHERE ID_DATE1='" + GetIdDate().Rows[0][0].ToString() + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }
        DataTable GetNumberCinema()
        {
            DataTable data = new DataTable();
            string query = "SELECT COUNT (*) FROM CINEMA WHERE ID_DATE1='" + GetIdDate().Rows[0][0].ToString() + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetNumberPlace()
        {
            DataTable data = new DataTable();
            //Lấy số lượng bộ phim trong db
            string query = "SELECT COUNT (*) FROM PLACE WHERE ID_MOVIE='" + GetIdMovie().Rows[0][0].ToString() + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetIdMovie()
        {
            DataTable data = new DataTable();
            string query = "SELECT ID_MOVIE FROM MOVIE WHERE NAME_MOVIE=N'" + name1 + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetDate()
        {
            DataTable data = new DataTable();
            string query = "SELECT * FROM DATE WHERE ID_PLACE='" + date1 + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetPlace()
        {
            int num = Int32.Parse(GetNumberPlace().Rows[0][0].ToString());
            DataTable data = new DataTable();
            for (int j = 0; j < num; j++)
            {
                string query = "SELECT NAME_PLACE FROM PLACE WHERE ID_MOVIE='" + GetIdMovie().Rows[0][0].ToString() + "'";
                using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(data);
                    connection.Close();
                }
            }
            return data;
        }

        DataTable GetIdCinema()
        {
            DataTable data = new DataTable();
            string query = "SELECT ID_CINEMA FROM CINEMA WHERE NAME_CINEMA=N'" + cinemaPlace1 + "' AND ID_DATE1='"+GetIdDate().Rows[0][0].ToString()+"'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetNumberTime()
        {
            DataTable data = new DataTable();
            string query = "SELECT COUNT (*) FROM TIME1 WHERE ID_CINEMA='" + GetIdCinema().Rows[0][0].ToString() + "'";
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        DataTable GetTime()
        {
            int num = Int32.Parse(GetNumberTime().Rows[0][0].ToString());
            DataTable data = new DataTable();
            for (int j = 0; j < num; j++)
            {
                string query = "SELECT NAME_TIME1 FROM TIME1 WHERE ID_CINEMA='" + GetIdCinema().Rows[0][0].ToString() + "'";
                using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(data);
                    connection.Close();
                }
            }
            return data;
        }
    }
}
